// CaterMe Shop — React UI for WooCommerce shop page
// Mounts on #caterme-shop-root, manages cart via caterme/v1/cart REST endpoints

/* ── Constants ── */
const S  = (typeof CATERME_SETTINGS !== 'undefined') ? CATERME_SETTINGS : {};
const _menuData = (typeof CATERME_MENU !== 'undefined' && CATERME_MENU)
  ? CATERME_MENU : { categories: [], items: {} };

const CATEGORIES     = _menuData.categories.map(c => c.name);
const CATEGORY_ICONS = Object.fromEntries(_menuData.categories.map(c => [c.name, c.icon || '🍽️']));
const MENU = {};
CATEGORIES.forEach(cat => { MENU[cat] = _menuData.items[cat] || []; });
const CATEGORY_TAGS = {};
CATEGORIES.forEach(cat => {
  const tags = [...new Set((MENU[cat] || []).map(i => i.tag).filter(Boolean))];
  CATEGORY_TAGS[cat] = tags;
});

const TAG_PALETTE = [
  {bg:"#fff3e0",color:"#b45309",border:"#f6d28a"},
  {bg:"#e8f5e9",color:"#276221",border:"#a5d6a7"},
  {bg:"#e3f2fd",color:"#1565c0",border:"#90caf9"},
  {bg:"#fce4ec",color:"#ad1457",border:"#f48fb1"},
  {bg:"#f3e5f5",color:"#6a1b9a",border:"#ce93d8"},
  {bg:"#e0f7fa",color:"#00695c",border:"#80cbc4"},
];
const TAG_COLORS = {};
let _tagIdx = 0;
CATEGORIES.forEach(cat => {
  (CATEGORY_TAGS[cat]||[]).forEach(tag => {
    if (!TAG_COLORS[tag]) TAG_COLORS[tag] = TAG_PALETTE[_tagIdx++ % TAG_PALETTE.length];
  });
});

const DIETARY_OPTIONS = [
  {key:"gluten_free",  label:"Gluten-Free",  icon:"🌾",color:"#d97706",bg:"#fef3c7"},
  {key:"dairy_free",   label:"Dairy-Free",   icon:"🥛",color:"#0284c7",bg:"#e0f2fe"},
  {key:"nut_allergy",  label:"Nut Allergy",  icon:"🥜",color:"#b45309",bg:"#fef9c3"},
  {key:"vegetarian",   label:"Vegetarian",   icon:"🥦",color:"#16a34a",bg:"#dcfce7"},
  {key:"vegan",        label:"Vegan",        icon:"🌱",color:"#15803d",bg:"#d1fae5"},
  {key:"no_onion",     label:"No Onion",     icon:"🧅",color:"#7c3aed",bg:"#ede9fe"},
  {key:"no_tomato",    label:"No Tomato",    icon:"🍅",color:"#dc2626",bg:"#fee2e2"},
  {key:"no_croutons",  label:"No Croutons",  icon:"🍞",color:"#92400e",bg:"#fef3c7"},
  {key:"no_cheese",    label:"No Cheese",    icon:"🧀",color:"#ca8a04",bg:"#fefce8"},
  {key:"low_sodium",   label:"Low Sodium",   icon:"🧂",color:"#64748b",bg:"#f1f5f9"},
  {key:"halal",        label:"Halal",        icon:"☪️", color:"#065f46",bg:"#d1fae5"},
  {key:"kosher",       label:"Kosher",       icon:"✡️", color:"#1e40af",bg:"#dbeafe"},
];

/* ── Theme ── */
function resolveTheme() {
  const inherit = S.style_mode === 'inherit';
  const R = parseInt(S.border_radius || 12, 10);
  if (inherit) return {
    inherit:true,primary:'',accent:'',bg:'',card:'',text:'',muted:'',border:'',
    headingFont:'',bodyFont:'',radius:R+'px',showHeader:S.show_header!=='0'};
  return {
    inherit:false,
    primary:   S.color_primary    || '#1a1208',
    accent:    S.color_accent     || '#c8832a',
    bg:        S.color_bg         || '#faf7f2',
    card:      S.color_card       || '#ffffff',
    text:      S.color_text       || '#2a1f0e',
    muted:     S.color_text_muted || '#7a6040',
    border:    S.color_border     || '#e8dcc8',
    headingFont: S.font_heading || 'Georgia, serif',
    bodyFont:    S.font_body    || 'Georgia, serif',
    radius:    R+'px',
    showHeader: S.show_header !== '0',
  };
}

/* ── Helpers ── */
function buildDefaultSelections(item) {
  const sel = {dietary:[]};
  (item.options||[]).forEach(opt => {
    if (opt.type==='select')  sel[opt.key] = (opt.max_selections||1)>1 ? [] : (opt.choices[0]||'');
    if (opt.type==='toggle')  sel[opt.key] = false;
    if (opt.type==='number')  sel[opt.key] = opt.default || opt.min || 1;
  });
  return sel;
}

function calcItemPrice(item, selections) {
  let price = item.price;
  const numOpt = (item.options||[]).find(o => o.type==='number');
  if (numOpt && selections[numOpt.key]) price = item.price * selections[numOpt.key];
  (item.options||[]).forEach(opt => {
    if (opt.type==='toggle' && selections[opt.key] && opt.price) price += parseFloat(opt.price)||0;
  });
  (item.options||[]).forEach(opt => {
    if (opt.type==='select' && selections[opt.key]) {
      const vals = Array.isArray(selections[opt.key]) ? selections[opt.key] : [selections[opt.key]];
      vals.forEach(v => { const m=String(v).match(/\+\$([0-9.]+)/); if(m) price+=parseFloat(m[1]); });
    }
  });
  return price;
}

function formatSelections(item, selections) {
  const parts = (item.options||[]).map(opt => {
    const val = selections[opt.key];
    if (opt.type==='toggle') return val ? opt.label : null;
    if (opt.type==='number') return val + ' lb' + (val>1?'s':'');
    if (Array.isArray(val))  return val.length>0 ? val.join(', ') : null;
    return val || null;
  }).filter(Boolean);
  return parts.join(' · ');
}

/* ── API helpers ── */
const API = S.rest_url ? S.rest_url.replace('/submit','') : '';
const nonce = S.rest_nonce || '';

async function apiPost(path, body) {
  const res = await fetch(API + path, {
    method:'POST',
    headers:{'Content-Type':'application/json','X-WP-Nonce':nonce},
    body: JSON.stringify(body),
  });
  return res.json();
}
async function apiGet(path) {
  const res = await fetch(API + path, {headers:{'X-WP-Nonce':nonce}});
  return res.json();
}

/* ═══════════════════════════════════════════════════════════════════
   MAIN COMPONENT
═══════════════════════════════════════════════════════════════════ */
function CaterMeShop() {
  const T  = resolveTheme();
  const F  = {heading: T.headingFont||'Georgia, serif', body: T.bodyFont||'Georgia, serif'};
  const cols = parseInt(S.menu_columns || 2, 10);

  const [activeCategory, setActiveCategory] = React.useState(CATEGORIES[0]||'');
  const [activeTag,      setActiveTag]      = React.useState('All');
  const [configuring,    setConfiguring]    = React.useState(null);
  const [showCart,       setShowCart]       = React.useState(false);

  // WC cart state — synced from API
  const [cartItems,   setCartItems]   = React.useState([]);
  const [cartCount,   setCartCount]   = React.useState(0);
  const [cartSubtotal,setCartSubtotal]= React.useState(0);
  const [cartLoading, setCartLoading] = React.useState(false);
  const [addingId,    setAddingId]    = React.useState(null); // product_id being added

  // Load cart on mount
  React.useEffect(() => {
    loadCart();
  }, []);

  async function loadCart() {
    try {
      const data = await apiGet('/cart');
      if (data && data.items) {
        setCartItems(data.items);
        setCartCount(data.count || 0);
        setCartSubtotal(data.subtotal || 0);
      }
    } catch(e) {}
  }

  // ── Open modifier modal ──
  function openConfig(item) {
    setConfiguring({
      item,
      selections: buildDefaultSelections(item),
      label_name: '',
    });
  }

  function toggleDietary(key) {
    setConfiguring(c => {
      const cur  = c.selections.dietary || [];
      const next = cur.includes(key) ? cur.filter(k=>k!==key) : [...cur, key];
      return {...c, selections:{...c.selections, dietary:next}};
    });
  }

  // ── Add to WC cart ──
  async function addToCart() {
    if (!configuring) return;
    const {item, selections, label_name} = configuring;
    const price = calcItemPrice(item, selections);

    // Build readable selections array
    const sels = [];
    (item.options||[]).forEach(opt => {
      const val = selections[opt.key];
      if (opt.type==='toggle') { if(val) sels.push(opt.label); }
      else if (opt.type==='number') { sels.push(val+' lb'+(val>1?'s':'')); }
      else if (Array.isArray(val)) { val.forEach(v=>sels.push(v)); }
      else if (val) { sels.push(val); }
    });
    const dietaryLabels = (selections.dietary||[]).map(k => {
      const d = DIETARY_OPTIONS.find(x=>x.key===k);
      return d ? d.label : k;
    });

    setAddingId(item.id);
    setConfiguring(null);
    setCartLoading(true);

    try {
      const data = await apiPost('/cart/add', {
        product_id: item.id,
        qty: 1,
        price,
        selections: sels,
        dietary: dietaryLabels.join(', '),
        label_name: label_name || '',
      });
      if (data.success) {
        setCartCount(data.cart_count || 0);
        await loadCart();
        setShowCart(true);
      }
    } catch(e) {}
    setAddingId(null);
    setCartLoading(false);
  }

  async function removeFromCart(cart_key) {
    setCartLoading(true);
    try {
      const data = await apiPost('/cart/remove', {cart_key});
      if (data.success) {
        setCartCount(data.count || 0);
        setCartSubtotal(data.subtotal || 0);
        setCartItems(prev => prev.filter(i=>i.cart_key!==cart_key));
      }
    } catch(e) {}
    setCartLoading(false);
  }

  async function updateQty(cart_key, delta, currentQty) {
    const newQty = Math.max(0, currentQty + delta);
    setCartLoading(true);
    // Optimistic update
    if (newQty === 0) {
      setCartItems(prev => prev.filter(i=>i.cart_key!==cart_key));
    } else {
      setCartItems(prev => prev.map(i=>i.cart_key===cart_key ? {...i, qty:newQty} : i));
    }
    try {
      await apiPost('/cart/update', {cart_key, qty:newQty});
      await loadCart();
    } catch(e) {}
    setCartLoading(false);
  }

  const catTags = CATEGORY_TAGS[activeCategory] || [];
  const tags = catTags.length > 0 ? ['All', ...catTags] : null;
  const visibleItems = (MENU[activeCategory]||[]).filter(item =>
    !tags || activeTag==='All' || item.tag===activeTag
  );

  const gridCols = Math.min(cols, 4);
  const gridStyle = {
    display:'grid',
    gridTemplateColumns: `repeat(${gridCols}, minmax(0, 1fr))`,
    gap:'16px',
    padding:'0 20px 32px',
  };

  return React.createElement('div', {
    className: 'caterme-shop',
    style: Object.assign({minHeight:400, position:'relative'},
      T.bg  ? {background:T.bg}  : {},
      T.text ? {color:T.text}    : {},
      {fontFamily:F.body}
    )
  },

    // Test mode banner
    S.test_mode && React.createElement('div', {
      style:{background:'#d97706',color:'#fff',padding:'10px 18px',display:'flex',alignItems:'center',gap:10,fontSize:13,fontWeight:700}
    }, '🧪 TEST MODE — Orders are saved but no payment collected.'),

    // Header bar with cart button
    React.createElement('div', {
      className:'caterme-shop-header',
      style: Object.assign({padding:'14px 20px',display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:10},
        T.primary ? {background:T.primary} : {background:'#1a1208'})
    },
      T.showHeader && React.createElement('div', null,
        React.createElement('p', {style:{fontFamily:F.heading,fontSize:22,fontWeight:900,color:'#f5e6c8',letterSpacing:2,textTransform:'uppercase',margin:0}},
          (S.store_name||'CaterMe').toUpperCase()),
        React.createElement('p', {style:{fontSize:11,color:'#b8996a',letterSpacing:3,textTransform:'uppercase',margin:0}}, 'Catering Menu')
      ),
      React.createElement('button', {
        onClick: ()=>setShowCart(true),
        className: 'caterme-cart-btn',
        style:{background:T.accent||'#c8832a',border:'none',borderRadius:30,padding:'9px 18px',color:'#fff',cursor:'pointer',fontSize:14,fontWeight:700,display:'flex',alignItems:'center',gap:8,fontFamily:F.body,marginLeft:'auto'}
      },
        '🛒',
        ` Order (${cartCount})`,
        cartSubtotal > 0 && React.createElement('span', {
          style:{background:'rgba(255,255,255,0.18)',borderRadius:20,padding:'2px 8px'}
        }, '$'+cartSubtotal.toFixed(2))
      )
    ),

    // Category tabs
    React.createElement('div', {
      className:'caterme-cat-tabs',
      style:{display:'flex',gap:6,overflowX:'auto',padding:'16px 20px 0',scrollbarWidth:'none'}
    },
      CATEGORIES.map(cat => React.createElement('button', {
        key: cat,
        onClick: ()=>{ setActiveCategory(cat); setActiveTag('All'); },
        style:{
          fontFamily:F.body, whiteSpace:'nowrap', padding:'8px 16px', borderRadius:'30px',
          cursor:'pointer', fontSize:13, fontWeight:700, border:'none',
          background: activeCategory===cat ? (T.accent||'#c8832a') : (T.card||'#fff'),
          color:       activeCategory===cat ? '#fff' : (T.muted||'#5a3e20'),
          boxShadow:   activeCategory===cat ? '0 2px 10px rgba(200,131,42,0.35)' : '0 1px 3px rgba(0,0,0,0.08)',
          transition: 'all .15s',
        }
      }, `${CATEGORY_ICONS[cat]||'🍽️'} ${cat}`))
    ),

    // Tag filter pills
    tags && React.createElement('div', {
      style:{display:'flex',gap:7,padding:'12px 20px 0',flexWrap:'wrap'}
    },
      tags.map(tag => {
        const tc = TAG_COLORS[tag];
        const isAll = tag==='All';
        const active = activeTag===tag;
        return React.createElement('button', {
          key:tag,
          onClick: ()=>setActiveTag(tag),
          style:{
            fontFamily:F.body, padding:'5px 13px', borderRadius:20, fontSize:12, fontWeight:700,
            cursor:'pointer', transition:'all .12s',
            border: active ? `2px solid ${isAll ? (T.accent||'#c8832a') : tc.color}` : `1.5px solid ${isAll ? (T.border||'#e0d0b8') : tc.border}`,
            background: active ? (isAll ? '#fff7ed' : tc.bg) : (T.card||'#fff'),
            color: active ? (isAll ? (T.accent||'#c8832a') : tc.color) : (T.muted||'#7a6040'),
          }
        }, tag);
      })
    ),

    // Product grid
    React.createElement('div', {style:gridStyle, className:'caterme-product-grid'},
      visibleItems.map(item =>
        React.createElement('div', {
          key:item.id,
          className:'caterme-product-card',
          style:{background:T.card||'#fff',borderRadius:T.radius,border:`1px solid ${T.border||'#e8dcc8'}`,overflow:'hidden',display:'flex',flexDirection:'column',boxShadow:'0 1px 4px rgba(0,0,0,0.06)'}
        },
          // Product image
          item.image && React.createElement('div', {style:{height:160,overflow:'hidden',background:'#f5f5f5'}},
            React.createElement('img', {src:item.image,alt:item.name,style:{width:'100%',height:'100%',objectFit:'cover'}})
          ),

          React.createElement('div', {style:{padding:'14px 16px',display:'flex',flexDirection:'column',flex:1,gap:6}},
            // Tag pill
            item.tag && React.createElement('span', {
              style:Object.assign({alignSelf:'flex-start',fontSize:11,padding:'2px 9px',borderRadius:20,fontWeight:700},
                TAG_COLORS[item.tag] || {background:'#f3f4f6',color:'#555',border:'1px solid #ddd'})
            }, item.tag),

            React.createElement('p', {
              style:{fontFamily:F.heading,fontSize:15,fontWeight:800,color:T.text||'#1a1208',margin:0,lineHeight:1.3}
            }, item.name),

            item.description && React.createElement('p', {
              style:{fontSize:12,color:T.muted||'#7a6040',margin:0,lineHeight:1.55,flex:1}
            }, item.description),

            // Price row
            React.createElement('div', {style:{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:'auto',paddingTop:8}},
              React.createElement('p', {
                style:{fontFamily:F.heading,fontSize:17,fontWeight:900,color:T.accent||'#c8832a',margin:0}
              }, '$'+item.price.toFixed(2) + (item.unit ? ' '+item.unit : '')),

              React.createElement('button', {
                onClick: ()=>openConfig(item),
                disabled: addingId===item.id,
                style:{
                  fontFamily:F.body, background:addingId===item.id?'#aaa':(T.accent||'#c8832a'),
                  color:'#fff', border:'none', borderRadius:T.radius||'8px',
                  padding:'8px 14px', cursor:addingId===item.id?'wait':'pointer',
                  fontSize:12.5, fontWeight:700
                }
              }, addingId===item.id ? 'Adding…' : (item.options&&item.options.length>0 ? 'Customize & Add' : '+ Add'))
            )
          )
        )
      )
    ),

    // ── Modifier Modal ──
    configuring && React.createElement('div', {
      style:{position:'fixed',inset:0,background:'rgba(10,6,2,0.65)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center',padding:16},
      onClick:()=>setConfiguring(null)
    },
      React.createElement('div', {
        style:{fontFamily:F.body,background:T.card||'#fff',borderRadius:T.radius,padding:'24px',maxWidth:460,width:'100%',boxShadow:'0 20px 60px rgba(0,0,0,0.35)',maxHeight:'90vh',overflowY:'auto'},
        onClick:e=>e.stopPropagation()
      },
        // Header
        React.createElement('div', {style:{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:6}},
          React.createElement('p', {style:{fontFamily:F.heading,fontSize:18,fontWeight:800,color:T.text||'#1a1208',margin:0,flex:1,paddingRight:10}},
            configuring.item.name),
          React.createElement('button', {onClick:()=>setConfiguring(null),style:{background:'none',border:'none',cursor:'pointer',fontSize:22,color:'#999'}}, '×')
        ),
        React.createElement('p', {style:{fontSize:12,color:T.muted||'#7a6040',marginBottom:18,lineHeight:1.6}},
          configuring.item.description),

        // Options
        (configuring.item.options||[]).map(opt => React.createElement('div', {key:opt.key,style:{marginBottom:16}},
          React.createElement('label', {style:{display:'block',fontSize:11,fontWeight:700,color:T.muted||'#5a3e20',textTransform:'uppercase',letterSpacing:1,marginBottom:7}},
            opt.label, opt.required && React.createElement('span', {style:{color:T.accent||'#c8832a'}}, ' *')
          ),
          opt.type==='select' && (() => {
            const maxSel = opt.max_selections||0;
            const curSels = Array.isArray(configuring.selections[opt.key])
              ? configuring.selections[opt.key]
              : (configuring.selections[opt.key] ? [configuring.selections[opt.key]] : []);
            const isMulti = maxSel!==1;
            return React.createElement('div', {style:{display:'flex',flexWrap:'wrap',gap:6}},
              opt.choices.map(choice => {
                const active = isMulti ? curSels.includes(choice) : configuring.selections[opt.key]===choice;
                const atLimit = isMulti && maxSel>0 && curSels.length>=maxSel && !active;
                return React.createElement('button', {
                  key:choice,
                  onClick:()=>{
                    if(atLimit) return;
                    setConfiguring(c=>{
                      if(!isMulti) return {...c,selections:{...c.selections,[opt.key]:choice}};
                      const prev = Array.isArray(c.selections[opt.key]) ? c.selections[opt.key] : [];
                      const next = prev.includes(choice) ? prev.filter(x=>x!==choice) : [...prev,choice];
                      return {...c,selections:{...c.selections,[opt.key]:next}};
                    });
                  },
                  style:{fontFamily:F.body,padding:'7px 12px',fontSize:12.5,borderRadius:'8px',cursor:atLimit?'not-allowed':'pointer',opacity:atLimit?0.45:1,
                    border:active?`2px solid ${T.accent||'#c8832a'}`:`2px solid ${T.border||'#e0d0b8'}`,
                    background:active?'#fff7ed':(T.bg||'#faf7f2'),color:active?(T.accent||'#c8832a'):(T.muted||'#5a3e20'),fontWeight:active?700:400}
                }, choice);
              }),
              opt.max_selections>1 && React.createElement('span', {style:{width:'100%',fontSize:11,color:T.muted||'#a07848',marginTop:2}},
                'Choose up to '+opt.max_selections)
            );
          })(),
          opt.type==='toggle' && React.createElement('button', {
            onClick:()=>setConfiguring(c=>({...c,selections:{...c.selections,[opt.key]:!c.selections[opt.key]}})),
            style:{fontFamily:F.body,padding:'7px 14px',fontSize:12.5,borderRadius:'8px',cursor:'pointer',
              border:configuring.selections[opt.key]?`2px solid ${T.accent||'#c8832a'}`:`2px solid ${T.border||'#e0d0b8'}`,
              background:configuring.selections[opt.key]?'#fff7ed':(T.bg||'#faf7f2'),
              color:configuring.selections[opt.key]?(T.accent||'#c8832a'):(T.muted||'#5a3e20'),
              fontWeight:configuring.selections[opt.key]?700:400}
          }, configuring.selections[opt.key]?'✓ '+opt.label:opt.label),
          opt.type==='number' && React.createElement('div', {style:{display:'flex',alignItems:'center',gap:10}},
            React.createElement('button', {onClick:()=>setConfiguring(c=>({...c,selections:{...c.selections,[opt.key]:Math.max(opt.min||1,c.selections[opt.key]-1)}})),style:{width:32,height:32,borderRadius:'8px',border:`1.5px solid ${T.border||'#e0d0b8'}`,background:T.bg||'#faf7f2',cursor:'pointer',fontSize:17,fontWeight:700,color:T.muted||'#5a3e20'}}, '−'),
            React.createElement('span', {style:{fontSize:17,fontWeight:700,minWidth:20,textAlign:'center'}}, configuring.selections[opt.key]),
            React.createElement('button', {onClick:()=>setConfiguring(c=>({...c,selections:{...c.selections,[opt.key]:c.selections[opt.key]+1}})),style:{width:32,height:32,borderRadius:'8px',border:`1.5px solid ${T.border||'#e0d0b8'}`,background:T.bg||'#faf7f2',cursor:'pointer',fontSize:17,fontWeight:700,color:T.muted||'#5a3e20'}}, '+'),
            React.createElement('span', {style:{fontSize:13,color:T.muted||'#a07848'}}, 'lbs')
          )
        )),

        // Label name
        React.createElement('div', {style:{marginTop:6,paddingTop:14,borderTop:`1px solid ${T.border||'#f0e8d8'}`}},
          React.createElement('label', {style:{display:'block',fontSize:11,fontWeight:700,color:T.muted||'#5a3e20',textTransform:'uppercase',letterSpacing:1,marginBottom:7}},
            '🏷️ Label Name ', React.createElement('span', {style:{color:'#aaa',fontWeight:400,textTransform:'none',letterSpacing:0,fontSize:11}}, '(printed on label)')
          ),
          React.createElement('input', {
            type:'text',value:configuring.label_name||'',
            onChange:e=>setConfiguring(c=>({...c,label_name:e.target.value})),
            placeholder:'e.g. John, Table 3, Gluten-Free Guest...',maxLength:40,
            style:{fontFamily:F.body,width:'100%',border:`2px solid ${T.border||'#e0d0b8'}`,borderRadius:'8px',padding:'9px 12px',fontSize:13,color:T.text||'#1a1208',background:T.bg||'#faf7f2',boxSizing:'border-box',outline:'none'}
          })
        ),

        // Dietary
        React.createElement('div', {style:{marginTop:6,paddingTop:14,borderTop:`1px solid ${T.border||'#f0e8d8'}`}},
          React.createElement('label', {style:{display:'block',fontSize:11,fontWeight:700,color:T.muted||'#5a3e20',textTransform:'uppercase',letterSpacing:1,marginBottom:10}},
            'Dietary Restrictions / Allergies'),
          React.createElement('div', {style:{display:'flex',flexWrap:'wrap',gap:7}},
            DIETARY_OPTIONS.map(d => {
              const active = (configuring.selections.dietary||[]).includes(d.key);
              return React.createElement('button', {
                key:d.key, onClick:()=>toggleDietary(d.key),
                style:{fontFamily:F.body,padding:'6px 11px',fontSize:12,borderRadius:20,cursor:'pointer',display:'flex',alignItems:'center',gap:5,
                  border:active?`2px solid ${d.color}`:`1.5px solid ${T.border||'#e0d0b8'}`,
                  background:active?d.bg:(T.bg||'#faf7f2'),color:active?d.color:(T.muted||'#7a6040'),fontWeight:active?700:400}
              }, d.icon+' '+d.label);
            })
          )
        ),

        // Footer
        React.createElement('div', {style:{borderTop:`1px solid ${T.border||'#e8dcc8'}`,paddingTop:14,marginTop:16,display:'flex',justifyContent:'space-between',alignItems:'center'}},
          React.createElement('span', {style:{fontFamily:F.heading,fontSize:20,fontWeight:800,color:T.accent||'#c8832a'}},
            '$'+calcItemPrice(configuring.item,configuring.selections).toFixed(2)),
          React.createElement('button', {
            onClick:addToCart,
            style:{fontFamily:F.body,background:T.accent||'#c8832a',color:'#fff',border:'none',borderRadius:T.radius||'10px',padding:'12px 26px',cursor:'pointer',fontSize:14,fontWeight:700}
          }, 'Add to Order')
        )
      )
    ),

    // ── Cart Drawer ──
    showCart && React.createElement('div', {
      style:{position:'fixed',inset:0,background:'rgba(10,6,2,0.55)',zIndex:9998},
      onClick:()=>setShowCart(false)
    },
      React.createElement('div', {
        style:{fontFamily:F.body,position:'fixed',top:0,right:0,bottom:0,width:'min(420px,100vw)',background:T.bg||'#faf7f2',zIndex:10000,overflowY:'auto',padding:'22px 18px',boxShadow:'-8px 0 40px rgba(0,0,0,0.2)'},
        onClick:e=>e.stopPropagation()
      },
        // Drawer header
        React.createElement('div', {style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:18}},
          React.createElement('p', {style:{fontFamily:F.heading,fontSize:20,fontWeight:900,color:T.text||'#1a1208',margin:0}}, 'Your Order'),
          React.createElement('button', {onClick:()=>setShowCart(false),style:{background:'none',border:'none',cursor:'pointer',fontSize:24,color:'#999'}}, '×')
        ),

        cartItems.length===0
          ? React.createElement('div', {style:{textAlign:'center',color:T.muted||'#a07848',padding:'50px 0'}},
              React.createElement('div', {style:{fontSize:36,marginBottom:10}}, '🥡'),
              'Your order is empty.',
              React.createElement('br'),
              'Browse the menu to get started!'
            )
          : React.createElement(React.Fragment, null,

              // Cart items list
              cartItems.map(entry => React.createElement('div', {
                key:entry.cart_key,
                style:{background:T.card||'#fff',borderRadius:T.radius,padding:'13px',marginBottom:10,border:`1px solid ${T.border||'#e8dcc8'}`}
              },
                React.createElement('div', {style:{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}},
                  React.createElement('div', {style:{flex:1}},
                    React.createElement('p', {style:{fontFamily:F.heading,fontWeight:700,fontSize:13.5,color:T.text||'#1a1208',margin:'0 0 3px'}}, entry.name),
                    entry.label_name && React.createElement('p', {style:{fontSize:11.5,color:T.accent||'#c8832a',fontWeight:700,margin:'0 0 3px',display:'flex',alignItems:'center',gap:4}},
                      '🏷️ ', entry.label_name),
                    entry.selections && entry.selections.length>0 && React.createElement('p', {style:{fontSize:11.5,color:T.muted||'#8a6a3a',margin:'0 0 3px',lineHeight:1.5}},
                      entry.selections.join(' · ')),
                    entry.dietary && React.createElement('p', {style:{fontSize:11,color:T.accent||'#c8832a',margin:'2px 0 0'}}, entry.dietary),
                    React.createElement('p', {style:{fontSize:13,color:T.accent||'#c8832a',fontWeight:700,margin:'4px 0 0'}},
                      '$'+(entry.line_total||entry.price*entry.qty).toFixed(2))
                  ),
                  React.createElement('div', {style:{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:6,marginLeft:8}},
                    React.createElement('div', {style:{display:'flex',alignItems:'center',gap:7}},
                      React.createElement('button', {onClick:()=>updateQty(entry.cart_key,-1,entry.qty),style:{width:26,height:26,borderRadius:'6px',border:`1.5px solid ${T.border||'#e0d0b8'}`,background:T.bg||'#faf7f2',cursor:'pointer',fontSize:14,fontWeight:700,color:T.muted||'#5a3e20'}}, '−'),
                      React.createElement('span', {style:{fontSize:14,fontWeight:700,minWidth:16,textAlign:'center'}}, entry.qty),
                      React.createElement('button', {onClick:()=>updateQty(entry.cart_key,1,entry.qty),style:{width:26,height:26,borderRadius:'6px',border:`1.5px solid ${T.border||'#e0d0b8'}`,background:T.bg||'#faf7f2',cursor:'pointer',fontSize:14,fontWeight:700,color:T.muted||'#5a3e20'}}, '+')
                    ),
                    React.createElement('button', {onClick:()=>removeFromCart(entry.cart_key),style:{background:'none',border:'none',cursor:'pointer',fontSize:11,color:'#cc3333',textDecoration:'underline'}}, 'Remove')
                  )
                )
              )),

              // Order summary
              React.createElement('div', {style:{background:T.primary||'#1a1208',borderRadius:T.radius,padding:'16px',marginTop:14,color:'#f5e6c8'}},
                React.createElement('div', {style:{display:'flex',justifyContent:'space-between',fontSize:12.5,marginBottom:6,color:'#b8996a'}},
                  React.createElement('span', null, 'Subtotal'), React.createElement('span', null, '$'+cartSubtotal.toFixed(2))),
                React.createElement('div', {style:{display:'flex',justifyContent:'space-between',fontSize:12.5,marginBottom:10,color:'#b8996a'}},
                  React.createElement('span', null, 'Tax & Delivery'), React.createElement('span', null, 'Calculated at checkout')),
                React.createElement('div', {style:{display:'flex',justifyContent:'space-between',fontSize:17,fontWeight:800,borderTop:'1px solid rgba(255,255,255,0.1)',paddingTop:10}},
                  React.createElement('span', null, 'Total'),
                  React.createElement('span', {style:{color:T.accent||'#c8832a'}}, '$'+cartSubtotal.toFixed(2)+'+'))
              ),

              // WC pre-auth notice
              !S.test_mode && S.wc_active && S.wc_preauth_note && React.createElement('div', {
                style:{background:'#f9f6ff',border:'1px solid #c9b3e8',borderRadius:T.radius||'8px',padding:'12px 14px',marginTop:12,display:'flex',gap:10,alignItems:'flex-start'}
              },
                React.createElement('span', {style:{fontSize:18,flexShrink:0}}, '🔒'),
                React.createElement('p', {style:{fontSize:12,color:'#3d2373',lineHeight:1.6,margin:0}}, S.wc_preauth_note)
              ),

              // Checkout button
              React.createElement('a', {
                href: S.checkout_url || '/checkout/',
                className: 'caterme-checkout-btn',
                style:{display:'block',textAlign:'center',background:S.test_mode?'#d97706':(T.accent||'#c8832a'),color:'#fff',border:'none',borderRadius:T.radius||'10px',padding:'14px',fontSize:15,fontWeight:800,marginTop:12,textDecoration:'none',fontFamily:F.body}
              }, S.test_mode ? '🧪 Test Checkout' : (S.wc_active ? 'Checkout & Enter Card Details →' : 'Proceed to Checkout →')),

              // Contact
              (S.store_email||S.store_phone) && React.createElement('p', {
                style:{textAlign:'center',fontSize:12,color:T.muted||'#a07848',marginTop:8}
              }, [S.store_email&&('Email '+S.store_email), S.store_phone].filter(Boolean).join(' · '))
            )
      )
    )
  );
}

/* ── Mount ── */
const shopRoot = document.getElementById('caterme-shop-root');
if (shopRoot) {
  const root = ReactDOM.createRoot(shopRoot);
  root.render(React.createElement(CaterMeShop));
}
