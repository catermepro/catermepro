

// ─── Dietary Restrictions ────────────────────────────────────────────────────
// The 12 built-in dietary/allergy tags. These are managed as a Modifier Template
// (see Modifier Templates admin page) — the array below drives the color-coded
// pills in the item customization modal.
const DIETARY_DEFAULTS = [
  { key: "gluten_free",   label: "Gluten-Free",   icon: "🌾", color: "#d97706", bg: "#fef3c7" },
  { key: "dairy_free",    label: "Dairy-Free",    icon: "🥛", color: "#0284c7", bg: "#e0f2fe" },
  { key: "nut_allergy",   label: "Nut Allergy",   icon: "🥜", color: "#b45309", bg: "#fef9c3" },
  { key: "vegetarian",    label: "Vegetarian",    icon: "🥦", color: "#16a34a", bg: "#dcfce7" },
  { key: "vegan",         label: "Vegan",         icon: "🌱", color: "#15803d", bg: "#d1fae5" },
  { key: "no_onion",      label: "No Onion",      icon: "🧅", color: "#7c3aed", bg: "#ede9fe" },
  { key: "no_tomato",     label: "No Tomato",     icon: "🍅", color: "#dc2626", bg: "#fee2e2" },
  { key: "no_croutons",   label: "No Croutons",   icon: "🍞", color: "#92400e", bg: "#fef3c7" },
  { key: "no_cheese",     label: "No Cheese",     icon: "🧀", color: "#ca8a04", bg: "#fefce8" },
  { key: "low_sodium",    label: "Low Sodium",    icon: "🧂", color: "#64748b", bg: "#f1f5f9" },
  { key: "halal",         label: "Halal",         icon: "☪️",  color: "#065f46", bg: "#d1fae5" },
  { key: "kosher",        label: "Kosher",        icon: "✡️",  color: "#1e40af", bg: "#dbeafe" },
];
const DIETARY_OPTIONS = DIETARY_DEFAULTS;


// ─── Analytics: Customer Flow Tracking ───────────────────────────────────────
function cmTrack(event, meta = {}) {
  try {
    const S = (typeof CATERME_SETTINGS !== 'undefined') ? CATERME_SETTINGS : {};
    const url = S.track_url;
    if (!url) return;
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': S.rest_nonce || '' },
      body: JSON.stringify({ event, ...meta, page_url: window.location.href }),
    }).catch(() => {}); // fire-and-forget
  } catch(e) {}
}

// ─── Menu Data (loaded from WordPress via CATERME_MENU global) ───────────────
const _menuData = (typeof CATERME_MENU !== 'undefined' && CATERME_MENU && CATERME_MENU.categories)
  ? CATERME_MENU
  : { categories: [], items: {} };

const CATEGORIES     = _menuData.categories.map(c => c.name);
const CATEGORY_ICONS = Object.fromEntries(_menuData.categories.map(c => [c.name, c.icon || '🍽️']));

// Build MENU: { "Boxes": [item,...], ... }
const MENU = {};
CATEGORIES.forEach(cat => { MENU[cat] = _menuData.items[cat] || []; });

// Collect all unique tags per category
const CATEGORY_TAGS = {};
CATEGORIES.forEach(cat => {
  const tags = [...new Set((MENU[cat] || []).map(i => i.tag).filter(Boolean))];
  CATEGORY_TAGS[cat] = tags;
});

// Auto-assign tag colors from a cycling palette
const _TAG_PALETTE = [
  { bg:"#fff3e0", color:"#b45309", border:"#f6d28a" },
  { bg:"#e8f5e9", color:"#276221", border:"#a5d6a7" },
  { bg:"#e3f2fd", color:"#1565c0", border:"#90caf9" },
  { bg:"#fce4ec", color:"#ad1457", border:"#f48fb1" },
  { bg:"#f3e5f5", color:"#6a1b9a", border:"#ce93d8" },
  { bg:"#e0f7fa", color:"#00695c", border:"#80cbc4" },
];
const TAG_COLORS = {};
let _tagIdx = 0;
CATEGORIES.forEach(cat => {
  (CATEGORY_TAGS[cat] || []).forEach(tag => {
    if (!TAG_COLORS[tag]) TAG_COLORS[tag] = _TAG_PALETTE[_tagIdx++ % _TAG_PALETTE.length];
  });
});




// ─── Helpers ──────────────────────────────────────────────────────────────────
function buildDefaultSelections(item) {
  const sel = { dietary: [] };
  (item.options || []).forEach(opt => {
    if (opt.type === "select") {
      // multi-select if max_selections > 1
      sel[opt.key] = (opt.max_selections || 1) > 1 ? [] : opt.choices[0];
    }
    if (opt.type === "toggle") sel[opt.key] = false;
    if (opt.type === "number") sel[opt.key] = opt.default || opt.min || 1;
  });
  return sel;
}

function calcItemPrice(item, selections) {
  let price = item.price;
  // Number type: price × quantity (e.g. /lb items)
  const numOpt = (item.options || []).find(o => o.type === 'number');
  if (numOpt && selections[numOpt.key]) price = item.price * selections[numOpt.key];
  // Toggle type: add option's price if enabled
  (item.options || []).forEach(opt => {
    if (opt.type === 'toggle' && selections[opt.key] && opt.price) price += parseFloat(opt.price) || 0;
  });
  // Select type: parse "+$X.XX" from choice label for inline upcharges (handles multi-select arrays)
  (item.options || []).forEach(opt => {
    if (opt.type === 'select' && selections[opt.key]) {
      const vals = Array.isArray(selections[opt.key]) ? selections[opt.key] : [selections[opt.key]];
      vals.forEach(v => {
        const m = String(v).match(/\+\$([0-9.]+)/);
        if (m) price += parseFloat(m[1]);
      });
    }
  });
  return price;
}

function formatSelections(item, selections) {
  const parts = (item.options || []).map(opt => {
    const val = selections[opt.key];
    if (opt.type === "toggle") return val ? opt.label : null;
    if (opt.type === "number") return val + " lb" + (val > 1 ? "s" : "");
    if (Array.isArray(val)) return val.length > 0 ? val.join(", ") : null;
    return val || null;
  }).filter(Boolean);
  return parts.join(" · ");
}

// ─── Theme Resolver ───────────────────────────────────────────────────────────
function resolveTheme() {
  const S = (typeof CATERME_SETTINGS !== 'undefined') ? CATERME_SETTINGS : {};
  const inherit = S.style_mode === 'inherit';
  const R = parseInt(S.border_radius || 12, 10);
  if (inherit) {
    return {
      inherit:       true,
      primary:       '',
      accent:        '',
      bg:            '',
      card:          '',
      text:          '',
      muted:         '',
      border:        '',
      headingFont:   '',
      bodyFont:      '',
      radius:        R + 'px',
      showHeader:    S.show_header !== '0',
    };
  }
  return {
    inherit:       false,
    primary:       S.color_primary    || '#1a1208',
    accent:        S.color_accent     || '#c8832a',
    bg:            S.color_bg         || '#faf7f2',
    card:          S.color_card       || '#ffffff',
    text:          S.color_text       || '#2a1f0e',
    muted:         S.color_text_muted || '#7a6040',
    border:        S.color_border     || '#e8dcc8',
    headingFont:   S.font_heading || 'Georgia, serif',
    bodyFont:      S.font_body    || 'Georgia, serif',
    radius:        R + 'px',
    showHeader:    S.show_header !== '0',
  };
}

// ─── Session Storage helpers ──────────────────────────────────────────────────
// Persists cart + checkout form across page refreshes within the same browser tab.
// sessionStorage is intentionally used (not localStorage) so data is scoped to
// the tab session — closing the tab or completing an order wipes it cleanly.

const CACHE_KEY = "caterme_order_draft";

function loadDraft() {
  try {
    const raw = sessionStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch(e) { return null; }
}

function saveDraft(state) {
  try { sessionStorage.setItem(CACHE_KEY, JSON.stringify(state)); } catch(e) {}
}

function clearDraft() {
  try { sessionStorage.removeItem(CACHE_KEY); } catch(e) {}
}

// ─── Main Component ───────────────────────────────────────────────────────────
function CateringApp() {
  // Restore draft on first render; fall back to clean defaults
  const _draft = loadDraft();

  const [activeCategory, setActiveCategory] = React.useState(CATEGORIES[0] || "");
  const [activeTag,      setActiveTag]      = React.useState("All");
  const [cart,           setCart]           = React.useState(_draft ? _draft.cart : []);
  const [configuring,    setConfiguring]    = React.useState(null);
  const [showCart,       setShowCart]       = React.useState(false);
  const [notes,          setNotes]          = React.useState(_draft ? _draft.notes : "");
  const [fulfillment,    setFulfillment]    = React.useState(_draft ? _draft.fulfillment : "pickup");
  const [orderDate,      setOrderDate]      = React.useState(_draft ? _draft.orderDate : "");
  const [orderTime,      setOrderTime]      = React.useState(_draft ? _draft.orderTime : "");
  const [customerName,   setCustomerName]   = React.useState(_draft ? _draft.customerName : "");
  const [customerPhone,  setCustomerPhone]  = React.useState(_draft ? _draft.customerPhone : "");
  const [customerEmail,  setCustomerEmail]  = React.useState(_draft ? _draft.customerEmail : "");
  const [submitState,    setSubmitState]    = React.useState("idle");
  const [submitMessage,  setSubmitMessage]  = React.useState("");
  const [tipPercent,     setTipPercent]     = React.useState(_draft ? _draft.tipPercent : null);
  const [customTip,      setCustomTip]      = React.useState(_draft ? _draft.customTip : "");
  const [deliveryAddress,setDeliveryAddress]= React.useState(_draft ? _draft.deliveryAddress : "");
  const [deliveryFee,    setDeliveryFee]    = React.useState(_draft ? (_draft.deliveryFee || 0) : 0);
  const [deliveryFeeMsg, setDeliveryFeeMsg] = React.useState(""); // status/error from fee lookup
  const [feeLoading,     setFeeLoading]     = React.useState(false);

  // Persist draft any time cart or checkout fields change
  React.useEffect(() => {
    if (cart.length === 0 && !customerName && !customerPhone && !customerEmail &&
        !notes && !orderDate && !orderTime && tipPercent === null) {
      clearDraft();
      return;
    }
    saveDraft({ cart, notes, fulfillment, orderDate, orderTime,
                customerName, customerPhone, customerEmail,
                tipPercent, customTip, deliveryAddress, deliveryFee });
  }, [cart, notes, fulfillment, orderDate, orderTime,
      customerName, customerPhone, customerEmail, tipPercent, customTip,
      deliveryAddress, deliveryFee]);

  // ── Fetch blocked dates when fulfillment changes ─────────────────────────────
  React.useEffect(function() {
    if (!S.blocked_dates_url) return;
    fetch(S.blocked_dates_url + "?fulfillment=" + fulfillment)
      .then(function(r) { return r.json(); })
      .then(function(data) {
        setBlockedDates({
          closed_days: data.closed_days || [],
          blocked_dates: data.blocked_dates || [],
        });
      })
      .catch(function() {});
  }, [fulfillment]);

  const S  = (typeof CATERME_SETTINGS !== 'undefined') ? CATERME_SETTINGS : {};
  const T  = resolveTheme();
  const F  = { heading: T.headingFont || 'Georgia, serif', body: T.bodyFont || 'Georgia, serif' };

  // ── WooCommerce mode detection ──────────────────────────────────────────────
  const useWCCart = !!(S.use_wc_cart && S.wc_checkout_url);

  // ── Blocked dates state ──────────────────────────────────────────────────────
  const [blockedDates, setBlockedDates] = React.useState({ closed_days: [], blocked_dates: [] });

  // ── Lead time: compute minimum bookable date ────────────────────────────────
  const leadHours = parseInt(S.lead_time_hours || 0, 10);
  const minDateObj = new Date(Date.now() + leadHours * 3600 * 1000);
  const minDate = minDateObj.toISOString().split("T")[0]; // YYYY-MM-DD

  // ── Delivery fee lookup (debounced 800ms) ───────────────────────────────────
  const _feeTimer = React.useRef(null);
  function lookupDeliveryFee(addr) {
    if (_feeTimer.current) clearTimeout(_feeTimer.current);
    if (!addr || !addr.trim() || !(S.delivery_fee_url)) {
      setDeliveryFee(0); setDeliveryFeeMsg(""); return;
    }
    setFeeLoading(true); setDeliveryFeeMsg("Looking up fee…");
    _feeTimer.current = setTimeout(function() {
      fetch(S.delivery_fee_url + "?address=" + encodeURIComponent(addr))
        .then(function(r) { return r.json(); })
        .then(function(data) {
          setFeeLoading(false);
          if (data.error) {
            setDeliveryFeeMsg("⚠️ " + data.error);
            setDeliveryFee(0);
          } else if (data.fee !== null) {
            setDeliveryFee(parseFloat(data.fee) || 0);
            setDeliveryFeeMsg(
              data.fee > 0
                ? "📍 " + data.miles + " mi — delivery fee: $" + parseFloat(data.fee).toFixed(2)
                : "📍 " + data.miles + " mi — free delivery"
            );
          } else {
            setDeliveryFeeMsg(""); setDeliveryFee(0);
          }
        })
        .catch(function() { setFeeLoading(false); setDeliveryFeeMsg(""); });
    }, 800);
  }

  // ── Check if date is blocked ─────────────────────────────────────────────────
  function isDateBlocked(dateStr) {
    if (!dateStr) return false;
    // Check day of week
    const d = new Date(dateStr + "T12:00:00");
    const dayOfWeek = d.toLocaleDateString("en-US", { weekday: "long" }).toLowerCase();
    if (blockedDates.closed_days.includes(dayOfWeek)) {
      return true;
    }
    // Check specific dates
    if (blockedDates.blocked_dates.includes(dateStr)) {
      return true;
    }
    return false;
  }

  // ── Load WooCommerce cart ────────────────────────────────────────────────────
  function loadWCCart() {
    if (!useWCCart || !S.wc_cart_get_url) return;
    fetch(S.wc_cart_get_url)
      .then(function(r) { return r.json(); })
      .then(function(data) {
        if (data.success && data.items) {
          const cartItems = data.items.map(function(item) {
            return {
              cart_item_key: item.cart_item_key,
              item: {
                id: item.product_id,
                name: item.name,
                price: item.price,
                options: [],
              },
              selections: item.selections || {},
              label_name: item.label_name || "",
              qty: item.quantity,
            };
          });
          setCart(cartItems);
        }
      })
      .catch(function() {});
  }

  // ── Load WC cart on mount (WC mode only) ─────────────────────────────────────
  React.useEffect(function() {
    if (useWCCart) {
      loadWCCart();
    }
  }, []);

  const catTags    = CATEGORY_TAGS[activeCategory] || [];
  const tags       = catTags.length > 0 ? ["All", ...catTags] : null;
  const visibleItems = (MENU[activeCategory] || []).filter(item =>
    !tags || activeTag === "All" || item.tag === activeTag
  );

  function openConfig(item, editIndex = null) {
    const existing = editIndex !== null ? cart[editIndex] : null;
    setConfiguring({
      item,
      selections: existing
        ? { ...existing.selections, dietary: [...(existing.selections.dietary || [])] }
        : buildDefaultSelections(item),
      label_name: existing ? (existing.label_name || "") : "",
      editIndex,
    });
  }

  function addToCart() {
    if (!configuring) return;
    const { item, selections, label_name, editIndex } = configuring;

    if (useWCCart) {
      // WooCommerce cart mode
      const dietaryArr = selections.dietary || [];
      const dietaryLabels = dietaryArr.map(function(k) {
        const d = DIETARY_OPTIONS.find(function(x) { return x.key === k; });
        return d ? d.label : k;
      });
      const dietaryStr = dietaryLabels.join(", ");

      if (editIndex !== null) {
        // Editing existing item - remove old, add new
        const oldItem = cart[editIndex];
        fetch(S.wc_cart_remove_url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ cart_item_key: oldItem.cart_item_key }),
        })
        .then(function() {
          return fetch(S.wc_cart_add_url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              product_id: item.id,
              quantity: oldItem.qty,
              selections: selections,
              label_name: label_name || "",
              dietary: dietaryStr,
            }),
          });
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
          if (data.success) {
            loadWCCart();
            setConfiguring(null);
          }
        })
        .catch(function() {});
      } else {
        // Adding new item
        fetch(S.wc_cart_add_url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            product_id: item.id,
            quantity: 1,
            selections: selections,
            label_name: label_name || "",
            dietary: dietaryStr,
          }),
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
          if (data.success) {
            loadWCCart();
            setShowCart(true);
          }
        })
        .catch(function() {});
        setConfiguring(null);
      }
    } else {
      // Session storage mode (original)
      const entry = { item, selections, label_name: label_name || "", qty: editIndex !== null ? cart[editIndex].qty : 1 };
      if (editIndex !== null) {
        setCart(c => c.map((v,i) => i === editIndex ? entry : v));
      } else {
        cmTrack("item_added_to_cart", {
          item_name:  item.name,
          item_price: calcItemPrice(item, selections),
        });
        setCart(c => [...c, entry]);
      }
      setConfiguring(null);
    }
  }

  function removeFromCart(idx) {
    if (useWCCart) {
      const item = cart[idx];
      fetch(S.wc_cart_remove_url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cart_item_key: item.cart_item_key }),
      })
      .then(function() { loadWCCart(); })
      .catch(function() {});
    } else {
      setCart(c => c.filter((_,i) => i !== idx));
    }
  }

  function updateQty(idx, delta) {
    if (useWCCart) {
      const item = cart[idx];
      const newQty = item.qty + delta;
      if (newQty < 1) {
        removeFromCart(idx);
      } else {
        fetch(S.wc_cart_update_url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            cart_item_key: item.cart_item_key,
            quantity: newQty,
          }),
        })
        .then(function() { loadWCCart(); })
        .catch(function() {});
      }
    } else {
      setCart(c => c.map((v,i) => {
        if (i !== idx) return v;
        const q = v.qty + delta;
        return q < 1 ? null : { ...v, qty: q };
      }).filter(Boolean));
    }
  }

  function toggleDietary(key) {
    setConfiguring(c => {
      const cur  = c.selections.dietary || [];
      const next = cur.includes(key) ? cur.filter(k => k !== key) : [...cur, key];
      return { ...c, selections: { ...c.selections, dietary: next } };
    });
  }

  async function submitOrder() {
    // ── WooCommerce checkout mode ─────────────────────────────────────────────
    if (useWCCart) {
      // Validate required fields
      if (!customerName || !customerPhone) {
        setSubmitMessage("Please fill in your name and phone number.");
        setSubmitState("error");
        return;
      }
      if (!orderDate || !orderTime) {
        setSubmitMessage("Please select a date and time.");
        setSubmitState("error");
        return;
      }
      if (fulfillment === "delivery" && !deliveryAddress) {
        setSubmitMessage("Please enter a delivery address.");
        setSubmitState("error");
        return;
      }

      // Validate date not blocked
      if (isDateBlocked(orderDate)) {
        setSubmitMessage((fulfillment === "delivery" ? "Delivery" : "Pickup") + " is not available on the selected date.");
        setSubmitState("error");
        return;
      }

      // Validate lead time
      if (leadHours > 0 && orderDate && orderTime) {
        const orderDt = new Date(orderDate + "T" + orderTime + ":00");
        const minAllowed = new Date(Date.now() + leadHours * 3600 * 1000);
        if (orderDt < minAllowed) {
          setSubmitMessage("Orders require at least " + leadHours + " hour" + (leadHours === 1 ? "" : "s") + " advance notice. Please choose a later date/time.");
          setSubmitState("error");
          return;
        }
      }

      // Store checkout data in sessionStorage to populate WC checkout fields
      sessionStorage.setItem("caterme_checkout_data", JSON.stringify({
        fulfillment:     fulfillment,
        orderDate:       orderDate,
        orderTime:       orderTime,
        deliveryAddress: fulfillment === "delivery" ? deliveryAddress : "",
        tipAmount:       tipAmount,
        customerName:    customerName,
        customerPhone:   customerPhone,
        customerEmail:   customerEmail,
      }));

      // Redirect to WC checkout
      setSubmitState("redirecting");
      setSubmitMessage("Taking you to checkout...");
      setTimeout(function() {
        window.location.href = S.wc_checkout_url;
      }, 500);
      return;
    }

    // ── REST submission mode (original) ───────────────────────────────────────
    const restUrl = S.rest_url || '';
    const nonce   = S.rest_nonce || '';
    if (!restUrl) {
      setSubmitState("error");
      setSubmitMessage("Submission endpoint not configured. Please contact the site administrator.");
      return;
    }
    cmTrack("checkout_started", {
      cart_count: cart.length,
      cart_total: parseFloat(subtotal.toFixed(2)),
      fulfillment,
    });
    setSubmitState("loading");

    // Build items payload
    const items = cart.map(entry => {
      const sels = [];
      (entry.item.options || []).forEach(opt => {
        const val = entry.selections[opt.key];
        if (opt.type === "toggle") { if (val) sels.push(opt.label); }
        else if (opt.type === "number") { sels.push(val + " lb" + (val > 1 ? "s" : "")); }
        else if (Array.isArray(val)) { val.forEach(v => sels.push(v)); }
        else if (val) { sels.push(val); }
      });
      const dietaryArr = entry.selections.dietary || [];
      const dietaryLabels = dietaryArr.map(k => {
        const d = DIETARY_OPTIONS.find(x => x.key === k);
        return d ? d.label : k;
      });
      return {
        name:       entry.item.name,
        qty:        entry.qty,
        price:      calcItemPrice(entry.item, entry.selections),
        selections: sels,
        dietary:    dietaryLabels,
        label_name: entry.label_name || "",
      };
    });

    const payload = {
      timestamp:        new Date().toISOString(),
      fulfillment,      orderDate, orderTime,
      subtotal:         parseFloat(subtotal.toFixed(2)),
      tip:              parseFloat(tipAmount.toFixed(2)),
      delivery_address: fulfillment === "delivery" ? deliveryAddress : "",
      delivery_fee:     fulfillment === "delivery" ? parseFloat(deliveryFee.toFixed(2)) : 0,
      notes,            items,
      customer_name:    customerName,
      customer_phone:   customerPhone,
      customer_email:   customerEmail,
    };

    try {
      const res = await fetch(restUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-WP-Nonce": nonce },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (res.ok && json.success) {
        if (json.payment_url) {
          // Redirect to WooCommerce checkout payment page
          setSubmitState("redirecting");
          setSubmitMessage("Redirecting to secure payment...");
          clearDraft();
          setTimeout(() => { window.location.href = json.payment_url; }, 800);
        } else {
          cmTrack("order_confirmed_by_customer", {
            order_number: json.order_number || "",
            fulfillment,
            cart_total: parseFloat(subtotal.toFixed(2)),
          });
          setSubmitState("success");
          setSubmitMessage(json.message || "Order received!");
          clearDraft();
          setCart([]);
          setNotes(""); setOrderDate(""); setOrderTime(""); setFulfillment("pickup");
          setCustomerName(""); setCustomerPhone(""); setCustomerEmail("");
          setTipPercent(null); setCustomTip("");
        }
      } else {
        setSubmitState("error");
        setSubmitMessage("Something went wrong: " + (json.message || "Unknown error"));
      }
    } catch(err) {
      setSubmitState("error");
      const phone = S.store_phone ? " or call " + S.store_phone : "";
      setSubmitMessage("Network error. Please try again" + phone + ".");
    }
  }

  const subtotal   = cart.reduce((s,e) => s + calcItemPrice(e.item, e.selections) * e.qty, 0);
  const cartCount  = cart.reduce((s,e) => s + e.qty, 0);
  // Tip calculation
  const tipEnabled  = S.tip_enabled !== '0';
  const tipPresets  = tipEnabled ? (S.tip_presets || '15,20,25').split(',').map(Number).filter(Boolean) : [];
  const tipAmount   = (() => {
    if (!tipEnabled || tipPercent === null) return 0;
    if (tipPercent === 'custom') return parseFloat(customTip) || 0;
    return parseFloat((subtotal * tipPercent / 100).toFixed(2));
  })();
  const orderTotal  = subtotal + tipAmount;

  // ── Render ──────────────────────────────────────────────────────────────────
    // Order intake is always unlimited — no frontend banner needed.
  const _planBanner = null;

  return React.createElement("div", { style: Object.assign({ minHeight: 400, position: "relative" }, T.bg ? { background: T.bg } : {}, T.text ? { color: T.text } : {}, { fontFamily: F.body }) },

    // Freemium orders remaining banner
    _planBanner,

    // Test Mode Banner
    S.test_mode && React.createElement("div", { style: { background: "#d97706", color: "#fff", padding: "10px 18px", display: "flex", alignItems: "center", gap: 10, fontSize: 13, fontWeight: 700, letterSpacing: 0.3 } },
      React.createElement("span", { style: { fontSize: 16 } }, "🧪"),
      "TEST MODE — Orders are saved but no payment will be collected.",
      React.createElement("span", { style: { marginLeft: "auto", fontWeight: 400, fontSize: 12, opacity: 0.85 } }, "Disable in CaterMe → Settings")
    ),

    // Header (only shown when showHeader is true)
    T.showHeader && React.createElement("div", { style: Object.assign({ padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }, T.primary ? { background: T.primary } : { background: "#1a1208" }) },
      React.createElement("div", null,
        React.createElement("p", { style: { fontFamily: F.heading, fontSize: 24, fontWeight: 900, color: "#f5e6c8", letterSpacing: 2, textTransform: "uppercase", margin: 0 } }, (S.store_name || "CaterMe").toUpperCase()),
        React.createElement("p", { style: { fontFamily: F.body, fontSize: 11, color: "#b8996a", letterSpacing: 3, textTransform: "uppercase", margin: 0 } }, "Catering Order Form")
      ),
      React.createElement("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
        // Cart button
        React.createElement("button", {
          onClick: () => setShowCart(true),
          style: { background: T.accent || "#c8832a", border: "none", borderRadius: 30, padding: "9px 18px", color: "#fff", cursor: "pointer", fontSize: 14, fontWeight: 700, display: "flex", alignItems: "center", gap: 8, fontFamily: F.body }
        },
          React.createElement("span", null, "🛒"),
          React.createElement("span", null, "Order (" + cartCount + ")"),
          subtotal > 0 && React.createElement("span", { style: { background: "rgba(255,255,255,0.18)", borderRadius: 20, padding: "2px 8px" } }, "$" + orderTotal.toFixed(2))
        )
      )
    ),

    // Cart button when header is hidden
    !T.showHeader && React.createElement("div", { style: { padding: "12px 20px", display: "flex", justifyContent: "flex-end" } },
      React.createElement("button", {
        onClick: () => setShowCart(true),
        style: { background: T.accent || "#c8832a", border: "none", borderRadius: 30, padding: "9px 18px", color: "#fff", cursor: "pointer", fontSize: 14, fontWeight: 700, display: "flex", alignItems: "center", gap: 8, fontFamily: F.body }
      },
        React.createElement("span", null, "🛒"),
        React.createElement("span", null, "Order (" + cartCount + ")"),
        subtotal > 0 && React.createElement("span", { style: { background: "rgba(0,0,0,0.15)", borderRadius: 20, padding: "2px 8px" } }, "$" + orderTotal.toFixed(2))
      )
    ),

    // Category Tabs
    React.createElement("div", { style: { display: "flex", gap: 6, overflowX: "auto", padding: "16px 20px 0", scrollbarWidth: "none" } },
      CATEGORIES.map(cat => React.createElement("button", {
        key: cat,
        onClick: () => { setActiveCategory(cat); setActiveTag("All"); },
        style: { fontFamily: F.body, background: activeCategory === cat ? (T.primary || "#1a1208") : (T.card || "#fff"), color: activeCategory === cat ? "#f5e6c8" : (T.muted || "#5a3e20"), border: "2px solid " + (activeCategory === cat ? (T.primary||"#1a1208") : (T.border||"#ddd0b8")), borderRadius: 30, padding: "7px 16px", cursor: "pointer", whiteSpace: "nowrap", fontSize: 13, fontWeight: 600 }
      }, CATEGORY_ICONS[cat] + " " + cat))
    ),

    // Sub-tags
    tags && React.createElement("div", { style: { display: "flex", gap: 6, padding: "10px 20px 0", flexWrap: "wrap" } },
      tags.map(t => {
        const c = TAG_COLORS[t] || { bg: "#f0f0f0", color: "#444", border: "#ccc" };
        const active = activeTag === t;
        return React.createElement("button", {
          key: t, onClick: () => setActiveTag(t),
          style: { fontFamily: F.body, background: active ? (t === "All" ? (T.primary||"#1a1208") : c.bg) : (T.card||"#fff"), color: active ? (t === "All" ? "#f5e6c8" : c.color) : (T.muted||"#888"), border: "1.5px solid " + (active ? (t === "All" ? (T.primary||"#1a1208") : c.border) : (T.border||"#e0d0b8")), borderRadius: 20, padding: "5px 13px", cursor: "pointer", fontSize: 12, fontWeight: active ? 700 : 500 }
        }, t === "All" ? "All " + activeCategory : t);
      })
    ),

    // Item Grid — columns controlled by settings
    React.createElement("div", { style: {
        display: "grid",
        gridTemplateColumns: "repeat(" + parseInt(S.menu_columns || 2, 10) + ", minmax(0, 1fr))",
        gap: 14, padding: "14px 20px 30px"
      } },
      visibleItems.length === 0
        ? React.createElement("div", { style: { gridColumn: "1/-1", textAlign: "center", padding: "48px 20px", color: T.muted||"#a07848" } },
            React.createElement("div", { style: { fontSize: 40, marginBottom: 10 } }, "🍽️"),
            React.createElement("p", { style: { fontSize: 15, margin: 0 } }, CATEGORIES.length === 0
              ? "No menu items yet — add items in the CaterMe admin panel."
              : "No items in this category yet."
            )
          )
        : visibleItems.map(item => React.createElement("div", { key: item.id, style: Object.assign({ padding: "18px", display: "flex", flexDirection: "column", boxShadow: "0 1px 4px rgba(0,0,0,0.05)", borderRadius: T.radius }, T.card ? { background: T.card } : {}, T.border ? { border: "1px solid " + T.border } : { border: "1px solid #e8dcc8" }) },
          // Product image
          item.image && React.createElement("div", { style: { width: "100%", height: 180, borderRadius: T.radius||"8px", overflow: "hidden", marginBottom: 12, background: "#f5f5f5" } },
            React.createElement("img", { src: item.image, alt: item.name, style: { width: "100%", height: "100%", objectFit: "cover" } })
          ),
          React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 } },
            React.createElement("span", { style: { fontFamily: F.heading, fontSize: 15, fontWeight: 800, color: T.text||"#1a1208", lineHeight: 1.3, flex: 1, paddingRight: 8 } }, item.name),
            React.createElement("span", { style: { fontFamily: F.body, fontSize: 17, fontWeight: 900, color: T.accent||"#c8832a", whiteSpace: "nowrap" } }, "$" + item.price.toFixed(2) + (item.unit || ""))
          ),
          item.tag && TAG_COLORS[item.tag] && React.createElement("span", { style: { ...TAG_COLORS[item.tag], fontSize: 10, fontWeight: 700, borderRadius: 20, padding: "2px 9px", alignSelf: "flex-start", border: "1px solid " + TAG_COLORS[item.tag].border, marginBottom: 6, fontFamily: F.body } }, item.tag),
          React.createElement("p", { style: { fontFamily: F.body, fontSize: 12, color: T.muted||"#7a6040", lineHeight: 1.6, flex: 1, margin: "0 0 10px" } }, item.description),
          item.options.length > 0 && React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 10 } },
            item.options.map(opt => React.createElement("span", { key: opt.key, style: { background: "#faf0e0", border: "1px solid #e8d4a8", borderRadius: 20, padding: "2px 8px", fontSize: 11, color: "#a07848", fontFamily: F.body } }, opt.label))
          ),
          React.createElement("button", {
            onClick: () => openConfig(item),
            style: { fontFamily: F.body, background: T.primary||"#1a1208", color: "#f5e6c8", border: "none", borderRadius: T.radius||"8px", padding: "10px 14px", cursor: "pointer", fontSize: 13, fontWeight: 700, marginTop: "auto" }
          }, item.options.length > 0 ? "Customize & Add" : "Add to Order")
        ))
    ),

    // Customize Modal
    configuring && React.createElement("div", {
      style: { position: "fixed", inset: 0, background: "rgba(10,6,2,0.65)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 },
      onClick: () => setConfiguring(null)
    },
      React.createElement("div", {
        style: { fontFamily: F.body, background: T.card||"#fff", borderRadius: T.radius, padding: "24px", maxWidth: 460, width: "100%", boxShadow: "0 20px 60px rgba(0,0,0,0.35)", maxHeight: "90vh", overflowY: "auto" },
        onClick: e => e.stopPropagation()
      },
        // Product image in modal
        configuring.item.image && React.createElement("div", { style: { width: "100%", height: 200, borderRadius: T.radius||"8px", overflow: "hidden", marginBottom: 16, background: "#f5f5f5" } },
          React.createElement("img", { src: configuring.item.image, alt: configuring.item.name, style: { width: "100%", height: "100%", objectFit: "cover" } })
        ),
        // Modal Header
        React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 } },
          React.createElement("p", { style: { fontFamily: F.heading, fontSize: 18, fontWeight: 800, color: T.text||"#1a1208", margin: 0, flex: 1, paddingRight: 10 } }, configuring.item.name),
          React.createElement("button", { onClick: () => setConfiguring(null), style: { background: "none", border: "none", cursor: "pointer", fontSize: 22, color: "#999" } }, "×")
        ),
        React.createElement("p", { style: { fontSize: 12, color: T.muted||"#7a6040", marginBottom: 18, lineHeight: 1.6 } }, configuring.item.description),

        // Standard options
        configuring.item.options.map(opt => React.createElement("div", { key: opt.key, style: { marginBottom: 16 } },
          React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 7 } },
            opt.label, opt.required && React.createElement("span", { style: { color: T.accent||"#c8832a" } }, " *")
          ),
          opt.type === "select" && React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 6 } },
            (() => {
              // Count how many select-type opts for this option group are selected
              const maxSel = opt.max_selections || 0; // 0 = unlimited
              const curSels = Array.isArray(configuring.selections[opt.key])
                ? configuring.selections[opt.key]
                : (configuring.selections[opt.key] ? [configuring.selections[opt.key]] : []);
              const isMulti = maxSel !== 1;
              return opt.choices.map(choice => {
                const active = isMulti
                  ? curSels.includes(choice)
                  : configuring.selections[opt.key] === choice;
                const atLimit = isMulti && maxSel > 0 && curSels.length >= maxSel && !active;
                return React.createElement("button", {
                  key: choice,
                  onClick: () => {
                    if (atLimit) return;
                    setConfiguring(c => {
                      if (!isMulti) return { ...c, selections: { ...c.selections, [opt.key]: choice } };
                      const prev = Array.isArray(c.selections[opt.key]) ? c.selections[opt.key] : (c.selections[opt.key] ? [c.selections[opt.key]] : []);
                      const next = prev.includes(choice) ? prev.filter(x => x !== choice) : [...prev, choice];
                      return { ...c, selections: { ...c.selections, [opt.key]: next } };
                    });
                  },
                  style: { fontFamily: F.body, padding: "7px 12px", fontSize: 12.5, borderRadius: "8px", cursor: atLimit ? "not-allowed" : "pointer", opacity: atLimit ? 0.45 : 1, border: active ? "2px solid " + (T.accent||"#c8832a") : "2px solid " + (T.border||"#e0d0b8"), background: active ? "#fff7ed" : (T.bg||"#faf7f2"), color: active ? (T.accent||"#c8832a") : (T.muted||"#5a3e20"), fontWeight: active ? 700 : 400 }
                }, choice);
              });
            })(),
            opt.max_selections > 1 && React.createElement("span", { style: { width: "100%", fontSize: 11, color: T.muted||"#a07848", marginTop: 2 } },
              "Choose up to " + opt.max_selections
            )
          ),
          opt.type === "toggle" && React.createElement("button", {
            onClick: () => setConfiguring(c => ({ ...c, selections: { ...c.selections, [opt.key]: !c.selections[opt.key] } })),
            style: { fontFamily: F.body, padding: "7px 14px", fontSize: 12.5, borderRadius: "8px", cursor: "pointer", border: configuring.selections[opt.key] ? "2px solid " + (T.accent||"#c8832a") : "2px solid " + (T.border||"#e0d0b8"), background: configuring.selections[opt.key] ? "#fff7ed" : (T.bg||"#faf7f2"), color: configuring.selections[opt.key] ? (T.accent||"#c8832a") : (T.muted||"#5a3e20"), fontWeight: configuring.selections[opt.key] ? 700 : 400 }
          }, configuring.selections[opt.key] ? "✓ " + opt.label : opt.label),
          opt.type === "number" && React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
            React.createElement("button", { onClick: () => setConfiguring(c => ({ ...c, selections: { ...c.selections, [opt.key]: Math.max(opt.min||1, c.selections[opt.key]-1) } })), style: { width: 32, height: 32, borderRadius: "8px", border: "1.5px solid " + (T.border||"#e0d0b8"), background: T.bg||"#faf7f2", cursor: "pointer", fontSize: 17, fontWeight: 700, color: T.muted||"#5a3e20" } }, "−"),
            React.createElement("span", { style: { fontSize: 17, fontWeight: 700, minWidth: 20, textAlign: "center" } }, configuring.selections[opt.key]),
            React.createElement("button", { onClick: () => setConfiguring(c => ({ ...c, selections: { ...c.selections, [opt.key]: c.selections[opt.key]+1 } })), style: { width: 32, height: 32, borderRadius: "8px", border: "1.5px solid " + (T.border||"#e0d0b8"), background: T.bg||"#faf7f2", cursor: "pointer", fontSize: 17, fontWeight: 700, color: T.muted||"#5a3e20" } }, "+"),
            React.createElement("span", { style: { fontSize: 13, color: T.muted||"#a07848" } }, "lbs")
          )
        )),

        // Label Name Field
        React.createElement("div", { style: { marginTop: 6, paddingTop: 14, borderTop: "1px solid " + (T.border||"#f0e8d8") } },
          React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 7 } },
            "🏷️ Label Name ",
            React.createElement("span", { style: { color: "#aaa", fontWeight: 400, textTransform: "none", letterSpacing: 0, fontSize: 11 } }, "(printed on label — e.g. a person's name)")
          ),
          React.createElement("input", {
            type: "text",
            value: configuring.label_name || "",
            onChange: e => setConfiguring(c => ({ ...c, label_name: e.target.value })),
            placeholder: "e.g. John, Table 3, Gluten-Free Guest...",
            maxLength: 40,
            style: { fontFamily: F.body, width: "100%", border: "2px solid " + (T.border||"#e0d0b8"), borderRadius: "8px", padding: "9px 12px", fontSize: 13, color: T.text||"#1a1208", background: T.bg||"#faf7f2", boxSizing: "border-box", outline: "none" }
          })
        ),

        // Dietary Restrictions Section
        React.createElement("div", { style: { marginTop: 6, paddingTop: 14, borderTop: "1px solid " + (T.border||"#f0e8d8") } },
          React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 10 } },
            "Dietary Restrictions / Allergies ",
            React.createElement("span", { style: { color: "#aaa", fontWeight: 400, textTransform: "none", letterSpacing: 0, fontSize: 11 } }, "(select all that apply)")
          ),
          React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 7 } },
            DIETARY_OPTIONS.map(d => {
              const active = (configuring.selections.dietary || []).includes(d.key);
              return React.createElement("button", {
                key: d.key, onClick: () => toggleDietary(d.key),
                style: { fontFamily: F.body, padding: "6px 11px", fontSize: 12, borderRadius: 20, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, border: active ? "2px solid " + d.color : "1.5px solid " + (T.border||"#e0d0b8"), background: active ? d.bg : (T.bg||"#faf7f2"), color: active ? d.color : (T.muted||"#7a6040"), fontWeight: active ? 700 : 400 }
              }, d.icon + " " + d.label);
            })
          )
        ),

        // Modal Footer
        React.createElement("div", { style: { borderTop: "1px solid " + (T.border||"#e8dcc8"), paddingTop: 14, marginTop: 16, display: "flex", justifyContent: "space-between", alignItems: "center" } },
          React.createElement("span", { style: { fontFamily: F.heading, fontSize: 20, fontWeight: 800, color: T.accent||"#c8832a" } }, "$" + calcItemPrice(configuring.item, configuring.selections).toFixed(2)),
          React.createElement("button", {
            onClick: addToCart,
            style: { fontFamily: F.body, background: T.accent||"#c8832a", color: "#fff", border: "none", borderRadius: T.radius||"10px", padding: "12px 26px", cursor: "pointer", fontSize: 14, fontWeight: 700 }
          }, configuring.editIndex !== null ? "Update Item" : "Add to Order")
        )
      )
    ),

    // Cart Drawer
    showCart && React.createElement("div", {
      style: { position: "fixed", inset: 0, background: "rgba(10,6,2,0.55)", zIndex: 9998 },
      onClick: () => setShowCart(false)
    },
      React.createElement("div", {
        style: { fontFamily: F.body, position: "fixed", top: 0, right: 0, bottom: 0, width: "min(420px, 100vw)", background: T.bg||"#faf7f2", zIndex: 10000, overflowY: "auto", padding: "22px 18px", boxShadow: "-8px 0 40px rgba(0,0,0,0.2)" },
        onClick: e => e.stopPropagation()
      },
        React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 } },
          React.createElement("p", { style: { fontFamily: F.heading, fontSize: 20, fontWeight: 900, color: T.text||"#1a1208", margin: 0 } }, "Your Order"),
          React.createElement("button", { onClick: () => setShowCart(false), style: { background: "none", border: "none", cursor: "pointer", fontSize: 24, color: "#999" } }, "×")
        ),
        cart.length === 0
          ? React.createElement("div", { style: { textAlign: "center", color: T.muted||"#a07848", padding: "50px 0" } },
              React.createElement("div", { style: { fontSize: 36, marginBottom: 10 } }, "🥡"),
              "Your order is empty.",
              React.createElement("br"),
              "Browse the menu to get started!"
            )
          : React.createElement(React.Fragment, null,
              cart.map((entry, idx) => React.createElement("div", { key: idx, style: { background: T.card||"#fff", borderRadius: T.radius, padding: "13px", marginBottom: 10, border: "1px solid " + (T.border||"#e8dcc8") } },
                React.createElement("div", { style: { display: "flex", gap: 12, justifyContent: "space-between", alignItems: "flex-start" } },
                  // Item thumbnail
                  entry.item.image && React.createElement("div", { style: { width: 70, height: 70, flexShrink: 0, borderRadius: "6px", overflow: "hidden", background: "#f5f5f5" } },
                    React.createElement("img", { src: entry.item.image, alt: entry.item.name, style: { width: "100%", height: "100%", objectFit: "cover" } })
                  ),
                  React.createElement("div", { style: { flex: 1, minWidth: 0 } },
                    React.createElement("p", { style: { fontFamily: F.heading, fontWeight: 700, fontSize: 13.5, color: T.text||"#1a1208", margin: "0 0 3px" } }, entry.item.name),
                    entry.label_name && React.createElement("p", { style: { fontSize: 11.5, color: T.accent||"#c8832a", fontWeight: 700, margin: "0 0 3px", display: "flex", alignItems: "center", gap: 4 } },
                      "🏷️ ", entry.label_name
                    ),
                    React.createElement("p", { style: { fontSize: 11.5, color: T.muted||"#8a6a3a", margin: "0 0 3px", lineHeight: 1.5 } }, formatSelections(entry.item, entry.selections)),
                    entry.selections.dietary && entry.selections.dietary.length > 0 &&
                      React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 3, margin: "4px 0" } },
                        entry.selections.dietary.map(k => {
                          const d = DIETARY_OPTIONS.find(x => x.key === k);
                          return d ? React.createElement("span", { key: k, style: { fontSize: 10, padding: "1px 7px", borderRadius: 20, background: d.bg, color: d.color, border: "1px solid " + d.color + "40", fontWeight: 600 } }, d.icon + " " + d.label) : null;
                        })
                      ),
                    React.createElement("p", { style: { fontSize: 13, color: T.accent||"#c8832a", fontWeight: 700, margin: "4px 0 0" } }, "$" + (calcItemPrice(entry.item, entry.selections) * entry.qty).toFixed(2))
                  ),
                  React.createElement("div", { style: { display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6, marginLeft: 8 } },
                    React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 7 } },
                      React.createElement("button", { onClick: () => updateQty(idx,-1), style: { width: 26, height: 26, borderRadius: "6px", border: "1.5px solid " + (T.border||"#e0d0b8"), background: T.bg||"#faf7f2", cursor: "pointer", fontSize: 14, fontWeight: 700, color: T.muted||"#5a3e20" } }, "−"),
                      React.createElement("span", { style: { fontSize: 14, fontWeight: 700, minWidth: 16, textAlign: "center" } }, entry.qty),
                      React.createElement("button", { onClick: () => updateQty(idx,1), style: { width: 26, height: 26, borderRadius: "6px", border: "1.5px solid " + (T.border||"#e0d0b8"), background: T.bg||"#faf7f2", cursor: "pointer", fontSize: 14, fontWeight: 700, color: T.muted||"#5a3e20" } }, "+")
                    ),
                    React.createElement("div", { style: { display: "flex", gap: 8 } },
                      React.createElement("button", { onClick: () => { setShowCart(false); openConfig(entry.item, idx); }, style: { background: "none", border: "none", cursor: "pointer", fontSize: 11, color: T.muted||"#a07848", textDecoration: "underline" } }, "Edit"),
                      React.createElement("button", { onClick: () => removeFromCart(idx), style: { background: "none", border: "none", cursor: "pointer", fontSize: 11, color: "#cc3333", textDecoration: "underline" } }, "Remove")
                    )
                  )
                )
              )),

              // Pickup / Delivery
              React.createElement("div", { style: { marginTop: 18 } },
                React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 } }, "Order Type"),
                React.createElement("div", { style: { display: "flex", gap: 8 } },
                  React.createElement("button", {
                    onClick: () => setFulfillment("pickup"),
                    style: { flex: 1, padding: "10px 8px", borderRadius: T.radius||"8px", cursor: "pointer", fontFamily: F.body, fontSize: 13, fontWeight: 700,
                      border: fulfillment === "pickup" ? "2px solid " + (T.accent||"#c8832a") : "2px solid " + (T.border||"#e0d0b8"),
                      background: fulfillment === "pickup" ? "#fff7ed" : (T.card||"#fff"),
                      color: fulfillment === "pickup" ? (T.accent||"#c8832a") : (T.muted||"#5a3e20") }
                  }, "🏪 Pick Up"),
                  React.createElement("button", {
                    onClick: () => setFulfillment("delivery"),
                    style: { flex: 1, padding: "10px 8px", borderRadius: T.radius||"8px", cursor: "pointer", fontFamily: F.body, fontSize: 13, fontWeight: 700,
                      border: fulfillment === "delivery" ? "2px solid " + (T.accent||"#c8832a") : "2px solid " + (T.border||"#e0d0b8"),
                      background: fulfillment === "delivery" ? "#fff7ed" : (T.card||"#fff"),
                      color: fulfillment === "delivery" ? (T.accent||"#c8832a") : (T.muted||"#5a3e20") }
                  }, "🚗 Delivery")
                ),
                fulfillment === "pickup" && S.store_address &&
                  React.createElement("p", { style: { fontSize: 11.5, color: T.muted||"#a07848", margin: "7px 0 0", lineHeight: 1.5 } }, "📍 " + S.store_address),
                fulfillment === "delivery" &&
                  React.createElement("div", { style: { marginTop: 10 } },
                    React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 } },
                      "🏠 Delivery Address"
                    ),
                    React.createElement("input", {
                      type: "text",
                      value: deliveryAddress,
                      onChange: e => {
                        setDeliveryAddress(e.target.value);
                        lookupDeliveryFee(e.target.value);
                      },
                      placeholder: "Street address, City, State, ZIP",
                      style: { fontFamily: F.body, width: "100%", border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "9px 11px", fontSize: 13, color: T.text||"#2a1f0e", background: T.card||"#fff", boxSizing: "border-box" }
                    }),
                    deliveryFeeMsg && React.createElement("p", {
                      style: { fontSize: 11.5, margin: "5px 0 0", lineHeight: 1.5,
                               color: deliveryFeeMsg.startsWith("⚠️") ? "#cc3333" : (T.muted||"#a07848") }
                    }, feeLoading ? "⏳ " + deliveryFeeMsg : deliveryFeeMsg),
                    !S.delivery_fee_url && React.createElement("p", { style: { fontSize: 11.5, color: T.muted||"#a07848", margin: "5px 0 0", lineHeight: 1.5 } },
                      "Delivery fee dependent on location. We'll confirm details after you submit."
                    )
                  )
              ),

              // Date & Time
              React.createElement("div", { style: { marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 } },
                React.createElement("div", null,
                  React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 } }, fulfillment === "pickup" ? "Pick Up Date" : "Delivery Date"),
                  React.createElement("input", { type: "date", value: orderDate, onChange: e => setOrderDate(e.target.value), min: minDate, style: { fontFamily: F.body, width: "100%", border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "9px 10px", fontSize: 13, color: T.text||"#2a1f0e", background: T.card||"#fff", boxSizing: "border-box" } })
                ),
                React.createElement("div", null,
                  React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 } }, fulfillment === "pickup" ? "Pick Up Time" : "Delivery Time"),
                  React.createElement("input", { type: "time", value: orderTime, onChange: e => setOrderTime(e.target.value), style: { fontFamily: F.body, width: "100%", border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "9px 10px", fontSize: 13, color: T.text||"#2a1f0e", background: T.card||"#fff", boxSizing: "border-box" } })
                )
              ),
              leadHours > 0 && React.createElement("p", { style: { fontSize: 11, color: T.muted||"#a07848", margin: "4px 0 0" } },
                "⏱️ Orders require at least " + leadHours + " hour" + (leadHours === 1 ? "" : "s") + " advance notice."
              ),
              orderDate && isDateBlocked(orderDate) && React.createElement("p", { style: { fontSize: 12, color: "#cc3333", fontWeight: 600, margin: "6px 0 0", padding: "6px 10px", background: "#fee", borderRadius: "4px", border: "1px solid #fcc" } },
                "⚠️ " + (fulfillment === "delivery" ? "Delivery" : "Pickup") + " is not available on this date. Please choose another."
              ),

              // Customer Info
              React.createElement("div", { style: { marginTop: 14 } },
                React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 } }, "Your Information"),
                React.createElement("input", { type: "text", value: customerName, onChange: e => setCustomerName(e.target.value), placeholder: "Full Name *", style: { fontFamily: F.body, width: "100%", border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "9px 11px", fontSize: 13, color: T.text||"#2a1f0e", background: T.card||"#fff", boxSizing: "border-box", marginBottom: 8 } }),
                React.createElement("input", { type: "tel", value: customerPhone, onChange: e => setCustomerPhone(e.target.value), placeholder: "Phone Number *", style: { fontFamily: F.body, width: "100%", border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "9px 11px", fontSize: 13, color: T.text||"#2a1f0e", background: T.card||"#fff", boxSizing: "border-box", marginBottom: 8 } }),
                React.createElement("input", { type: "email", value: customerEmail, onChange: e => setCustomerEmail(e.target.value), placeholder: "Email Address", style: { fontFamily: F.body, width: "100%", border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "9px 11px", fontSize: 13, color: T.text||"#2a1f0e", background: T.card||"#fff", boxSizing: "border-box" } })
              ),

              // Notes
              React.createElement("div", { style: { marginTop: 14 } },
                React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 } }, "Special Notes / Allergies"),
                React.createElement("textarea", { value: notes, onChange: e => setNotes(e.target.value), rows: 3, placeholder: fulfillment === "delivery" ? "Delivery address and any special requests..." : "Any special requests or notes...", style: { fontFamily: F.body, width: "100%", border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "9px 11px", fontSize: 13, color: T.text||"#2a1f0e", background: T.card||"#fff", resize: "none", boxSizing: "border-box" } })
              ),

              // Tip Section
              tipEnabled && React.createElement("div", { style: { marginTop: 14 } },
                React.createElement("label", { style: { display: "block", fontSize: 11, fontWeight: 700, color: T.muted||"#5a3e20", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 } }, "💰 Add a Tip"),
                React.createElement("div", { style: { display: "flex", gap: 6, flexWrap: "wrap" } },
                  tipPresets.map(pct =>
                    React.createElement("button", {
                      key: pct,
                      onClick: () => { setTipPercent(tipPercent === pct ? null : pct); setCustomTip(""); },
                      style: { fontFamily: F.body, flex: 1, minWidth: 52, padding: "8px 4px", fontSize: 13, fontWeight: 700, borderRadius: T.radius||"8px", cursor: "pointer",
                        border: tipPercent === pct ? "2px solid " + (T.accent||"#c8832a") : "1.5px solid " + (T.border||"#e0d0b8"),
                        background: tipPercent === pct ? "#fff7ed" : (T.card||"#fff"),
                        color: tipPercent === pct ? (T.accent||"#c8832a") : (T.muted||"#5a3e20")
                      }
                    },
                      pct + "%",
                      React.createElement("br"),
                      React.createElement("span", { style: { fontSize: 11, fontWeight: 400 } }, "$" + (subtotal * pct / 100).toFixed(2))
                    )
                  ),
                  React.createElement("button", {
                    onClick: () => { setTipPercent(tipPercent === "custom" ? null : "custom"); },
                    style: { fontFamily: F.body, flex: 1, minWidth: 52, padding: "8px 4px", fontSize: 13, fontWeight: 700, borderRadius: T.radius||"8px", cursor: "pointer",
                      border: tipPercent === "custom" ? "2px solid " + (T.accent||"#c8832a") : "1.5px solid " + (T.border||"#e0d0b8"),
                      background: tipPercent === "custom" ? "#fff7ed" : (T.card||"#fff"),
                      color: tipPercent === "custom" ? (T.accent||"#c8832a") : (T.muted||"#5a3e20")
                    }
                  }, "Custom")
                ),
                tipPercent === "custom" && React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8, marginTop: 8 } },
                  React.createElement("span", { style: { fontSize: 16, color: T.muted||"#5a3e20" } }, "$"),
                  React.createElement("input", {
                    type: "number", min: "0", step: "0.50",
                    value: customTip,
                    onChange: e => setCustomTip(e.target.value),
                    placeholder: "0.00",
                    style: { fontFamily: F.body, flex: 1, border: "1.5px solid " + (T.border||"#e0d0b8"), borderRadius: T.radius||"8px", padding: "8px 11px", fontSize: 14, color: T.text||"#1a1208", background: T.card||"#fff" }
                  })
                )
              ),

              // Summary
              React.createElement("div", { style: { background: T.primary||"#1a1208", borderRadius: T.radius, padding: "16px", marginTop: 14, color: "#f5e6c8" } },
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 6, color: "#b8996a" } },
                  React.createElement("span", null, "Subtotal"), React.createElement("span", null, "$" + subtotal.toFixed(2))
                ),
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 6, color: "#b8996a" } },
                  React.createElement("span", null, fulfillment === "delivery" ? "Delivery Fee" : "Pick Up"),
                  React.createElement("span", null,
                    fulfillment === "delivery"
                      ? (deliveryFee > 0 ? "$" + deliveryFee.toFixed(2) : (deliveryAddress ? "Free" : "TBD"))
                      : "—"
                  )
                ),
                orderDate && orderTime && React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 6, color: "#b8996a" } },
                  React.createElement("span", null, fulfillment === "pickup" ? "Pick Up" : "Delivery"),
                  React.createElement("span", null, new Date(orderDate + "T" + orderTime).toLocaleString("en-US", { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }))
                ),
                tipEnabled && tipAmount > 0 && React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 6, color: "#b8996a" } },
                  React.createElement("span", null, "Tip" + (tipPercent !== "custom" && tipPercent ? " (" + tipPercent + "%)" : "")),
                  React.createElement("span", null, "$" + tipAmount.toFixed(2))
                ),
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 10, color: "#b8996a" } },
                  React.createElement("span", null, "Tax"), React.createElement("span", null, "Calculated at checkout")
                ),
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 17, fontWeight: 800, borderTop: "1px solid rgba(255,255,255,0.1)", paddingTop: 10 } },
                  React.createElement("span", null, "Total"),
                  React.createElement("span", { style: { color: T.accent||"#c8832a" } },
                    "$" + (orderTotal + (fulfillment === "delivery" ? deliveryFee : 0)).toFixed(2) +
                    (fulfillment === "delivery" && !deliveryAddress ? "+" : "")
                  )
                )
              ),

              // Test Mode Notice (replaces WC notice when test mode on)
              S.test_mode && React.createElement("div", { style: { background: "#fffbeb", border: "1px solid #f6d28a", borderRadius: T.radius||"8px", padding: "12px 14px", marginTop: 12, display: "flex", gap: 10, alignItems: "flex-start" } },
                React.createElement("span", { style: { fontSize: 18, flexShrink: 0 } }, "🧪"),
                React.createElement("p", { style: { fontSize: 12, color: "#92400e", lineHeight: 1.6, margin: 0, fontFamily: F.body } },
                  React.createElement("strong", null, "Test Mode is active."),
                  " Your order will be saved but no payment will be collected."
                )
              ),

              // WC Pre-Auth Notice (only shown when WC active and NOT in test mode)
              !S.test_mode && S.wc_active && React.createElement("div", { style: { background: "#f9f6ff", border: "1px solid #c9b3e8", borderRadius: T.radius||"8px", padding: "12px 14px", marginTop: 12, display: "flex", gap: 10, alignItems: "flex-start" } },
                React.createElement("span", { style: { fontSize: 18, flexShrink: 0 } }, "🔒"),
                React.createElement("p", { style: { fontSize: 12, color: "#3d2373", lineHeight: 1.6, margin: 0, fontFamily: F.body } },
                  S.wc_preauth_note || "Your card will be pre-authorized but not charged until your order is confirmed."
                )
              ),

              React.createElement("button", {
                onClick: submitOrder,
                disabled: submitState === "loading" || submitState === "redirecting",
                style: { fontFamily: F.body, width: "100%", background: submitState === "loading" || submitState === "redirecting" ? "#aaa" : S.test_mode ? "#d97706" : (T.accent||"#c8832a"), color: "#fff", border: "none", borderRadius: T.radius||"10px", padding: "14px", cursor: (submitState === "loading" || submitState === "redirecting") ? "wait" : "pointer", fontSize: 15, fontWeight: 800, marginTop: 12, transition: "background 0.2s" }
              }, submitState === "loading" ? "Saving Order..." : submitState === "redirecting" ? "↗ Redirecting to Payment..." : S.test_mode ? "🧪 Submit Test Order" : (S.wc_active ? "Submit & Enter Card Details" : "Submit Catering Request")),

              submitState === "success" && React.createElement("div", { style: { background: "#f0faf3", border: "1px solid #34a853", borderRadius: T.radius||"8px", padding: "14px 16px", marginTop: 10, fontSize: 13, color: "#1a6630", lineHeight: 1.6 } }, submitMessage),
              submitState === "redirecting" && React.createElement("div", { style: { background: "#f9f6ff", border: "1px solid #c9b3e8", borderRadius: T.radius||"8px", padding: "14px 16px", marginTop: 10, fontSize: 13, color: "#3d2373", lineHeight: 1.6, display: "flex", alignItems: "center", gap: 10 } },
                React.createElement("span", { style: { fontSize: 20 } }, "🔒"),
                submitMessage
              ),
              submitState === "error" && React.createElement("div", { style: { background: "#fff0f0", border: "1px solid #cc3333", borderRadius: T.radius||"8px", padding: "14px 16px", marginTop: 10, fontSize: 13, color: "#cc3333", lineHeight: 1.6 } }, "⚠️ " + submitMessage),
              submitState !== "success" && submitState !== "redirecting" && (S.store_email || S.store_phone) &&
                React.createElement("p", { style: { textAlign: "center", fontSize: 12, color: T.muted||"#a07848", marginTop: 8 } },
                  [S.store_email && ("Email " + S.store_email), S.store_phone].filter(Boolean).join(" · ")
                )
            )
      )
    )
  );
}

// Mount
const rootEl = document.getElementById("caterme-root");
if (rootEl) {
  const root = ReactDOM.createRoot(rootEl);
  root.render(React.createElement(CateringApp));
}

