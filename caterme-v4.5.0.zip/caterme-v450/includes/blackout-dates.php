<?php
/**
 * CaterMe — Blackout Dates & Times
 *
 * Allows admin to block specific days-of-week and specific dates for pickup and/or delivery.
 * Provides REST endpoint for frontend availability checking.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── REST: Check date/time availability ──────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/availability', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $request ) {
            $date        = sanitize_text_field( $request->get_param('date') ?? '' ); // YYYY-MM-DD
            $time        = sanitize_text_field( $request->get_param('time') ?? '' ); // HH:MM
            $fulfillment = sanitize_text_field( $request->get_param('fulfillment') ?? 'pickup' );

            if ( ! $date ) {
                return new WP_REST_Response( array( 'available' => false, 'reason' => 'No date provided.' ), 400 );
            }

            $is_available = caterme_check_availability( $date, $time, $fulfillment );

            if ( $is_available === true ) {
                return new WP_REST_Response( array( 'available' => true ), 200 );
            } else {
                return new WP_REST_Response( array( 'available' => false, 'reason' => $is_available ), 200 );
            }
        },
    ));
});

// ─── Availability checker ─────────────────────────────────────────────────────

/**
 * Check if a given date/time is available for the specified fulfillment type.
 *
 * @param  string $date         YYYY-MM-DD
 * @param  string $time         HH:MM (optional)
 * @param  string $fulfillment  'pickup' or 'delivery'
 * @return true|string          true if available, error message if not
 */
function caterme_check_availability( $date, $time, $fulfillment ) {
    $s = caterme_get_settings();

    $prefix = $fulfillment === 'delivery' ? 'delivery' : 'pickup';

    // ── Check day-of-week blackouts ───────────────────────────────────────────
    $closed_days = array_filter( explode( ',', $s["{$prefix}_closed_days"] ?? '' ) );
    if ( ! empty( $closed_days ) ) {
        $day_of_week = strtolower( date( 'l', strtotime($date) ) ); // monday, tuesday, etc.
        if ( in_array( $day_of_week, array_map('strtolower', $closed_days) ) ) {
            return ucfirst($fulfillment) . ' is not available on ' . ucfirst($day_of_week) . 's.';
        }
    }

    // ── Check specific date blackouts ─────────────────────────────────────────
    $blocked_dates_raw = $s["{$prefix}_blocked_dates"] ?? '';
    $blocked_dates = array_filter( array_map( 'trim', explode( ',', $blocked_dates_raw ) ) );
    if ( in_array( $date, $blocked_dates ) ) {
        return ucfirst($fulfillment) . ' is not available on ' . date('F j, Y', strtotime($date)) . '.';
    }

    // ── Check time-specific blackouts (future enhancement) ────────────────────
    // Could add time ranges here if needed

    return true;
}

// ─── Get blocked dates for frontend calendar ─────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/blocked-dates', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $request ) {
            $fulfillment = sanitize_text_field( $request->get_param('fulfillment') ?? 'pickup' );
            $s = caterme_get_settings();
            $prefix = $fulfillment === 'delivery' ? 'delivery' : 'pickup';

            $closed_days = array_filter( explode( ',', $s["{$prefix}_closed_days"] ?? '' ) );
            $blocked_dates = array_filter( array_map( 'trim', explode( ',', $s["{$prefix}_blocked_dates"] ?? '' ) ) );

            return new WP_REST_Response( array(
                'closed_days'    => array_map( 'strtolower', $closed_days ),
                'blocked_dates'  => $blocked_dates,
            ), 200 );
        },
    ));
});
