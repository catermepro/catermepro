<?php
/**
 * CaterMe — WooCommerce Checkout Integration
 *
 * Adds custom checkout fields, displays line items with modifier details,
 * and creates caterme_orders records from WC orders after payment.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Add custom checkout fields ───────────────────────────────────────────────

add_filter( 'woocommerce_checkout_fields', function( $fields ) {
    $settings = caterme_get_settings();
    
    // Add CaterMe section
    $fields['caterme'] = array(
        'fulfillment' => array(
            'type'     => 'radio',
            'label'    => __( 'Order Type', 'caterme' ),
            'required' => true,
            'class'    => array( 'form-row-wide', 'caterme-fulfillment' ),
            'options'  => array(
                'pickup'   => __( '🏪 Pick Up', 'caterme' ),
                'delivery' => __( '🚗 Delivery', 'caterme' ),
            ),
            'default'  => 'pickup',
            'priority' => 10,
        ),
        'order_date' => array(
            'type'        => 'date',
            'label'       => __( 'Date', 'caterme' ),
            'required'    => true,
            'class'       => array( 'form-row-first', 'caterme-order-date' ),
            'placeholder' => '',
            'priority'    => 20,
        ),
        'order_time' => array(
            'type'        => 'time',
            'label'       => __( 'Time', 'caterme' ),
            'required'    => true,
            'class'       => array( 'form-row-last', 'caterme-order-time' ),
            'placeholder' => '',
            'priority'    => 30,
        ),
        'delivery_address' => array(
            'type'        => 'textarea',
            'label'       => __( 'Delivery Address', 'caterme' ),
            'required'    => false,
            'class'       => array( 'form-row-wide', 'caterme-delivery-address' ),
            'placeholder' => __( 'Street address, City, State, ZIP', 'caterme' ),
            'priority'    => 40,
            'custom_attributes' => array(
                'rows' => 2,
            ),
        ),
        'tip_amount' => array(
            'type'        => 'number',
            'label'       => __( 'Tip', 'caterme' ),
            'required'    => false,
            'class'       => array( 'form-row-wide', 'caterme-tip' ),
            'placeholder' => '0.00',
            'priority'    => 50,
            'custom_attributes' => array(
                'step' => '0.01',
                'min'  => '0',
            ),
        ),
    );

    return $fields;
});

// ─── Validate checkout fields ─────────────────────────────────────────────────

add_action( 'woocommerce_checkout_process', function() {
    $fulfillment = sanitize_text_field( $_POST['caterme_fulfillment'] ?? 'pickup' );
    $order_date  = sanitize_text_field( $_POST['caterme_order_date'] ?? '' );
    $order_time  = sanitize_text_field( $_POST['caterme_order_time'] ?? '' );
    $delivery_address = sanitize_textarea_field( $_POST['caterme_delivery_address'] ?? '' );

    // Validate date/time required
    if ( empty($order_date) ) {
        wc_add_notice( __( 'Please select an order date.', 'caterme' ), 'error' );
    }
    if ( empty($order_time) ) {
        wc_add_notice( __( 'Please select an order time.', 'caterme' ), 'error' );
    }

    // Validate delivery address if delivery selected
    if ( $fulfillment === 'delivery' && empty($delivery_address) ) {
        wc_add_notice( __( 'Delivery address is required.', 'caterme' ), 'error' );
    }

    // Validate against blackout dates
    if ( $order_date ) {
        $availability = caterme_check_availability( $order_date, $order_time, $fulfillment );
        if ( $availability !== true ) {
            wc_add_notice( $availability, 'error' );
        }
    }

    // Validate lead time
    $settings = caterme_get_settings();
    $lead_hours = absint( $settings['lead_time_hours'] ?? 0 );
    if ( $lead_hours > 0 && $order_date && $order_time ) {
        $order_dt = strtotime( $order_date . ' ' . $order_time );
        $min_allowed = time() + ( $lead_hours * 3600 );
        if ( $order_dt !== false && $order_dt < $min_allowed ) {
            wc_add_notice( sprintf(
                __( 'Orders require at least %d hour%s advance notice. Please choose a later date/time.', 'caterme' ),
                $lead_hours,
                $lead_hours === 1 ? '' : 's'
            ), 'error' );
        }
    }
});

// ─── Save checkout field data to order meta ───────────────────────────────────

add_action( 'woocommerce_checkout_update_order_meta', function( $order_id ) {
    if ( ! empty( $_POST['caterme_fulfillment'] ) ) {
        update_post_meta( $order_id, '_caterme_fulfillment', sanitize_text_field( $_POST['caterme_fulfillment'] ) );
    }
    if ( ! empty( $_POST['caterme_order_date'] ) ) {
        update_post_meta( $order_id, '_caterme_order_date', sanitize_text_field( $_POST['caterme_order_date'] ) );
    }
    if ( ! empty( $_POST['caterme_order_time'] ) ) {
        update_post_meta( $order_id, '_caterme_order_time', sanitize_text_field( $_POST['caterme_order_time'] ) );
    }
    if ( ! empty( $_POST['caterme_delivery_address'] ) ) {
        update_post_meta( $order_id, '_caterme_delivery_address', sanitize_textarea_field( $_POST['caterme_delivery_address'] ) );
    }
    if ( ! empty( $_POST['caterme_tip_amount'] ) ) {
        update_post_meta( $order_id, '_caterme_tip_amount', floatval( $_POST['caterme_tip_amount'] ) );
    }
});

// ─── Create caterme_orders record after WC order is created ──────────────────

add_action( 'woocommerce_checkout_order_processed', function( $order_id, $posted_data, $order ) {
    global $wpdb;

    // Check if already processed (prevent duplicates on page refresh)
    if ( get_post_meta( $order_id, '_caterme_order_created', true ) ) {
        return;
    }

    $orders_table = $wpdb->prefix . 'caterme_orders';
    $items_table  = $wpdb->prefix . 'caterme_order_items';

    // Generate order number
    $order_number = caterme_generate_order_number();

    // Get checkout field values
    $fulfillment      = get_post_meta( $order_id, '_caterme_fulfillment', true ) ?: 'pickup';
    $order_date       = get_post_meta( $order_id, '_caterme_order_date', true );
    $order_time       = get_post_meta( $order_id, '_caterme_order_time', true );
    $delivery_address = get_post_meta( $order_id, '_caterme_delivery_address', true );
    $tip              = floatval( get_post_meta( $order_id, '_caterme_tip_amount', true ) );

    // Calculate delivery fee if delivery
    $delivery_fee = 0;
    if ( $fulfillment === 'delivery' && $delivery_address ) {
        $fee_result = caterme_calc_delivery_fee( $delivery_address );
        if ( is_array( $fee_result ) ) {
            $delivery_fee = $fee_result['fee'];
        }
    }

    // Get customer info
    $customer_name  = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
    $customer_phone = $order->get_billing_phone();
    $customer_email = $order->get_billing_email();

    // Calculate subtotal from cart items (excluding tip)
    $subtotal = 0;
    foreach ( $order->get_items() as $item ) {
        $subtotal += $item->get_total();
    }

    // Get tax from WC order
    $tax = floatval( $order->get_total_tax() );

    // Insert order
    $wpdb->insert( $orders_table, array(
        'wc_order_id'      => $order_id,
        'order_number'     => $order_number,
        'status'           => 'new',
        'payment_status'   => 'pending',
        'fulfillment'      => $fulfillment,
        'order_date'       => $order_date ? date( 'Y-m-d', strtotime( $order_date ) ) : null,
        'order_time'       => $order_time ? $order_time . ':00' : null,
        'subtotal'         => $subtotal,
        'delivery_fee'     => $delivery_fee,
        'tax'              => $tax,
        'tip'              => $tip,
        'customer_name'    => $customer_name,
        'customer_phone'   => $customer_phone,
        'customer_email'   => $customer_email,
        'delivery_address' => $delivery_address,
        'notes'            => $order->get_customer_note(),
        'created_at'       => current_time( 'mysql' ),
    ));

    $caterme_order_id = $wpdb->insert_id;

    // Insert items
    foreach ( $order->get_items() as $item ) {
        $item_name    = $item->get_name();
        $qty          = $item->get_quantity();
        $unit_price   = $item->get_total() / $qty;
        $line_total   = $item->get_total();
        
        // Get modifier data from item meta
        $selections   = $item->get_meta( '_caterme_selections' ) ?: array();
        $label_name   = $item->get_meta( '_caterme_label_name' ) ?: '';
        $dietary      = $item->get_meta( '_caterme_dietary' ) ?: '';

        $wpdb->insert( $items_table, array(
            'order_id'   => $caterme_order_id,
            'item_name'  => $item_name,
            'qty'        => $qty,
            'unit_price' => $unit_price,
            'line_total' => $line_total,
            'selections' => is_array( $selections ) ? wp_json_encode( $selections ) : $selections,
            'dietary'    => $dietary,
            'label_name' => $label_name,
        ));
    }

    // Link back to caterme order
    update_post_meta( $order_id, '_caterme_order_id', $caterme_order_id );
    update_post_meta( $order_id, '_caterme_order_number', $order_number );
    update_post_meta( $order_id, '_caterme_order_created', '1' );

    // Send notification
    caterme_notify_new_order( $caterme_order_id );

}, 10, 3 );

// ─── Display line items with modifiers on checkout page ──────────────────────

add_action( 'woocommerce_review_order_before_order_total', function() {
    if ( ! WC()->cart->is_empty() ) {
        echo '<tr class="caterme-items-header"><th colspan="2" style="padding-top:20px;border-top:2px solid #ddd;font-size:14px;color:#666;">Order Items</th></tr>';
        
        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
            $product      = $cart_item['data'];
            $quantity     = $cart_item['quantity'];
            $item_total   = $cart_item['line_total'];
            $label_name   = $cart_item['caterme_label_name'] ?? '';
            $selections   = $cart_item['caterme_selections'] ?? array();
            $dietary      = $cart_item['caterme_dietary'] ?? '';

            echo '<tr class="caterme-cart-item">';
            echo '<td style="padding:8px 0;vertical-align:top;">';
            echo '<strong>' . esc_html( $product->get_name() ) . '</strong>';
            echo '<span style="color:#999;margin-left:8px;">× ' . $quantity . '</span>';
            
            if ( $label_name ) {
                echo '<div style="font-size:12px;color:#c8832a;font-weight:700;margin-top:3px;">🏷️ ' . esc_html( $label_name ) . '</div>';
            }
            
            if ( ! empty( $selections ) ) {
                echo '<div style="font-size:12px;color:#888;margin-top:3px;">';
                $sel_parts = array();
                foreach ( $selections as $key => $val ) {
                    if ( $key === 'dietary' ) continue;
                    if ( $val === false || $val === 0 || $val === '' ) continue;
                    if ( is_array( $val ) ) {
                        foreach ( $val as $v ) $sel_parts[] = esc_html( $v );
                        continue;
                    }
                    if ( $val === true ) {
                        $sel_parts[] = esc_html( ucfirst( str_replace( '_', ' ', $key ) ) );
                        continue;
                    }
                    $sel_parts[] = esc_html( (string) $val );
                }
                echo implode( ' · ', $sel_parts );
                echo '</div>';
            }
            
            if ( $dietary ) {
                echo '<div style="font-size:11px;color:#c8832a;margin-top:2px;">' . esc_html( $dietary ) . '</div>';
            }
            
            echo '</td>';
            echo '<td style="text-align:right;vertical-align:top;padding:8px 0;">$' . number_format( $item_total, 2 ) . '</td>';
            echo '</tr>';
        }
    }
});

// ─── Add CSS for checkout fields ──────────────────────────────────────────────

add_action( 'wp_head', function() {
    if ( ! is_checkout() ) return;
    ?>
    <style>
    .caterme-fulfillment ul { display: flex; gap: 10px; list-style: none; padding: 0; margin: 10px 0 0; }
    .caterme-fulfillment li { flex: 1; }
    .caterme-fulfillment label { display: block; padding: 12px; border: 2px solid #ddd; border-radius: 6px; text-align: center; cursor: pointer; transition: all 0.2s; }
    .caterme-fulfillment input[type="radio"]:checked + label { border-color: #c8832a; background: #fff7ed; color: #c8832a; font-weight: 700; }
    .caterme-fulfillment input[type="radio"] { display: none; }
    .caterme-delivery-address { display: none; }
    .caterme-items-header th { background: #faf7f2; padding: 12px 8px !important; font-weight: 700; }
    .caterme-cart-item td { border-top: 1px solid #f0f0f0; }
    </style>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle delivery address field based on fulfillment selection
        var fulfillmentInputs = document.querySelectorAll('input[name="caterme_fulfillment"]');
        var deliveryField = document.querySelector('.caterme-delivery-address');
        
        function toggleDeliveryField() {
            var deliverySelected = document.querySelector('input[name="caterme_fulfillment"]:checked')?.value === 'delivery';
            if (deliveryField) {
                deliveryField.style.display = deliverySelected ? 'block' : 'none';
                var textarea = deliveryField.querySelector('textarea');
                if (textarea) {
                    textarea.required = deliverySelected;
                }
            }
        }
        
        fulfillmentInputs.forEach(function(input) {
            input.addEventListener('change', toggleDeliveryField);
        });
        
        toggleDeliveryField();
        
        // Auto-populate from sessionStorage (CaterMe cart drawer)
        var data = sessionStorage.getItem('caterme_checkout_data');
        if (data) {
            try {
                var parsed = JSON.parse(data);
                
                // Fulfillment type
                var fulfillmentInput = document.querySelector('input[name="caterme_fulfillment"][value="' + parsed.fulfillment + '"]');
                if (fulfillmentInput) {
                    fulfillmentInput.checked = true;
                    toggleDeliveryField();
                }
                
                // Date and time
                var dateInput = document.querySelector('input[name="caterme_order_date"]');
                if (dateInput && parsed.orderDate) dateInput.value = parsed.orderDate;
                
                var timeInput = document.querySelector('input[name="caterme_order_time"]');
                if (timeInput && parsed.orderTime) timeInput.value = parsed.orderTime;
                
                // Delivery address
                var addressInput = document.querySelector('textarea[name="caterme_delivery_address"]');
                if (addressInput && parsed.deliveryAddress) addressInput.value = parsed.deliveryAddress;
                
                // Tip
                var tipInput = document.querySelector('input[name="caterme_tip_amount"]');
                if (tipInput && parsed.tipAmount) tipInput.value = parsed.tipAmount.toFixed(2);
                
                // Customer name (split into first/last)
                if (parsed.customerName) {
                    var nameParts = parsed.customerName.split(' ');
                    var billingFirstName = document.querySelector('#billing_first_name');
                    var billingLastName = document.querySelector('#billing_last_name');
                    if (billingFirstName) billingFirstName.value = nameParts[0] || '';
                    if (billingLastName) billingLastName.value = nameParts.slice(1).join(' ') || '';
                }
                
                // Phone and email
                var billingPhone = document.querySelector('#billing_phone');
                if (billingPhone && parsed.customerPhone) billingPhone.value = parsed.customerPhone;
                
                var billingEmail = document.querySelector('#billing_email');
                if (billingEmail && parsed.customerEmail) billingEmail.value = parsed.customerEmail;
                
                // Clear after populating
                sessionStorage.removeItem('caterme_checkout_data');
            } catch(e) {
                console.error('Error parsing CaterMe checkout data:', e);
            }
        }
    });
    </script>
    <?php
});
