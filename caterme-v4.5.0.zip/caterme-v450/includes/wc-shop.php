<?php
/**
 * CaterMe — WooCommerce Shop & Checkout Integration
 *
 * 1. Auto-inject React on WC shop page (template override)
 * 2. AJAX: caterme_prepare_checkout — populates WC cart + session, returns checkout URL
 * 3. WC checkout: inject CaterMe fulfillment fields, validate, save to order meta
 * 4. woocommerce_checkout_order_created: create caterme_orders + items from WC order
 * 5. WC cart item display: show modifier selections on checkout & order confirmation
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─────────────────────────────────────────────────────────────────────────────
// 1. SHOP PAGE — inject React via template override
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Replace the WC shop template with our React app template.
 * Only activates on is_shop(). Product archive/category pages are unaffected.
 */
add_filter( 'template_include', function( $template ) {
    if ( ! function_exists('is_shop') || ! is_shop() ) return $template;
    $custom = plugin_dir_path( dirname(__FILE__) ) . 'templates/shop.php';
    return file_exists( $custom ) ? $custom : $template;
}, 99 );

// ─────────────────────────────────────────────────────────────────────────────
// 2. AJAX: populate WC cart + session, return checkout URL
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'wp_ajax_caterme_prepare_checkout',        'caterme_ajax_prepare_checkout' );
add_action( 'wp_ajax_nopriv_caterme_prepare_checkout', 'caterme_ajax_prepare_checkout' );

function caterme_ajax_prepare_checkout() {
    check_ajax_referer( 'caterme_prepare_checkout', 'nonce' );

    if ( ! caterme_wc_active() ) {
        wp_send_json_error( array('message' => 'WooCommerce is not active.') );
    }

    $raw  = wp_unslash( $_POST['data'] ?? '{}' );
    $data = json_decode( $raw, true );
    if ( ! is_array($data) ) {
        wp_send_json_error( array('message' => 'Invalid data.') );
    }

    $fulfillment      = sanitize_text_field( $data['fulfillment']      ?? 'pickup' );
    $order_date       = sanitize_text_field( $data['orderDate']        ?? '' );
    $order_time       = sanitize_text_field( $data['orderTime']        ?? '' );
    $delivery_address = sanitize_textarea_field( $data['deliveryAddress'] ?? '' );
    $delivery_fee     = round( floatval( $data['deliveryFee'] ?? 0 ), 2 );
    $notes            = sanitize_textarea_field( $data['notes']        ?? '' );
    $tip              = round( floatval( $data['tipAmount']            ?? 0 ), 2 );
    $customer_name    = sanitize_text_field( $data['customerName']     ?? '' );
    $customer_email   = sanitize_email(      $data['customerEmail']    ?? '' );
    $customer_phone   = sanitize_text_field( $data['customerPhone']    ?? '' );
    $items            = $data['items'] ?? array();

    // ── Availability validation ──────────────────────────────────────────────
    if ( function_exists('caterme_validate_datetime') && $order_date ) {
        $avail_check = caterme_validate_datetime( $order_date, $order_time, $fulfillment );
        if ( $avail_check !== true ) {
            wp_send_json_error( array('message' => $avail_check) );
        }
    }

    // ── Lead time validation ─────────────────────────────────────────────────
    $settings   = caterme_get_settings();
    $lead_hours = absint( $settings['lead_time_hours'] ?? 0 );
    if ( $lead_hours > 0 && $order_date && $order_time ) {
        $order_ts    = strtotime( $order_date . ' ' . $order_time );
        $min_allowed = time() + $lead_hours * 3600;
        if ( $order_ts !== false && $order_ts < $min_allowed ) {
            wp_send_json_error( array(
                'message' => sprintf(
                    'Orders require at least %d hour%s advance notice. Please choose a later date/time.',
                    $lead_hours, $lead_hours === 1 ? '' : 's'
                ),
            ) );
        }
    }

    // ── Delivery fee recalculation (server-side truth) ────────────────────────
    if ( $fulfillment === 'delivery' && $delivery_address && function_exists('caterme_calc_delivery_fee') ) {
        $fee_result = caterme_calc_delivery_fee( $delivery_address );
        if ( is_array($fee_result) ) $delivery_fee = $fee_result['fee'];
    }

    // ── Clear existing WC cart ────────────────────────────────────────────────
    WC()->cart->empty_cart();

    // ── Add each item to WC cart with CaterMe meta ────────────────────────────
    foreach ( $items as $item_data ) {
        $product_id = absint( $item_data['item']['id'] ?? 0 );
        $qty        = max( 1, absint( $item_data['qty'] ?? 1 ) );
        $unit_price = round( floatval( $item_data['unitPrice'] ?? 0 ), 2 );

        if ( ! $product_id ) continue;
        $product = wc_get_product( $product_id );
        if ( ! $product || ! $product->is_purchasable() ) continue;

        // Build human-readable selections string array
        $item_obj  = $item_data['item'];
        $selections_arr = (array) ( $item_data['selectionsFlat'] ?? array() );
        $dietary_str    = sanitize_text_field( $item_data['dietary'] ?? '' );
        $label_name     = sanitize_text_field( $item_data['labelName'] ?? '' );

        $cart_item_data = array(
            'caterme_meta' => array(
                'unit_price'  => $unit_price,
                'selections'  => $selections_arr,
                'dietary'     => $dietary_str,
                'label_name'  => $label_name,
                'product_id'  => $product_id,
            ),
        );

        WC()->cart->add_to_cart( $product_id, $qty, 0, array(), $cart_item_data );
    }

    // ── Store CaterMe fulfillment data in WC session ──────────────────────────
    $session_data = array(
        'fulfillment'      => $fulfillment,
        'order_date'       => $order_date,
        'order_time'       => $order_time,
        'delivery_address' => $delivery_address,
        'delivery_fee'     => $delivery_fee,
        'notes'            => $notes,
        'tip'              => $tip,
        'customer_name'    => $customer_name,
        'customer_email'   => $customer_email,
        'customer_phone'   => $customer_phone,
    );
    WC()->session->set( 'caterme_checkout', $session_data );

    $checkout_url = wc_get_checkout_url();
    wp_send_json_success( array( 'checkout_url' => $checkout_url ) );
}

// ─── Price override: apply CaterMe modifier-adjusted price to WC cart ─────────
add_action( 'woocommerce_before_calculate_totals', function( $cart ) {
    if ( is_admin() && ! defined('DOING_AJAX') ) return;
    foreach ( $cart->get_cart() as $cart_item ) {
        if ( ! empty( $cart_item['caterme_meta']['unit_price'] ) ) {
            $cart_item['data']->set_price( floatval( $cart_item['caterme_meta']['unit_price'] ) );
        }
    }
}, 20 );

// ─── Display modifier selections on WC cart & checkout ────────────────────────
add_filter( 'woocommerce_get_item_data', function( $data, $cart_item ) {
    $meta = $cart_item['caterme_meta'] ?? null;
    if ( ! $meta ) return $data;

    if ( ! empty( $meta['selections'] ) && is_array( $meta['selections'] ) ) {
        $data[] = array( 'name' => 'Selections', 'value' => implode( ' · ', $meta['selections'] ) );
    }
    if ( ! empty( $meta['label_name'] ) ) {
        $data[] = array( 'name' => '🏷️ Label', 'value' => $meta['label_name'] );
    }
    if ( ! empty( $meta['dietary'] ) ) {
        $data[] = array( 'name' => 'Dietary', 'value' => $meta['dietary'] );
    }
    return $data;
}, 10, 2 );

// ─── Persist CaterMe meta to WC order line items ──────────────────────────────
add_action( 'woocommerce_checkout_create_order_line_item', function( $item, $cart_item_key, $values ) {
    $meta = $values['caterme_meta'] ?? null;
    if ( ! $meta ) return;

    if ( ! empty( $meta['selections'] ) && is_array( $meta['selections'] ) ) {
        $item->add_meta_data( 'Selections', implode( ' · ', $meta['selections'] ), true );
    }
    if ( ! empty( $meta['label_name'] ) ) {
        $item->add_meta_data( 'Label Name', $meta['label_name'], true );
    }
    if ( ! empty( $meta['dietary'] ) ) {
        $item->add_meta_data( 'Dietary', $meta['dietary'], true );
    }
    if ( ! empty( $meta['unit_price'] ) ) {
        $item->add_meta_data( '_caterme_unit_price', $meta['unit_price'], true );
    }
}, 10, 3 );

// ─────────────────────────────────────────────────────────────────────────────
// 3. WC CHECKOUT — inject CaterMe fulfillment fields
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'woocommerce_before_order_notes', function( $checkout ) {
    $s = caterme_get_settings();
    $session = WC()->session ? WC()->session->get('caterme_checkout') : array();
    if ( ! is_array($session) ) $session = array();

    $fulfillment = $session['fulfillment'] ?? 'pickup';
    $avail_pickup   = function_exists('caterme_get_availability') ? caterme_get_availability('pickup')   : array();
    $avail_delivery = function_exists('caterme_get_availability') ? caterme_get_availability('delivery') : array();

    $open_p  = $avail_pickup['open_time']   ?? '';
    $close_p = $avail_pickup['close_time']  ?? '';
    $open_d  = $avail_delivery['open_time'] ?? '';
    $close_d = $avail_delivery['close_time'] ?? '';

    ?>
    <div id="caterme-checkout-section" style="margin-bottom:30px;">
        <h3 style="font-size:18px;font-weight:700;margin-bottom:16px;">📋 Order Details</h3>

        <!-- Fulfillment type -->
        <p class="form-row form-row-wide" id="caterme_fulfillment_row">
            <label>Order Type <abbr class="required" title="required">*</abbr></label>
            <span style="display:flex;gap:10px;margin-top:6px;">
                <label style="flex:1;border:2px solid <?php echo $fulfillment==='pickup'?'#c8832a':'#e0d0b8'; ?>;border-radius:8px;padding:10px;text-align:center;cursor:pointer;font-weight:<?php echo $fulfillment==='pickup'?'700':'400'; ?>;background:<?php echo $fulfillment==='pickup'?'#fff7ed':'#fff'; ?>;" id="caterme-ft-pickup-label">
                    <input type="radio" name="caterme_fulfillment" value="pickup" id="caterme-ft-pickup" <?php checked($fulfillment,'pickup'); ?> style="display:none;">
                    🏪 Pick Up
                </label>
                <label style="flex:1;border:2px solid <?php echo $fulfillment==='delivery'?'#c8832a':'#e0d0b8'; ?>;border-radius:8px;padding:10px;text-align:center;cursor:pointer;font-weight:<?php echo $fulfillment==='delivery'?'700':'400'; ?>;background:<?php echo $fulfillment==='delivery'?'#fff7ed':'#fff'; ?>;" id="caterme-ft-delivery-label">
                    <input type="radio" name="caterme_fulfillment" value="delivery" id="caterme-ft-delivery" <?php checked($fulfillment,'delivery'); ?> style="display:none;">
                    🚗 Delivery
                </label>
            </span>
        </p>

        <!-- Delivery address (shown for delivery only) -->
        <p class="form-row form-row-wide" id="caterme_delivery_address_row" style="<?php echo $fulfillment!=='delivery' ? 'display:none;' : ''; ?>">
            <label for="caterme_delivery_address">Delivery Address <abbr class="required" title="required">*</abbr></label>
            <input type="text" id="caterme_delivery_address" name="caterme_delivery_address" class="input-text"
                   value="<?php echo esc_attr($session['delivery_address'] ?? ''); ?>"
                   placeholder="Street address, City, State, ZIP" />
        </p>

        <!-- Delivery fee (shown for delivery only) -->
        <p id="caterme_delivery_fee_row" style="<?php echo $fulfillment!=='delivery' ? 'display:none;' : ''; ?>;font-size:13px;color:#555;margin-bottom:10px;">
            🚗 Delivery fee: <strong id="caterme-delivery-fee-val">$<?php echo number_format(floatval($session['delivery_fee'] ?? 0),2); ?></strong>
        </p>

        <!-- Date & time -->
        <p class="form-row form-row-first">
            <label for="caterme_order_date" id="caterme_date_label">
                <?php echo $fulfillment==='delivery' ? 'Delivery Date' : 'Pick Up Date'; ?>
                <abbr class="required" title="required">*</abbr>
            </label>
            <input type="date" id="caterme_order_date" name="caterme_order_date" class="input-text"
                   value="<?php echo esc_attr($session['order_date'] ?? ''); ?>"
                   <?php if ( function_exists('caterme_get_settings') ): $lh = absint( ($s['lead_time_hours'] ?? 0) ); if ($lh) : ?>
                   min="<?php echo date('Y-m-d', strtotime("+{$lh} hours")); ?>"
                   <?php endif; endif; ?> />
        </p>
        <p class="form-row form-row-last">
            <label for="caterme_order_time" id="caterme_time_label">
                <?php echo $fulfillment==='delivery' ? 'Delivery Time' : 'Pick Up Time'; ?>
                <abbr class="required" title="required">*</abbr>
            </label>
            <input type="time" id="caterme_order_time" name="caterme_order_time" class="input-text"
                   value="<?php echo esc_attr($session['order_time'] ?? ''); ?>" />
            <?php if ($open_p && $close_p): ?>
            <span class="description" id="caterme-time-hint-pickup">Pick up: <?php echo date('g:i a', strtotime($open_p)); ?> – <?php echo date('g:i a', strtotime($close_p)); ?></span>
            <?php endif; ?>
            <?php if ($open_d && $close_d): ?>
            <span class="description" id="caterme-time-hint-delivery" style="<?php echo $fulfillment!=='delivery'?'display:none;':''; ?>">Delivery: <?php echo date('g:i a', strtotime($open_d)); ?> – <?php echo date('g:i a', strtotime($close_d)); ?></span>
            <?php endif; ?>
        </p>

        <!-- Tip -->
        <?php if ( ($s['tip_enabled'] ?? '1') === '1' ): ?>
        <p class="form-row form-row-wide">
            <label for="caterme_tip">Tip (Optional)</label>
            <span style="display:flex;align-items:center;gap:8px;">
                <span style="font-size:15px;color:#555;">$</span>
                <input type="number" id="caterme_tip" name="caterme_tip" class="input-text"
                       value="<?php echo esc_attr(number_format(floatval($session['tip'] ?? 0), 2, '.', '')); ?>"
                       min="0" step="0.50" style="max-width:120px;" />
            </span>
        </p>
        <?php endif; ?>

        <!-- Availability data for JS -->
        <script>
        window.CATERME_AVAIL = {
            pickup:   <?php echo wp_json_encode($avail_pickup); ?>,
            delivery: <?php echo wp_json_encode($avail_delivery); ?>
        };
        </script>
    </div>

    <script>
    (function() {
        function isDateBlocked(dateStr, type) {
            if (!window.CATERME_AVAIL) return false;
            var avail = type === 'delivery' ? CATERME_AVAIL.delivery : CATERME_AVAIL.pickup;
            if (!avail) return false;
            // blocked dates
            if (avail.blocked_dates && avail.blocked_dates.indexOf(dateStr) !== -1) return true;
            // closed days
            var d = new Date(dateStr + 'T00:00:00');
            if (avail.closed_days && avail.closed_days.indexOf(d.getDay()) !== -1) return true;
            return false;
        }
        function getType() {
            var r = document.querySelector('input[name="caterme_fulfillment"]:checked');
            return r ? r.value : 'pickup';
        }
        function updateLabels(type) {
            var dl = document.getElementById('caterme_date_label');
            var tl = document.getElementById('caterme_time_label');
            var hp = document.getElementById('caterme-time-hint-pickup');
            var hd = document.getElementById('caterme-time-hint-delivery');
            var ar = document.getElementById('caterme_delivery_address_row');
            var fr = document.getElementById('caterme_delivery_fee_row');
            if (dl) dl.childNodes[0].nodeValue = type === 'delivery' ? 'Delivery Date ' : 'Pick Up Date ';
            if (tl) tl.childNodes[0].nodeValue = type === 'delivery' ? 'Delivery Time ' : 'Pick Up Time ';
            if (hp) hp.style.display = type === 'delivery' ? 'none' : '';
            if (hd) hd.style.display = type === 'delivery' ? '' : 'none';
            if (ar) ar.style.display = type === 'delivery' ? '' : 'none';
            if (fr) fr.style.display = type === 'delivery' ? '' : 'none';
        }
        document.addEventListener('change', function(e) {
            if (e.target && e.target.name === 'caterme_fulfillment') {
                var type = e.target.value;
                updateLabels(type);
                // Update radio label styles
                ['pickup','delivery'].forEach(function(ft) {
                    var lbl = document.getElementById('caterme-ft-' + ft + '-label');
                    if (!lbl) return;
                    var active = ft === type;
                    lbl.style.borderColor  = active ? '#c8832a' : '#e0d0b8';
                    lbl.style.fontWeight   = active ? '700' : '400';
                    lbl.style.background   = active ? '#fff7ed' : '#fff';
                });
                // Re-validate date for new type
                var di = document.getElementById('caterme_order_date');
                if (di && di.value) validateDate(di.value, type);
            }
        });
        function validateDate(dateStr, type) {
            var di = document.getElementById('caterme_order_date');
            if (!di) return;
            var blocked = isDateBlocked(dateStr, type || getType());
            if (blocked) {
                di.style.borderColor = '#dc2626';
                di.setCustomValidity('Not available on this date. Please choose another day.');
            } else {
                di.style.borderColor = '';
                di.setCustomValidity('');
            }
        }
        document.addEventListener('change', function(e) {
            if (e.target && e.target.id === 'caterme_order_date') {
                validateDate(e.target.value, getType());
            }
        });
        // Run on page load
        updateLabels(getType());
    })();
    </script>
    <?php
} );

// ─────────────────────────────────────────────────────────────────────────────
// 4. WC CHECKOUT VALIDATION
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'woocommerce_checkout_process', function() {
    $fulfillment = sanitize_text_field( $_POST['caterme_fulfillment'] ?? 'pickup' );
    $order_date  = sanitize_text_field( $_POST['caterme_order_date']  ?? '' );
    $order_time  = sanitize_text_field( $_POST['caterme_order_time']  ?? '' );

    if ( ! $order_date ) {
        wc_add_notice( 'Please select a date for your order.', 'error' );
        return;
    }
    if ( ! $order_time ) {
        wc_add_notice( 'Please select a time for your order.', 'error' );
        return;
    }

    if ( function_exists('caterme_validate_datetime') ) {
        $result = caterme_validate_datetime( $order_date, $order_time, $fulfillment );
        if ( $result !== true ) {
            wc_add_notice( $result, 'error' );
        }
    }

    if ( $fulfillment === 'delivery' && empty( trim( $_POST['caterme_delivery_address'] ?? '' ) ) ) {
        wc_add_notice( 'Please enter a delivery address.', 'error' );
    }
} );

// ─────────────────────────────────────────────────────────────────────────────
// 5. SAVE TO WC ORDER META + CREATE caterme_orders ON CHECKOUT
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'woocommerce_checkout_order_created', function( $wc_order ) {
    global $wpdb;

    if ( ! ( $wc_order instanceof WC_Order ) ) return;

    $fulfillment      = sanitize_text_field( $_POST['caterme_fulfillment']      ?? 'pickup' );
    $order_date       = sanitize_text_field( $_POST['caterme_order_date']       ?? '' );
    $order_time       = sanitize_text_field( $_POST['caterme_order_time']       ?? '' );
    $delivery_address = sanitize_textarea_field( $_POST['caterme_delivery_address'] ?? '' );
    $tip              = round( floatval( $_POST['caterme_tip'] ?? 0 ), 2 );
    $notes            = sanitize_textarea_field( $_POST['order_comments'] ?? '' );

    // Save to WC order meta for reference
    $wc_order->update_meta_data( '_caterme_fulfillment',      $fulfillment );
    $wc_order->update_meta_data( '_caterme_order_date',       $order_date );
    $wc_order->update_meta_data( '_caterme_order_time',       $order_time );
    $wc_order->update_meta_data( '_caterme_delivery_address', $delivery_address );
    $wc_order->update_meta_data( '_caterme_tip',              $tip );
    $wc_order->save();

    // ── Recalculate delivery fee server-side ─────────────────────────────────
    $delivery_fee = 0.0;
    if ( $fulfillment === 'delivery' && $delivery_address && function_exists('caterme_calc_delivery_fee') ) {
        $fr = caterme_calc_delivery_fee( $delivery_address );
        if ( is_array($fr) ) $delivery_fee = $fr['fee'];
    }

    // ── Build subtotal from WC order items ───────────────────────────────────
    $subtotal = 0.0;
    $wc_items = $wc_order->get_items();
    foreach ( $wc_items as $wc_item ) {
        $subtotal += floatval( $wc_item->get_subtotal() );
    }

    // ── Tax ──────────────────────────────────────────────────────────────────
    $tax = round( floatval( $wc_order->get_total_tax() ), 2 );

    // ── Create caterme_orders row ─────────────────────────────────────────────
    $settings     = caterme_get_settings();
    $orders_table = $wpdb->prefix . 'caterme_orders';
    $items_table  = $wpdb->prefix . 'caterme_order_items';

    $order_number = caterme_generate_order_number();

    $order_date_val = $order_date ? date('Y-m-d', strtotime($order_date)) : null;
    $order_time_val = $order_time ? $order_time . ':00'                    : null;

    $customer_name  = trim( $wc_order->get_billing_first_name() . ' ' . $wc_order->get_billing_last_name() );
    $customer_email = $wc_order->get_billing_email();
    $customer_phone = $wc_order->get_billing_phone();

    $inserted = $wpdb->insert( $orders_table, array(
        'wc_order_id'      => $wc_order->get_id(),
        'payment_status'   => 'pending',
        'order_number'     => $order_number,
        'status'           => 'new',
        'fulfillment'      => $fulfillment,
        'order_date'       => $order_date_val,
        'order_time'       => $order_time_val,
        'subtotal'         => round( $subtotal, 2 ),
        'delivery_fee'     => $delivery_fee,
        'tax'              => $tax,
        'tip'              => $tip,
        'customer_name'    => $customer_name,
        'customer_phone'   => $customer_phone,
        'customer_email'   => $customer_email,
        'delivery_address' => $delivery_address,
        'notes'            => $notes,
        'created_at'       => current_time('mysql'),
    ) );

    if ( ! $inserted ) return; // DB error — WC order still created, just no CaterMe record

    $caterme_order_id = $wpdb->insert_id;

    // Save back-reference in WC order meta
    $wc_order->update_meta_data( '_caterme_order_id',     $caterme_order_id );
    $wc_order->update_meta_data( '_caterme_order_number', $order_number );
    $wc_order->save();

    // ── Create caterme_order_items rows ───────────────────────────────────────
    foreach ( $wc_items as $wc_item ) {
        $product_id   = $wc_item->get_product_id();
        $qty          = $wc_item->get_quantity();
        $unit_price   = round( floatval( $wc_item->get_meta('_caterme_unit_price') ?: ($wc_item->get_subtotal() / max(1,$qty)) ), 2 );
        $line_total   = round( $unit_price * $qty, 2 );
        $selections_str = $wc_item->get_meta('Selections') ?: '';
        $dietary_str    = $wc_item->get_meta('Dietary')    ?: '';
        $label_name     = $wc_item->get_meta('Label Name') ?: '';

        $wpdb->insert( $items_table, array(
            'order_id'   => $caterme_order_id,
            'item_name'  => $wc_item->get_name(),
            'qty'        => $qty,
            'unit_price' => $unit_price,
            'line_total' => $line_total,
            'selections' => wp_json_encode( $selections_str ? explode( ' · ', $selections_str ) : array() ),
            'dietary'    => $dietary_str,
            'label_name' => $label_name,
        ) );
    }

    // ── Notify staff ──────────────────────────────────────────────────────────
    if ( function_exists('caterme_notify_new_order') ) {
        caterme_notify_new_order( $caterme_order_id );
    }

    // ── Google Sheets webhook ─────────────────────────────────────────────────
    $webhook = $settings['sheets_webhook'] ?? '';
    if ( $webhook ) {
        $payload = array(
            'order_number'   => $order_number,
            'timestamp'      => current_time('c'),
            'fulfillment'    => $fulfillment,
            'orderDate'      => $order_date,
            'orderTime'      => $order_time,
            'subtotal'       => round($subtotal,2),
            'customer_name'  => $customer_name,
            'customer_phone' => $customer_phone,
            'customer_email' => $customer_email,
            'notes'          => $notes,
        );
        wp_remote_post( $webhook, array(
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($payload),
            'timeout' => 10,
            'blocking' => false,
        ) );
    }
} );

// ─── Pre-fill WC billing fields from CaterMe session ──────────────────────────
add_filter( 'woocommerce_checkout_get_value', function( $value, $input ) {
    $session = WC()->session ? WC()->session->get('caterme_checkout') : null;
    if ( ! is_array($session) ) return $value;

    if ( $input === 'billing_first_name' && $session['customer_name'] ) {
        $parts = explode(' ', $session['customer_name'], 2);
        return $parts[0] ?? $value;
    }
    if ( $input === 'billing_last_name' && $session['customer_name'] ) {
        $parts = explode(' ', $session['customer_name'], 2);
        return $parts[1] ?? $value;
    }
    if ( $input === 'billing_email' && $session['customer_email'] ) return $session['customer_email'];
    if ( $input === 'billing_phone' && $session['customer_phone'] ) return $session['customer_phone'];

    return $value;
}, 10, 2 );

// ─── Show CaterMe fulfillment info in WC admin order view ─────────────────────
add_action( 'woocommerce_admin_order_data_after_shipping_address', function( $order ) {
    $fulfillment = $order->get_meta('_caterme_fulfillment');
    if ( ! $fulfillment ) return;
    $date    = $order->get_meta('_caterme_order_date');
    $time    = $order->get_meta('_caterme_order_time');
    $addr    = $order->get_meta('_caterme_delivery_address');
    $cm_id   = $order->get_meta('_caterme_order_id');
    $cm_num  = $order->get_meta('_caterme_order_number');
    echo '<div style="padding:12px 0;border-top:1px solid #eee;margin-top:10px;">';
    echo '<h4 style="margin:0 0 8px;font-size:12px;text-transform:uppercase;color:#888;">CaterMe</h4>';
    if ( $cm_num ) echo '<p style="margin:2px 0;font-size:12px;"><strong>Order:</strong> ' . esc_html($cm_num) . ( $cm_id ? ' <a href="'.admin_url('admin.php?page=caterme-orders&view='.$cm_id).'">View ↗</a>' : '' ) . '</p>';
    echo '<p style="margin:2px 0;font-size:12px;"><strong>Type:</strong> ' . esc_html(ucfirst($fulfillment)) . '</p>';
    if ( $date ) echo '<p style="margin:2px 0;font-size:12px;"><strong>Date:</strong> ' . esc_html(date('l, F j, Y', strtotime($date))) . '</p>';
    if ( $time ) echo '<p style="margin:2px 0;font-size:12px;"><strong>Time:</strong> ' . esc_html(date('g:i a', strtotime($time))) . '</p>';
    if ( $addr ) echo '<p style="margin:2px 0;font-size:12px;"><strong>Address:</strong> ' . esc_html($addr) . '</p>';
    echo '</div>';
} );
