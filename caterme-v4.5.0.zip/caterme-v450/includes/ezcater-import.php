<?php
/**
 * ezCater Order Import Feature
 * Temporary import system until ezCater API integration is complete
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Add Import ezCater Order submenu
 */
add_action( 'admin_menu', function() {
    add_submenu_page(
        'caterme-orders',
        'Import ezCater Order',
        '📥 Import ezCater',
        'manage_options',
        'caterme-import-ezcater',
        'caterme_import_ezcater_page'
    );
}, 15 );

/**
 * Render the Import ezCater Order page
 */
function caterme_import_ezcater_page() {
    global $wpdb;
    
    // Handle form submission
    $import_result = null;
    if ( isset($_POST['caterme_import_submit']) && check_admin_referer('caterme_import_ezcater', 'caterme_import_nonce') ) {
        $import_result = caterme_process_ezcater_import( $_FILES['json_file'] ?? null, $_POST );
    }
    
    ?>
    <div class="wrap">
        <h1>
            <?php echo esc_html( get_admin_page_title() ); ?>
            <span style="background: #ffc107; color: #000; padding: 4px 8px; border-radius: 3px; font-size: 12px; margin-left: 10px;">TEMPORARY</span>
        </h1>
        
        <div class="notice notice-info">
            <p><strong>ℹ️ Temporary Feature:</strong> This import tool will be replaced once ezCater API integration is complete. Use this to manually upload ezCater order JSON files.</p>
        </div>
        
        <?php if ( $import_result ): ?>
            <?php if ( $import_result['success'] ): ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>✓ Success!</strong> <?php echo esc_html( $import_result['message'] ); ?></p>
                    <?php if ( isset($import_result['order_id']) ): ?>
                    <p>
                        <a href="<?php echo admin_url( 'admin.php?page=caterme-orders&order_id=' . $import_result['order_id'] ); ?>" class="button button-primary">
                            View Order #<?php echo esc_html( $import_result['order_number'] ); ?>
                        </a>
                        <a href="<?php echo admin_url( 'admin.php?page=caterme-print&order_id=' . $import_result['order_id'] . '&type=labels' ); ?>" class="button" target="_blank">
                            Print Labels
                        </a>
                    </p>
                    <p style="font-size: 13px; color: #666;">
                        <strong>Order Details:</strong><br>
                        Order ID: <?php echo esc_html( $import_result['order_id'] ); ?><br>
                        Items: <?php echo esc_html( $import_result['items_count'] ); ?><br>
                        Subtotal: $<?php echo number_format( $import_result['subtotal'], 2 ); ?>
                    </p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="notice notice-error is-dismissible">
                    <p><strong>✗ Error!</strong> <?php echo esc_html( $import_result['message'] ); ?></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2>Upload ezCater Order JSON</h2>
            
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'caterme_import_ezcater', 'caterme_import_nonce' ); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="json_file">JSON File <span style="color: #d63638;">*</span></label>
                        </th>
                        <td>
                            <input type="file" name="json_file" id="json_file" accept=".json" required style="margin-bottom: 8px;">
                            <p class="description">
                                Upload the JSON file exported from your ezCater order processing system.<br>
                                Maximum file size: 5MB
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="unit_price">Default Unit Price</label>
                        </th>
                        <td>
                            <span style="font-size: 18px; color: #666;">$</span>
                            <input type="number" name="unit_price" id="unit_price" value="12.00" step="0.01" min="0" style="width: 100px;">
                            <p class="description">Price per item (used if not specified in JSON). You can edit individual prices after import.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="order_status">Initial Status</label>
                        </th>
                        <td>
                            <select name="order_status" id="order_status">
                                <option value="new">New</option>
                                <option value="confirmed" selected>Confirmed</option>
                                <option value="preparing">Preparing</option>
                            </select>
                            <p class="description">The imported order will be created with this status.</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="caterme_import_submit" class="button button-primary" value="Import Order">
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 Expected JSON Format</h3>
            <p>Your JSON file should follow this structure:</p>
            <pre style="background: #f6f7f7; padding: 15px; overflow-x: auto; font-size: 12px; border: 1px solid #dcdcde; border-radius: 4px;">{
  "order_number": "Y9Y-ZVJ",
  "customer_name": "John Doe",
  "customer_phone": "555-1234",
  "customer_email": "john@example.com",
  "fulfillment_type": "delivery",
  "fulfillment_date": "2026-02-26",
  "fulfillment_time": "10:15 AM",
  "delivery_address": "123 Main St, City, ST 12345",
  "headcount": 100,
  "items": [
    {
      "item_number": 1,
      "label_name": "Jane Smith",
      "item_name": "Premium Box Lunch",
      "selections": "Turkey Sandwich on White, Assorted Sides",
      "dietary_restrictions": ["No Onion", "Gluten-Free"]
    }
  ]
}</pre>
            
            <h4 style="margin-top: 20px;">Field Descriptions:</h4>
            <table class="widefat" style="margin-top: 10px;">
                <thead>
                    <tr>
                        <th style="width: 200px;">Field</th>
                        <th>Description</th>
                        <th style="width: 100px;">Required</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>order_number</code></td>
                        <td>Unique ezCater order number</td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td><code>customer_name</code></td>
                        <td>Name of the customer placing the order</td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td><code>customer_phone</code></td>
                        <td>Contact phone number</td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td><code>customer_email</code></td>
                        <td>Contact email address</td>
                        <td>No</td>
                    </tr>
                    <tr>
                        <td><code>fulfillment_type</code></td>
                        <td>"pickup" or "delivery"</td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td><code>fulfillment_date</code></td>
                        <td>Date in YYYY-MM-DD format</td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td><code>fulfillment_time</code></td>
                        <td>Time (e.g., "10:15 AM")</td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td><code>delivery_address</code></td>
                        <td>Full delivery address (required if delivery)</td>
                        <td>Conditional</td>
                    </tr>
                    <tr>
                        <td><code>items</code></td>
                        <td>Array of order items (see structure above)</td>
                        <td>Yes</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <style>
        .card h3 { margin-top: 0; }
        .card pre { white-space: pre-wrap; word-wrap: break-word; }
        .widefat code { background: #f0f0f1; padding: 2px 6px; border-radius: 2px; font-size: 11px; }
    </style>
    <?php
}

/**
 * Process ezCater JSON import
 */
function caterme_process_ezcater_import( $file, $post_data ) {
    global $wpdb;
    
    // Validate file upload
    if ( ! $file || empty( $file['tmp_name'] ) ) {
        return array(
            'success' => false,
            'message' => 'No file uploaded. Please select a JSON file.'
        );
    }
    
    // Check file type
    $file_extension = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
    if ( $file_extension !== 'json' ) {
        return array(
            'success' => false,
            'message' => 'Invalid file type. Please upload a .json file.'
        );
    }
    
    // Check file size (5MB max)
    if ( $file['size'] > 5 * 1024 * 1024 ) {
        return array(
            'success' => false,
            'message' => 'File is too large. Maximum size is 5MB.'
        );
    }
    
    // Read and parse JSON
    $json_content = file_get_contents( $file['tmp_name'] );
    $order_data = json_decode( $json_content, true );
    
    if ( json_last_error() !== JSON_ERROR_NONE ) {
        return array(
            'success' => false,
            'message' => 'Invalid JSON file: ' . json_last_error_msg()
        );
    }
    
    // Validate required fields
    $required_fields = array( 'order_number', 'customer_name', 'customer_phone', 'fulfillment_type', 'fulfillment_date', 'fulfillment_time', 'items' );
    foreach ( $required_fields as $field ) {
        if ( empty( $order_data[ $field ] ) ) {
            return array(
                'success' => false,
                'message' => "Missing required field: {$field}"
            );
        }
    }
    
    // Validate items array
    if ( ! is_array( $order_data['items'] ) || count( $order_data['items'] ) === 0 ) {
        return array(
            'success' => false,
            'message' => 'Order must contain at least one item.'
        );
    }
    
    // Get settings
    $unit_price = floatval( $post_data['unit_price'] ?? 12.00 );
    $order_status = sanitize_text_field( $post_data['order_status'] ?? 'confirmed' );
    
    // Parse fulfillment date and time
    $fulfillment_date = sanitize_text_field( $order_data['fulfillment_date'] );
    $fulfillment_time = sanitize_text_field( $order_data['fulfillment_time'] );
    
    // Convert time to 24-hour format for database
    $time_obj = date_create_from_format( 'g:i A', $fulfillment_time );
    if ( ! $time_obj ) {
        $time_obj = date_create_from_format( 'H:i', $fulfillment_time );
    }
    $fulfillment_time_db = $time_obj ? $time_obj->format('H:i:s') : '00:00:00';
    
    // Calculate totals
    $items_count = count( $order_data['items'] );
    $subtotal = $items_count * $unit_price;
    
    // Start transaction
    $wpdb->query( 'START TRANSACTION' );
    
    try {
        // Insert order
        $orders_table = $wpdb->prefix . 'caterme_orders';
        
        $order_insert = $wpdb->insert(
            $orders_table,
            array(
                'order_number'     => sanitize_text_field( $order_data['order_number'] ),
                'customer_name'    => sanitize_text_field( $order_data['customer_name'] ),
                'customer_phone'   => sanitize_text_field( $order_data['customer_phone'] ),
                'customer_email'   => sanitize_email( $order_data['customer_email'] ?? '' ),
                'fulfillment'      => strtolower( sanitize_text_field( $order_data['fulfillment_type'] ) ),
                'order_date'       => $fulfillment_date,
                'order_time'       => $fulfillment_time_db,
                'delivery_address' => sanitize_textarea_field( $order_data['delivery_address'] ?? '' ),
                'subtotal'         => $subtotal,
                'delivery_fee'     => 0.00,
                'tax'              => 0.00,
                'tip'              => 0.00,
                'status'           => $order_status,
                'payment_status'   => 'none',
                'notes'            => 'Imported from ezCater. Headcount: ' . intval( $order_data['headcount'] ?? 0 ),
                'created_at'       => current_time( 'mysql' )
            ),
            array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%f', '%f', '%f', '%s', '%s', '%s', '%s' )
        );
        
        if ( $order_insert === false ) {
            throw new Exception( 'Failed to insert order: ' . $wpdb->last_error );
        }
        
        $order_id = $wpdb->insert_id;
        
        // Insert order items
        $items_table = $wpdb->prefix . 'caterme_order_items';
        $items_inserted = 0;
        
        foreach ( $order_data['items'] as $item ) {
            // Validate item has required fields
            if ( empty( $item['item_name'] ) ) {
                continue;
            }
            
            $quantity = 1;
            $line_total = $quantity * $unit_price;
            
            // Format dietary restrictions
            $dietary = '';
            if ( ! empty( $item['dietary_restrictions'] ) && is_array( $item['dietary_restrictions'] ) ) {
                $dietary = implode( ', ', array_map( 'sanitize_text_field', $item['dietary_restrictions'] ) );
            }
            
            // Format selections as JSON
            $selections = wp_json_encode( array(
                'text' => sanitize_textarea_field( $item['selections'] ?? '' )
            ) );
            
            $item_insert = $wpdb->insert(
                $items_table,
                array(
                    'order_id'   => $order_id,
                    'item_name'  => sanitize_text_field( $item['item_name'] ),
                    'qty'        => $quantity,
                    'unit_price' => $unit_price,
                    'line_total' => $line_total,
                    'label_name' => sanitize_text_field( $item['label_name'] ?? '' ),
                    'selections' => $selections,
                    'dietary'    => $dietary
                ),
                array( '%d', '%s', '%d', '%f', '%f', '%s', '%s', '%s' )
            );
            
            if ( $item_insert === false ) {
                throw new Exception( 'Failed to insert item: ' . $wpdb->last_error );
            }
            
            $items_inserted++;
        }
        
        // Commit transaction
        $wpdb->query( 'COMMIT' );
        
        return array(
            'success'      => true,
            'message'      => "Order imported successfully! {$items_inserted} items added.",
            'order_id'     => $order_id,
            'order_number' => $order_data['order_number'],
            'items_count'  => $items_inserted,
            'subtotal'     => $subtotal
        );
        
    } catch ( Exception $e ) {
        // Rollback on error
        $wpdb->query( 'ROLLBACK' );
        
        return array(
            'success' => false,
            'message' => 'Import failed: ' . $e->getMessage()
        );
    }
}
