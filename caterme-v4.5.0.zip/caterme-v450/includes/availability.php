<?php
/**
 * CaterMe — Availability / Blackout System
 *
 * Stores blackout rules in caterme_settings under two keys:
 *   pickup_availability   JSON {closed_days:[0,6], blocked_dates:["2026-12-25",...], hours:{open:"09:00",close:"17:00"}}
 *   delivery_availability JSON same structure
 *
 * REST GET caterme/v1/availability — returns both configs for frontend validation.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Defaults ──────────────────────────────────────────────────────────────────
function caterme_availability_defaults() {
    return array(
        'closed_days'    => array(),       // day-of-week ints 0=Sun … 6=Sat
        'blocked_dates'  => array(),       // ["YYYY-MM-DD",...]
        'open_time'      => '',            // "HH:MM" 24h, empty = no restriction
        'close_time'     => '',
    );
}

function caterme_get_availability( $type = 'pickup' ) {
    $s   = caterme_get_settings();
    $key = $type === 'delivery' ? 'delivery_availability' : 'pickup_availability';
    $raw = $s[$key] ?? '{}';
    $data = json_decode( $raw, true );
    if ( ! is_array($data) ) $data = array();
    return array_merge( caterme_availability_defaults(), $data );
}

// ── REST endpoint ─────────────────────────────────────────────────────────────
add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/availability', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function() {
            return new WP_REST_Response( array(
                'pickup'   => caterme_get_availability('pickup'),
                'delivery' => caterme_get_availability('delivery'),
            ), 200 );
        },
    ));
});

// ── Sanitizer for settings save ───────────────────────────────────────────────
function caterme_sanitize_availability( $raw ) {
    $data = is_array($raw) ? $raw : ( json_decode( wp_unslash($raw), true ) ?: array() );

    $closed_days = array();
    foreach ( (array)($data['closed_days'] ?? array()) as $d ) {
        $di = absint($d);
        if ( $di >= 0 && $di <= 6 ) $closed_days[] = $di;
    }

    $blocked_dates = array();
    foreach ( (array)($data['blocked_dates'] ?? array()) as $dt ) {
        $dt = sanitize_text_field($dt);
        if ( preg_match('/^\d{4}-\d{2}-\d{2}$/', $dt) ) $blocked_dates[] = $dt;
    }

    $open  = sanitize_text_field( $data['open_time']  ?? '' );
    $close = sanitize_text_field( $data['close_time'] ?? '' );
    if ( ! preg_match('/^\d{2}:\d{2}$/', $open)  ) $open  = '';
    if ( ! preg_match('/^\d{2}:\d{2}$/', $close) ) $close = '';

    return array(
        'closed_days'   => array_values( array_unique($closed_days) ),
        'blocked_dates' => array_values( array_unique($blocked_dates) ),
        'open_time'     => $open,
        'close_time'    => $close,
    );
}

// ── Date / time validation helpers ───────────────────────────────────────────
function caterme_is_date_available( $date_str, $type = 'pickup' ) {
    if ( ! $date_str || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_str ) ) return false;
    $avail = caterme_get_availability( $type );
    if ( in_array( $date_str, $avail['blocked_dates'] ) ) return false;
    $dow = (int) date( 'w', strtotime( $date_str ) );
    if ( in_array( $dow, $avail['closed_days'] ) ) return false;
    return true;
}

/**
 * Full date + time validation. Returns true or an error string.
 */
function caterme_validate_datetime( $date_str, $time_str, $type = 'pickup' ) {
    if ( ! $date_str ) return 'Please select a date.';
    if ( ! caterme_is_date_available( $date_str, $type ) ) {
        $label = ( $type === 'delivery' ) ? 'delivery' : 'pick-up';
        return "Sorry, {$label} is not available on that date. Please choose another day.";
    }
    $avail = caterme_get_availability( $type );
    if ( $time_str && $avail['open_time'] && $avail['close_time'] ) {
        $t     = strtotime( $date_str . ' ' . $time_str );
        $open  = strtotime( $date_str . ' ' . $avail['open_time'] );
        $close = strtotime( $date_str . ' ' . $avail['close_time'] );
        if ( $t < $open || $t > $close ) {
            $label = ( $type === 'delivery' ) ? 'Delivery' : 'Pick up';
            return "{$label} hours are " . date('g:i a', $open) . ' – ' . date('g:i a', $close) . '. Please choose a time within that window.';
        }
    }
    return true;
}
