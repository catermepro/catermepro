<?php
/**
 * CaterMe — Menu Manager
 * Stores the full menu as JSON in wp_options (caterme_menu).
 * Provides a REST API for saving and a full admin CRUD UI.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Default menu ─────────────────────────────────────────────────────────────
// Used on first activation. Includes a realistic sample menu that operators
// can edit or replace entirely.

function caterme_default_menu() {
    return array(
        'categories' => array(

            // ── Boxes ─────────────────────────────────────────────────────────
            array(
                'id'   => 'boxes',
                'name' => 'Boxes',
                'icon' => '🥡',
                'tags' => array('Sandwich','Wrap','Salad'),
                'items' => array(

                    // Sandwich Boxes
                    array(
                        'id' => 'std-sandwich', 'name' => 'Standard Sandwich Box', 'price' => 12,
                        'tag' => 'Sandwich', 'unit' => '',
                        'description' => 'Choice of one protein, homemade chicken salad, or Papa\'s pimento cheese. Served on a mini-bun with cheddar cheese, lettuce, tomato, and red onion (or half Veg wrap). Includes pickle spear, Zapp\'s chips or small homemade potato salad, and a cookie. *GF bread +$2.00',
                        'options' => array(
                            array('key'=>'protein','label'=>'Protein / Filling','type'=>'select','required'=>true,'choices'=>array('Homemade Chicken Salad','Papa\'s Pimento Cheese','Ham','Chicken','Turkey','Roast Beef','Corned Beef'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Small Homemade Potato Salad','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'gf','label'=>'Gluten-Free Bread (+$2.00)','type'=>'toggle','required'=>false,'choices'=>array(),'price'=>2,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'prem-sandwich', 'name' => 'Premium Sandwich Box', 'price' => 15,
                        'tag' => 'Sandwich', 'unit' => '',
                        'description' => 'Full sandwich with choice of one protein, Club, chicken salad, or Papa\'s pimento cheese. Served on wheat or white bread with cheddar cheese, lettuce, tomato, and red onion. Includes pickle spear, Zapp\'s chips or small homemade potato salad, and a cookie. *GF bread +$2.00',
                        'options' => array(
                            array('key'=>'protein','label'=>'Protein / Filling','type'=>'select','required'=>true,'choices'=>array('Club','Homemade Chicken Salad','Papa\'s Pimento Cheese','Ham','Chicken','Turkey','Roast Beef','Corned Beef'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'bread','label'=>'Bread','type'=>'select','required'=>true,'choices'=>array('Wheat','White'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Small Homemade Potato Salad','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'gf','label'=>'Gluten-Free Bread (+$2.00)','type'=>'toggle','required'=>false,'choices'=>array(),'price'=>2,'min'=>1,'default'=>1),
                        ),
                    ),

                    // Wrap Boxes
                    array(
                        'id' => 'std-wrap', 'name' => 'Standard Wrap Box', 'price' => 15,
                        'tag' => 'Wrap', 'unit' => '',
                        'description' => 'Choice of one protein, cheddar cheese, lettuce, tomato, and onion. Served on white or wheat wrap with pickle spear, Zapp\'s chips, and a cookie. Mustard and mayo packet included.',
                        'options' => array(
                            array('key'=>'protein','label'=>'Protein','type'=>'select','required'=>true,'choices'=>array('Ham','Chicken','Turkey','Roast Beef','Corned Beef'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'wrap','label'=>'Wrap Type','type'=>'select','required'=>true,'choices'=>array('White','Wheat'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'hbh-wrap', 'name' => 'The HBH Wrap Box', 'price' => 15,
                        'tag' => 'Wrap', 'unit' => '',
                        'description' => 'Ham, bacon, cheddar cheese, shredded lettuce, tomato, red onion, and honey mustard. Served on white or wheat wrap with pickle spear, Zapp\'s chips, and a cookie.',
                        'options' => array(
                            array('key'=>'wrap','label'=>'Wrap Type','type'=>'select','required'=>true,'choices'=>array('White','Wheat'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'chicken-caesar-wrap', 'name' => 'Chicken Caesar Wrap Box', 'price' => 15,
                        'tag' => 'Wrap', 'unit' => '',
                        'description' => 'Sliced rotisserie chicken, romaine lettuce, croutons, shredded Parmesan, Caesar dressing. Served on white or wheat wrap with pickle spear, Zapp\'s chips, and a cookie.',
                        'options' => array(
                            array('key'=>'wrap','label'=>'Wrap Type','type'=>'select','required'=>true,'choices'=>array('White','Wheat'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),

                    // Salad Boxes
                    array(
                        'id' => 'house-salad', 'name' => 'House Salad Box', 'price' => 15,
                        'tag' => 'Salad', 'unit' => '',
                        'description' => 'Shredded iceberg lettuce with choice of protein, diced tomato, red onion, shredded cheddar cheese, and croutons. Accompanied by homemade dressings. Served with Zapp\'s chips, a cookie, and a utensil packet.',
                        'options' => array(
                            array('key'=>'protein','label'=>'Protein','type'=>'select','required'=>true,'choices'=>array('Ham','Chicken','Turkey','Roast Beef','Corned Beef'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array('Ranch','Spicy Ranch','Italian','Greek','Honey Mustard','Caesar'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'veggie-salad', 'name' => 'Veggie Salad Box', 'price' => 14,
                        'tag' => 'Salad', 'unit' => '',
                        'description' => 'Shredded iceberg lettuce, diced tomato, onion, cucumber, carrot, bell pepper, banana peppers, and shredded cheddar cheese. Accompanied by homemade dressings. Served with Zapp\'s chips, a cookie, and a utensil packet.',
                        'options' => array(
                            array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array('Ranch','Spicy Ranch','Italian','Greek','Honey Mustard','Caesar'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'club-salad', 'name' => 'Classic Club Salad Box', 'price' => 16,
                        'tag' => 'Salad', 'unit' => '',
                        'description' => 'Shredded iceberg lettuce, ham, turkey, bacon, diced tomato, red onion, croutons. Accompanied by homemade dressings. Served with Zapp\'s chips, a cookie, and a utensil packet.',
                        'options' => array(
                            array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array('Ranch','Spicy Ranch','Italian','Greek','Honey Mustard','Caesar'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'caesar-salad', 'name' => 'Chicken Caesar Salad Box', 'price' => 15,
                        'tag' => 'Salad', 'unit' => '',
                        'description' => 'Romaine lettuce, sliced rotisserie chicken, shredded Parmesan cheese, croutons. Accompanied by homemade dressings. Served with Zapp\'s chips, a cookie, and a utensil packet.',
                        'options' => array(
                            array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array('Ranch','Spicy Ranch','Italian','Greek','Honey Mustard','Caesar'),'price'=>0,'min'=>1,'default'=>1),
                            array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array('Zapp\'s Chips','Upgrade to Hal\'s Chips (+$0.75)'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                ),
            ),

            // ── Platters ──────────────────────────────────────────────────────
            array(
                'id'   => 'platters',
                'name' => 'Platters',
                'icon' => '🍽️',
                'tags' => array(),
                'items' => array(
                    array(
                        'id' => 'sandwich-tray', 'name' => 'Sandwich Tray', 'price' => 81,
                        'tag' => '', 'unit' => '',
                        'description' => '18 mini-buns filled with your choice of any of our proteins, or The Veg, topped with lettuce and tomato. Served with onions on the side and mayo/mustard packets.',
                        'options' => array(
                            array('key'=>'protein','label'=>'Protein / Filling','type'=>'select','required'=>true,'choices'=>array('The Veg','Ham','Chicken','Turkey','Roast Beef','Corned Beef','Homemade Chicken Salad','Papa\'s Pimento Cheese'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                ),
            ),

            // ── Sides ─────────────────────────────────────────────────────────
            array(
                'id'   => 'sides',
                'name' => 'Sides',
                'icon' => '🥔',
                'tags' => array(),
                'items' => array(
                    array(
                        'id' => 'hals-chips', 'name' => "Assorted Hal's Chips", 'price' => 3,
                        'tag' => '', 'unit' => '',
                        'description' => 'Imported directly from New York City, and unique to us.',
                        'options' => array(),
                    ),
                    array(
                        'id' => 'potato-salad', 'name' => 'Signature Potato Salad', 'price' => 10,
                        'tag' => '', 'unit' => '/lb',
                        'description' => 'Diced potatoes in a creamy mayo and mustard dressing. Serves approx. 4 individuals per pound.',
                        'options' => array(
                            array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'coleslaw', 'name' => 'Cole Slaw', 'price' => 7,
                        'tag' => '', 'unit' => '/lb',
                        'description' => 'Red & white cabbage, carrot, in a creamy coleslaw dressing. Serves approx. 5 individuals per pound.',
                        'options' => array(
                            array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'pasta-salad', 'name' => 'Rotating Pasta Salad', 'price' => 9,
                        'tag' => '', 'unit' => '/lb',
                        'description' => 'Inquire about this week\'s pasta salad. Serves approx. 4 individuals per pound. For specific requests, please provide 48-hour notice.',
                        'options' => array(
                            array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'fruit', 'name' => 'Fresh Cut Fruit', 'price' => 8,
                        'tag' => '', 'unit' => '/lb',
                        'description' => 'Selection of freshly diced fruit. Fruit selection dependent on season and market availability. Serves approx. 5 individuals per pound.',
                        'options' => array(
                            array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                ),
            ),

            // ── Drinks ────────────────────────────────────────────────────────
            array(
                'id'   => 'drinks',
                'name' => 'Drinks',
                'icon' => '🥤',
                'tags' => array(),
                'items' => array(
                    array('id'=>'soft-drink','name'=>'Assorted Bottled Soft Drinks','price'=>3,'tag'=>'','unit'=>'','description'=>'Assorted flavors.','options'=>array()),
                    array('id'=>'gold-peak','name'=>'Assorted Bottled Gold Peak Tea','price'=>3,'tag'=>'','unit'=>'','description'=>'Assorted varieties.','options'=>array()),
                    array('id'=>'water','name'=>'Dasani Bottled Water','price'=>3,'tag'=>'','unit'=>'','description'=>'','options'=>array()),
                ),
            ),

            // ── Desserts ──────────────────────────────────────────────────────
            array(
                'id'   => 'desserts',
                'name' => 'Desserts',
                'icon' => '🍪',
                'tags' => array(),
                'items' => array(
                    array(
                        'id' => 'brownie', 'name' => 'Killer Brownie', 'price' => 3.5,
                        'tag' => '', 'unit' => '',
                        'description' => 'Choose from either Brookie (Chocolate chip cookie brownie) or Chocolatier.',
                        'options' => array(
                            array('key'=>'type','label'=>'Brownie Type','type'=>'select','required'=>true,'choices'=>array('Brookie (Chocolate Chip Cookie Brownie)','Chocolatier'),'price'=>0,'min'=>1,'default'=>1),
                        ),
                    ),
                    array(
                        'id' => 'cookie', 'name' => 'Chocolate Chip Cookie', 'price' => 2,
                        'tag' => '', 'unit' => '',
                        'description' => 'Baked fresh and individually wrapped. Other cookie options available with 48-hour notice.',
                        'options' => array(),
                    ),
                ),
            ),

        ),
    );
}

// ─── Get / Save ───────────────────────────────────────────────────────────────

define( 'CATERME_MENU_SEED_VERSION', '2' ); // bump to re-seed default menu on existing installs

function caterme_get_menu() {
    // Auto-seed the full menu if it's never been saved or is on an older seed version
    if ( get_option('caterme_menu_seed_version') !== CATERME_MENU_SEED_VERSION ) {
        $default = caterme_default_menu();
        caterme_save_menu( $default );
        update_option( 'caterme_menu_seed_version', CATERME_MENU_SEED_VERSION );
        return $default;
    }
    $raw = get_option( 'caterme_menu', null );
    if ( $raw !== null && $raw !== false ) {
        $decoded = json_decode( $raw, true );
        if ( is_array($decoded) && isset($decoded['categories']) ) return $decoded;
    }
    return caterme_default_menu();
}

function caterme_save_menu( $menu ) {
    return update_option( 'caterme_menu', wp_json_encode($menu), false );
}

// ─── REST API ─────────────────────────────────────────────────────────────────

add_action( 'rest_api_init', 'caterme_register_menu_api' );

function caterme_register_menu_api() {
    register_rest_route( 'caterme/v1', '/menu', array(
        array(
            'methods'             => 'GET',
            'callback'            => function() { return new WP_REST_Response( caterme_get_menu(), 200 ); },
            'permission_callback' => function() { return current_user_can('manage_options'); },
        ),
        array(
            'methods'             => 'POST',
            'callback'            => 'caterme_handle_save_menu',
            'permission_callback' => function() { return current_user_can('manage_options'); },
        ),
    ));
}

function caterme_handle_save_menu( WP_REST_Request $request ) {
    $menu = $request->get_json_params();

    // Reset to defaults
    if ( ! empty($menu['reset']) ) {
        delete_option('caterme_menu');
        delete_option('caterme_menu_seed_version');
        return new WP_REST_Response( array('success'=>true,'message'=>'Reset to defaults.'), 200 );
    }

    if ( ! $menu || ! isset($menu['categories']) || ! is_array($menu['categories']) ) {
        return new WP_REST_Response( array('success'=>false,'message'=>'Invalid menu data.'), 400 );
    }

    $clean = array( 'categories' => array() );

    foreach ( $menu['categories'] as $cat ) {
        $cat_id = sanitize_key( $cat['id'] ?? '' );
        if ( ! $cat_id ) $cat_id = 'cat-' . substr( md5(uniqid()), 0, 8 );

        $clean_cat = array(
            'id'    => $cat_id,
            'name'  => sanitize_text_field( $cat['name'] ?? 'Category' ),
            'icon'  => sanitize_text_field( $cat['icon'] ?? '🍽️' ),
            'tags'  => array_values( array_filter( array_map( 'sanitize_text_field', (array)($cat['tags'] ?? array()) ) ) ),
            'items' => array(),
        );

        foreach ( ($cat['items'] ?? array()) as $item ) {
            $item_id = sanitize_key( $item['id'] ?? '' );
            if ( ! $item_id ) $item_id = 'item-' . substr( md5(uniqid()), 0, 8 );

            $clean_item = array(
                'id'          => $item_id,
                'name'        => sanitize_text_field( $item['name'] ?? '' ),
                'price'       => round( floatval( $item['price'] ?? 0 ), 2 ),
                'description' => sanitize_textarea_field( $item['description'] ?? '' ),
                'tag'         => sanitize_text_field( $item['tag'] ?? '' ),
                'unit'        => sanitize_text_field( $item['unit'] ?? '' ),
                'options'     => array(),
            );

            foreach ( ($item['options'] ?? array()) as $opt ) {
                $opt_key = sanitize_key( $opt['key'] ?? '' );
                if ( ! $opt_key ) $opt_key = 'opt-' . substr( md5(uniqid()), 0, 8 );
                $opt_type = in_array( $opt['type']??'', array('select','toggle','number') ) ? $opt['type'] : 'select';

                $clean_opt = array(
                    'key'      => $opt_key,
                    'label'    => sanitize_text_field( $opt['label'] ?? '' ),
                    'type'     => $opt_type,
                    'required' => (bool)( $opt['required'] ?? false ),
                    'choices'  => array_values( array_filter( array_map( 'sanitize_text_field', (array)($opt['choices'] ?? array()) ) ) ),
                    'price'    => round( floatval( $opt['price'] ?? 0 ), 2 ),
                    'min'      => intval( $opt['min'] ?? 1 ),
                    'default'  => intval( $opt['default'] ?? 1 ),
                );
                $clean_item['options'][] = $clean_opt;
            }

            $clean_cat['items'][] = $clean_item;
        }

        $clean['categories'][] = $clean_cat;
    }

    caterme_save_menu( $clean );
    return new WP_REST_Response( array('success'=>true,'message'=>'Menu saved successfully.'), 200 );
}

// ─── Admin page ───────────────────────────────────────────────────────────────

function caterme_menu_page() {
    $menu    = caterme_get_menu();
    $api_url = rest_url('caterme/v1/menu');
    $nonce   = wp_create_nonce('wp_rest');
    ?>
    <div class="wrap" id="caterme-menu-wrap">
        <h1 style="display:flex;align-items:center;gap:12px;margin-bottom:4px;">
            🍽️ CaterMe — Menu Manager
            <span id="cm-save-status" style="font-size:13px;font-weight:400;color:#666;"></span>
        </h1>
        <p style="color:#666;margin-bottom:20px;">Build your catering menu. Changes are saved when you click <strong>Save Menu</strong>.</p>

        <div style="display:flex;gap:12px;align-items:center;margin-bottom:20px;flex-wrap:wrap;">
            <button id="cm-add-cat" class="button button-secondary" style="font-size:14px;padding:6px 16px;">+ Add Category</button>
            <button id="cm-save" class="button button-primary" style="font-size:14px;padding:6px 18px;">💾 Save Menu</button>
            <button id="cm-reset" class="button" style="color:#cc3333;border-color:#cc3333;font-size:13px;" onclick="if(confirm('Reset to default sample menu? All changes will be lost.'))cmResetMenu();">↩ Reset to Defaults</button>
            <a href="<?php echo admin_url('admin.php?page=caterme-modifiers'); ?>" class="button" style="margin-left:auto;font-size:13px;">🔧 Modifier Templates</a>
        </div>

        <div id="cm-app">Loading...</div>
    </div>

    <!-- ── Category Modal ── -->
    <div id="cm-cat-modal" class="cm-modal-wrap" style="display:none;">
        <div class="cm-modal">
            <h2 id="cm-cat-modal-title">Add Category</h2>
            <input type="hidden" id="cm-cat-idx" value="-1" />
            <div class="cm-field">
                <label>Name *</label>
                <input type="text" id="cm-cat-name" placeholder="e.g. Boxes, Platters, Drinks" class="regular-text" />
            </div>
            <div class="cm-field">
                <label>Icon <span style="color:#888;font-weight:400;">(emoji)</span></label>
                <input type="text" id="cm-cat-icon" placeholder="🍽️" style="width:60px;font-size:20px;text-align:center;" maxlength="4" />
            </div>
            <div class="cm-field">
                <label>Sub-tags <span style="color:#888;font-weight:400;">(comma-separated, optional — e.g. Sandwich, Wrap, Salad)</span></label>
                <input type="text" id="cm-cat-tags" placeholder="Sandwich, Wrap, Salad" class="regular-text" />
                <p style="font-size:12px;color:#888;margin:4px 0 0;">Tags appear as filter buttons above the item grid. Leave blank for no tags.</p>
            </div>
            <div class="cm-modal-footer">
                <button class="button button-primary" onclick="cmSaveCategory()">Save Category</button>
                <button class="button" onclick="cmCloseModal('cm-cat-modal')">Cancel</button>
            </div>
        </div>
    </div>

    <!-- ── Item Modal ── -->
    <div id="cm-item-modal" class="cm-modal-wrap" style="display:none;">
        <div class="cm-modal" style="max-width:700px;">
            <h2 id="cm-item-modal-title">Add Item</h2>
            <input type="hidden" id="cm-item-cat-idx" value="0" />
            <input type="hidden" id="cm-item-idx" value="-1" />

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="cm-field" style="grid-column:1/-1">
                    <label>Item Name *</label>
                    <input type="text" id="cm-item-name" placeholder="e.g. Standard Sandwich Box" class="large-text" />
                </div>
                <div class="cm-field">
                    <label>Price ($) *</label>
                    <input type="number" id="cm-item-price" placeholder="12.00" min="0" step="0.01" style="width:120px;" />
                </div>
                <div class="cm-field">
                    <label>Unit <span style="color:#888;font-weight:400;">(optional, e.g. /lb, /person)</span></label>
                    <input type="text" id="cm-item-unit" placeholder="/lb" style="width:100px;" />
                </div>
                <div class="cm-field">
                    <label>Tag <span style="color:#888;font-weight:400;">(for filtered categories)</span></label>
                    <input type="text" id="cm-item-tag" placeholder="Sandwich" style="width:160px;" list="cm-tag-list" />
                    <datalist id="cm-tag-list"></datalist>
                </div>
                <div class="cm-field" style="grid-column:1/-1">
                    <label>Description</label>
                    <textarea id="cm-item-desc" rows="2" class="large-text" placeholder="Describe what's included..."></textarea>
                </div>
                <div class="cm-field" style="grid-column:1/-1;">
                    <label style="display:flex;align-items:center;gap:8px;font-weight:400;text-transform:none;letter-spacing:0;cursor:pointer;">
                        <input type="checkbox" id="cm-item-no-print" style="width:16px;height:16px;flex-shrink:0;" />
                        <span>
                            <strong style="font-size:13px;">🚫 No Label</strong>
                            <span style="color:#888;font-size:12px;margin-left:6px;">Skip this item when printing Avery labels (e.g. drinks, condiments, bulk items).</span>
                        </span>
                    </label>
                </div>
            </div>

            <!-- Modifiers editor -->
            <div style="margin-top:20px;border-top:1px solid #ddd;padding-top:16px;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                    <h3 style="margin:0;font-size:14px;">Modifiers <span style="color:#888;font-weight:400;font-size:12px;">(protein choices, add-ons, quantities, etc.)</span></h3>
                    <div style="display:flex;gap:8px;">
                        <button class="button button-secondary" onclick="cmAddFromTemplate()" style="font-size:12px;">📋 From Template</button>
                        <button class="button button-secondary" onclick="cmAddModifier()" style="font-size:12px;">+ Add Modifier</button>
                    </div>
                </div>
                <div id="cm-modifiers-list"></div>
            </div>

            <div class="cm-modal-footer">
                <button class="button button-primary" onclick="cmSaveItem()">Save Item</button>
                <button class="button" onclick="cmCloseModal('cm-item-modal')">Cancel</button>
            </div>
        </div>
    </div>

    <!-- ── Option Modal ── -->
    <div id="cm-mod-modal" class="cm-modal-wrap" style="display:none;">
        <div class="cm-modal" style="max-width:520px;">
            <h2 id="cm-mod-modal-title">Add Modifier</h2>
            <input type="hidden" id="cm-mod-idx" value="-1" />
            <div class="cm-field">
                <label>Type *</label>
                <select id="cm-mod-type" onchange="cmModTypeChange(this.value)" class="regular-text">
                    <option value="select">Select — Customer picks one choice from a list</option>
                    <option value="toggle">Toggle — Yes/No add-on (e.g. Gluten-Free Bread)</option>
                    <option value="number">Number — Quantity entry (e.g. pounds)</option>
                </select>
            </div>
            <div class="cm-field">
                <label>Label *</label>
                <input type="text" id="cm-mod-label" placeholder="e.g. Protein, Side, Bread Type" class="regular-text" />
            </div>
            <div id="cm-mod-required-wrap" class="cm-field">
                <label><input type="checkbox" id="cm-mod-required" /> Required</label>
            </div>
            <div id="cm-mod-choices-wrap" class="cm-field">
                <label>Choices <span style="color:#888;font-weight:400;">(one per line)</span></label>
                <textarea id="cm-mod-choices" rows="5" class="large-text" placeholder="Ham&#10;Chicken&#10;Turkey&#10;Roast Beef"></textarea>
            </div>
            <div id="cm-mod-max-sel-wrap" class="cm-field" style="display:none;">
                <label>Max Selections <span style="color:#888;font-weight:400;">How many choices the customer can pick. 0 or 1 = single choice (radio). 2+ = multi-select up to that number.</span></label>
                <input type="number" id="cm-mod-max-sel" value="1" min="0" max="20" style="width:80px;" />
            </div>
            <div id="cm-mod-price-wrap" class="cm-field" style="display:none;">
                <label>Price Add-on ($) <span style="color:#888;font-weight:400;">(leave 0 if free)</span></label>
                <input type="number" id="cm-mod-price" value="0" min="0" step="0.01" style="width:120px;" />
            </div>
            <div id="cm-mod-number-wrap" style="display:none;">
                <div class="cm-field">
                    <label>Minimum Quantity</label>
                    <input type="number" id="cm-mod-min" value="1" min="1" style="width:80px;" />
                </div>
                <div class="cm-field">
                    <label>Default Quantity</label>
                    <input type="number" id="cm-mod-default" value="1" min="1" style="width:80px;" />
                </div>
            </div>
            <div class="cm-modal-footer">
                <button class="button button-primary" onclick="cmSaveModifier()">Save Modifier</button>
                <button class="button" onclick="cmCloseModal('cm-mod-modal')">Cancel</button>
            </div>
        </div>
    </div>

    <!-- ── Template Picker Modal ── -->
    <div id="cm-template-picker" class="cm-modal-wrap" style="display:none;">
        <div class="cm-modal" style="max-width:540px;">
            <h2>📋 Add from Template</h2>
            <p style="font-size:13px;color:#666;margin:-10px 0 16px;">Select one or more modifier templates to add to this item. Existing modifiers with the same key will be skipped.</p>
            <div id="cm-template-list" style="display:flex;flex-direction:column;gap:8px;max-height:360px;overflow-y:auto;margin-bottom:16px;">
                <p style="color:#888;font-size:13px;font-style:italic;">Loading templates…</p>
            </div>
            <div class="cm-modal-footer">
                <button class="button button-primary" onclick="cmApplyTemplates()">Add Selected</button>
                <button class="button" onclick="cmCloseModal('cm-template-picker')">Cancel</button>
                <a href="<?php echo admin_url('admin.php?page=caterme-modifiers'); ?>" target="_blank" style="margin-left:auto;font-size:12px;line-height:2.4;color:#c8832a;">⚙️ Manage Templates →</a>
            </div>
        </div>
    </div>

<style>
.cm-modal-wrap { position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px; }
.cm-modal { background:#fff;border-radius:10px;padding:28px 32px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.35); }
.cm-modal h2 { margin:0 0 20px;font-size:18px;color:#1a1208; }
.cm-field { margin-bottom:14px; }
.cm-field label { display:block;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#5a3e20;margin-bottom:5px; }
.cm-modal-footer { border-top:1px solid #f0e8d8;padding-top:16px;margin-top:20px;display:flex;gap:10px; }
.cm-cat-block { background:#fff;border:1px solid #e0d0b8;border-radius:10px;margin-bottom:14px;overflow:hidden; }
.cm-cat-header { background:#1a1208;color:#f5e6c8;padding:11px 16px;display:flex;align-items:center;gap:10px;cursor:pointer; }
.cm-cat-header:hover { background:#261a0a; }
.cm-cat-title { font-weight:800;font-size:14px;flex:1; }
.cm-cat-actions { display:flex;gap:6px; }
.cm-cat-actions button { background:rgba(255,255,255,.1);color:#f5e6c8;border:1px solid rgba(255,255,255,.2);border-radius:5px;padding:4px 9px;cursor:pointer;font-size:12px; }
.cm-cat-actions button:hover { background:rgba(255,255,255,.2); }
.cm-cat-body { padding:0; }
.cm-items-table { width:100%;border-collapse:collapse; }
.cm-items-table th { background:#faf7f2;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:#7a6040;padding:8px 14px;text-align:left;border-bottom:1px solid #f0e8d8; }
.cm-items-table td { padding:10px 14px;border-bottom:1px solid #f5f0ea;vertical-align:middle;font-size:13px; }
.cm-items-table tr:last-child td { border-bottom:none; }
.cm-items-table tr:hover td { background:#fdfaf5; }
.cm-tag-pill { display:inline-block;border-radius:20px;padding:2px 9px;font-size:11px;font-weight:600;background:#e8f0fe;color:#1e40af;border:1px solid #93c5fd; }
.cm-empty { padding:24px;text-align:center;color:#a07848;font-size:13px; }
.cm-add-item-row td { padding:10px 14px;background:#faf7f2;border-top:1px solid #f0e8d8; }
.cm-opt-row { display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #f0e8d8; }
.cm-template-row { display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border:1.5px solid #e0d0b8;border-radius:8px;cursor:pointer;background:#fff;transition:border-color .15s,background .15s; }
.cm-template-row:hover { border-color:#c8832a;background:#fffbf5; }
.cm-template-row input[type=checkbox] { margin-top:2px;flex-shrink:0;width:16px;height:16px; }
.cm-template-disabled { opacity:.55;cursor:not-allowed; }
.cm-template-disabled:hover { border-color:#e0d0b8;background:#fff; }
.cm-opt-row:last-child { border-bottom:none; }
.cm-opt-type-badge { font-size:10px;padding:2px 7px;border-radius:10px;font-weight:700;text-transform:uppercase; }
.cm-opt-type-select  { background:#e0f2fe;color:#0369a1; }
.cm-opt-type-toggle  { background:#dcfce7;color:#15803d; }
.cm-opt-type-number  { background:#fef9c3;color:#854d0e; }
</style>

<script>
(function() {
    // ── State ──────────────────────────────────────────────────────────────────
    let menu = <?php echo wp_json_encode( $menu ); ?>;
    let dirty = false;
    // While editing an item in the item modal, we hold its options here
    let editingModifiers = [];

    const API_URL  = <?php echo wp_json_encode( $api_url ); ?>;
    const API_NONCE = <?php echo wp_json_encode( $nonce ); ?>;

    function slug(str) {
        return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || ('id-' + Date.now());
    }

    // ── Render ─────────────────────────────────────────────────────────────────
    function render() {
        const app = document.getElementById('cm-app');
        if (!menu.categories || !menu.categories.length) {
            app.innerHTML = '<div class="cm-empty" style="padding:40px;font-size:15px;">No categories yet. Click <strong>+ Add Category</strong> to get started.</div>';
            return;
        }
        app.innerHTML = menu.categories.map((cat, ci) => {
            const hasItems = cat.items && cat.items.length > 0;
            const tagPills = (cat.tags || []).map(t => `<span class="cm-tag-pill">${esc(t)}</span>`).join(' ');
            const itemRows = hasItems ? cat.items.map((item, ii) => `
                <tr>
                    <td>
                        <strong>${esc(item.name)}</strong>
                        ${item.tag ? `<span class="cm-tag-pill" style="margin-left:6px;">${esc(item.tag)}</span>` : ''}
                        ${item.no_print ? `<span style="margin-left:6px;font-size:11px;color:#888;background:#f0f0f0;border:1px solid #ddd;border-radius:4px;padding:1px 6px;">🚫 no label</span>` : ''}
                        ${item.description ? `<div style="font-size:11px;color:#888;margin-top:2px;max-width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(item.description)}</div>` : ''}
                    </td>
                    <td style="white-space:nowrap;font-weight:700;color:#c8832a;">$${parseFloat(item.price).toFixed(2)}${item.unit ? `<span style="font-weight:400;color:#888;font-size:11px;">${esc(item.unit)}</span>` : ''}</td>
                    <td style="color:#888;font-size:12px;">${(item.options||[]).length} option${(item.options||[]).length !== 1 ? 's':''}</td>
                    <td style="white-space:nowrap;">
                        <button onclick="cmMoveItem(${ci},${ii},-1)" class="button" style="padding:3px 7px;min-height:0;" title="Move up" ${ii===0?'disabled':''}>↑</button>
                        <button onclick="cmMoveItem(${ci},${ii},1)"  class="button" style="padding:3px 7px;min-height:0;" title="Move down" ${ii===cat.items.length-1?'disabled':''}>↓</button>
                        <button onclick="cmOpenItem(${ci},${ii})"    class="button" style="padding:3px 8px;min-height:0;">✏️ Edit</button>
                        <button onclick="cmDeleteItem(${ci},${ii})"  class="button" style="padding:3px 8px;min-height:0;color:#cc3333;border-color:#cc3333;">🗑️</button>
                    </td>
                </tr>`).join('') : '';

            return `
            <div class="cm-cat-block">
                <div class="cm-cat-header">
                    <span style="font-size:22px;">${esc(cat.icon||'🍽️')}</span>
                    <span class="cm-cat-title">${esc(cat.name)} ${tagPills ? `<span style="font-weight:400;font-size:12px;opacity:.7;">(${(cat.tags||[]).join(', ')})</span>` : ''}</span>
                    <span style="font-size:12px;color:#b8996a;margin-right:8px;">${(cat.items||[]).length} item${(cat.items||[]).length!==1?'s':''}</span>
                    <div class="cm-cat-actions" onclick="event.stopPropagation()">
                        <button onclick="cmMoveCat(${ci},-1)" title="Move up"   ${ci===0?'disabled':''}>↑</button>
                        <button onclick="cmMoveCat(${ci},1)"  title="Move down" ${ci===menu.categories.length-1?'disabled':''}>↓</button>
                        <button onclick="cmOpenCategory(${ci})">✏️ Edit</button>
                        <button onclick="cmDeleteCat(${ci})" style="color:#ffaa99;">🗑️ Delete</button>
                    </div>
                </div>
                <div class="cm-cat-body">
                    ${hasItems ? `
                    <table class="cm-items-table">
                        <thead><tr>
                            <th>Item</th><th>Price</th><th>Options</th><th style="width:200px;">Actions</th>
                        </tr></thead>
                        <tbody>${itemRows}</tbody>
                    </table>` : `<div class="cm-empty">No items yet.</div>`}
                    <table class="cm-items-table"><tbody>
                        <tr class="cm-add-item-row">
                            <td colspan="4"><button onclick="cmOpenItem(${ci},-1)" class="button button-secondary" style="font-size:13px;">+ Add Item to ${esc(cat.name)}</button></td>
                        </tr>
                    </tbody></table>
                </div>
            </div>`;
        }).join('');
    }

    function esc(s) {
        return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function markDirty() {
        dirty = true;
        document.getElementById('cm-save-status').textContent = '● Unsaved changes';
        document.getElementById('cm-save-status').style.color = '#c8832a';
    }

    // ── Category CRUD ──────────────────────────────────────────────────────────
    function cmOpenCategory(idx) {
        document.getElementById('cm-cat-idx').value = idx;
        document.getElementById('cm-cat-modal-title').textContent = idx === -1 ? 'Add Category' : 'Edit Category';
        const cat = idx === -1 ? {name:'',icon:'🍽️',tags:[]} : menu.categories[idx];
        document.getElementById('cm-cat-name').value = cat.name || '';
        document.getElementById('cm-cat-icon').value = cat.icon || '🍽️';
        document.getElementById('cm-cat-tags').value = (cat.tags||[]).join(', ');
        document.getElementById('cm-cat-modal').style.display = 'flex';
        setTimeout(() => document.getElementById('cm-cat-name').focus(), 50);
    }
    window.cmOpenCategory = cmOpenCategory;

    function cmSaveCategory() {
        const idx    = parseInt(document.getElementById('cm-cat-idx').value);
        const name   = document.getElementById('cm-cat-name').value.trim();
        const icon   = document.getElementById('cm-cat-icon').value.trim() || '🍽️';
        const tagsRaw= document.getElementById('cm-cat-tags').value;
        const tags   = tagsRaw.split(',').map(t=>t.trim()).filter(Boolean);
        if (!name) { alert('Category name is required.'); return; }

        if (idx === -1) {
            menu.categories.push({ id: slug(name), name, icon, tags, items: [] });
        } else {
            menu.categories[idx] = { ...menu.categories[idx], name, icon, tags };
        }
        markDirty(); cmCloseModal('cm-cat-modal'); render();
    }
    window.cmSaveCategory = cmSaveCategory;

    function cmDeleteCat(ci) {
        const cat = menu.categories[ci];
        if (!confirm(`Delete category "${cat.name}" and all ${(cat.items||[]).length} items in it?`)) return;
        menu.categories.splice(ci, 1);
        markDirty(); render();
    }
    window.cmDeleteCat = cmDeleteCat;

    function cmMoveCat(ci, dir) {
        const ni = ci + dir;
        if (ni < 0 || ni >= menu.categories.length) return;
        [menu.categories[ci], menu.categories[ni]] = [menu.categories[ni], menu.categories[ci]];
        markDirty(); render();
    }
    window.cmMoveCat = cmMoveCat;

    // ── Item CRUD ──────────────────────────────────────────────────────────────
    function cmOpenItem(catIdx, itemIdx) {
        document.getElementById('cm-item-cat-idx').value = catIdx;
        document.getElementById('cm-item-idx').value = itemIdx;
        document.getElementById('cm-item-modal-title').textContent = itemIdx === -1 ? 'Add Item' : 'Edit Item';

        const item = itemIdx === -1
            ? { name:'', price:'', description:'', tag:'', unit:'', no_print:false, options:[] }
            : menu.categories[catIdx].items[itemIdx];

        document.getElementById('cm-item-name').value     = item.name || '';
        document.getElementById('cm-item-price').value    = item.price || '';
        document.getElementById('cm-item-desc').value     = item.description || '';
        document.getElementById('cm-item-tag').value      = item.tag || '';
        document.getElementById('cm-item-unit').value     = item.unit || '';
        document.getElementById('cm-item-no-print').checked = item.no_print || false;

        // Populate tag datalist
        const dl = document.getElementById('cm-tag-list');
        const cat = menu.categories[catIdx];
        dl.innerHTML = (cat.tags||[]).map(t => `<option value="${esc(t)}">`).join('');

        editingModifiers = JSON.parse(JSON.stringify(item.options || []));
        renderOptions();

        document.getElementById('cm-item-modal').style.display = 'flex';
        setTimeout(() => document.getElementById('cm-item-name').focus(), 50);
    }
    window.cmOpenItem = cmOpenItem;

    function renderOptions() {
        const list = document.getElementById('cm-modifiers-list');
        if (!editingModifiers.length) {
            list.innerHTML = '<p style="color:#888;font-size:13px;font-style:italic;">No options yet. Add modifiers to let customers customize this item.</p>';
            return;
        }
        list.innerHTML = editingModifiers.map((opt, i) => {
            const badge = `<span class="cm-mod-type-badge cm-opt-type-${opt.type}">${opt.type}</span>`;
            let detail = '';
            if (opt.type === 'select') detail = (opt.choices||[]).slice(0,3).join(', ') + ((opt.choices||[]).length > 3 ? ` +${opt.choices.length-3} more` : '');
            if (opt.type === 'toggle') detail = opt.price > 0 ? `+$${parseFloat(opt.price).toFixed(2)}` : 'Free';
            if (opt.type === 'number') detail = `Min: ${opt.min}, Default: ${opt.default}`;
            return `<div class="cm-mod-row">
                ${badge}
                <span style="flex:1;font-size:13px;"><strong>${esc(opt.label)}</strong> <span style="color:#888;font-size:12px;">${esc(detail)}</span>${opt.required?' <span style="color:#c8832a;font-size:11px;">required</span>':''}</span>
                <button onclick="cmEditModifier(${i})"   class="button" style="padding:3px 8px;min-height:0;font-size:12px;">✏️</button>
                <button onclick="cmMoveMod(${i},-1)"   class="button" style="padding:3px 6px;min-height:0;" ${i===0?'disabled':''}>↑</button>
                <button onclick="cmMoveMod(${i},1)"    class="button" style="padding:3px 6px;min-height:0;" ${i===editingModifiers.length-1?'disabled':''}>↓</button>
                <button onclick="cmDeleteMod(${i})"    class="button" style="padding:3px 8px;min-height:0;color:#cc3333;border-color:#cc3333;font-size:12px;">🗑️</button>
            </div>`;
        }).join('');
    }

    function cmSaveItem() {
        const catIdx  = parseInt(document.getElementById('cm-item-cat-idx').value);
        const itemIdx = parseInt(document.getElementById('cm-item-idx').value);
        const name    = document.getElementById('cm-item-name').value.trim();
        const price   = parseFloat(document.getElementById('cm-item-price').value) || 0;
        if (!name) { alert('Item name is required.'); return; }

        const item = {
            id:          itemIdx === -1 ? slug(name) : menu.categories[catIdx].items[itemIdx].id,
            name,
            price:       Math.round(price * 100) / 100,
            description: document.getElementById('cm-item-desc').value.trim(),
            tag:         document.getElementById('cm-item-tag').value.trim(),
            unit:        document.getElementById('cm-item-unit').value.trim(),
            no_print:    document.getElementById('cm-item-no-print').checked,
            options:     JSON.parse(JSON.stringify(editingModifiers)),
        };

        if (itemIdx === -1) {
            menu.categories[catIdx].items.push(item);
        } else {
            menu.categories[catIdx].items[itemIdx] = item;
        }

        markDirty(); cmCloseModal('cm-item-modal'); render();
    }
    window.cmSaveItem = cmSaveItem;

    function cmDeleteItem(ci, ii) {
        if (!confirm(`Delete "${menu.categories[ci].items[ii].name}"?`)) return;
        menu.categories[ci].items.splice(ii, 1);
        markDirty(); render();
    }
    window.cmDeleteItem = cmDeleteItem;

    function cmMoveItem(ci, ii, dir) {
        const ni = ii + dir;
        const items = menu.categories[ci].items;
        if (ni < 0 || ni >= items.length) return;
        [items[ii], items[ni]] = [items[ni], items[ii]];
        markDirty(); render();
    }
    window.cmMoveItem = cmMoveItem;

    // ── Modifier CRUD ────────────────────────────────────────────────────────────
    function cmModTypeChange(type) {
        document.getElementById('cm-mod-choices-wrap').style.display  = type === 'select' ? '' : 'none';
        document.getElementById('cm-mod-max-sel-wrap').style.display  = type === 'select' ? '' : 'none';
        document.getElementById('cm-mod-required-wrap').style.display = type !== 'number' ? '' : 'none';
        document.getElementById('cm-mod-price-wrap').style.display    = type === 'toggle' ? '' : 'none';
        document.getElementById('cm-mod-number-wrap').style.display   = type === 'number' ? '' : 'none';
    }
    window.cmModTypeChange = cmModTypeChange;

    function cmAddModifier() {
        document.getElementById('cm-mod-idx').value = -1;
        document.getElementById('cm-mod-modal-title').textContent = 'Add Option';
        document.getElementById('cm-mod-type').value    = 'select';
        document.getElementById('cm-mod-label').value   = '';
        document.getElementById('cm-mod-choices').value = '';
        document.getElementById('cm-mod-required').checked = true;
        document.getElementById('cm-mod-price').value   = 0;
        document.getElementById('cm-mod-min').value     = 1;
        document.getElementById('cm-mod-default').value = 1;
        document.getElementById('cm-mod-max-sel').value = 1;
        cmModTypeChange('select');
        document.getElementById('cm-mod-modal').style.display = 'flex';
        setTimeout(() => document.getElementById('cm-mod-label').focus(), 50);
    }
    window.cmAddModifier = cmAddModifier;

    function cmEditModifier(i) {
        const opt = editingModifiers[i];
        document.getElementById('cm-mod-idx').value = i;
        document.getElementById('cm-mod-modal-title').textContent = 'Edit Option';
        document.getElementById('cm-mod-type').value    = opt.type;
        document.getElementById('cm-mod-label').value   = opt.label || '';
        document.getElementById('cm-mod-choices').value = (opt.choices||[]).join('\n');
        document.getElementById('cm-mod-required').checked = opt.required || false;
        document.getElementById('cm-mod-price').value   = opt.price || 0;
        document.getElementById('cm-mod-min').value     = opt.min || 1;
        document.getElementById('cm-mod-default').value = opt.default || 1;
        document.getElementById('cm-mod-max-sel').value = opt.max_selections || 1;
        cmModTypeChange(opt.type);
        document.getElementById('cm-mod-modal').style.display = 'flex';
    }
    window.cmEditModifier = cmEditModifier;

    function cmSaveModifier() {
        const i     = parseInt(document.getElementById('cm-mod-idx').value);
        const type  = document.getElementById('cm-mod-type').value;
        const label = document.getElementById('cm-mod-label').value.trim();
        if (!label) { alert('Modifier label is required.'); return; }
        const opt = {
            key:            i === -1 ? slug(label) : editingModifiers[i].key,
            label,
            type,
            required:       document.getElementById('cm-mod-required').checked,
            choices:        type === 'select' ? document.getElementById('cm-mod-choices').value.split('\n').map(s=>s.trim()).filter(Boolean) : [],
            max_selections: type === 'select' ? (parseInt(document.getElementById('cm-mod-max-sel').value) || 1) : 1,
            price:          type === 'toggle' ? parseFloat(document.getElementById('cm-mod-price').value) || 0 : 0,
            min:            type === 'number' ? parseInt(document.getElementById('cm-mod-min').value) || 1 : 1,
            default:        type === 'number' ? parseInt(document.getElementById('cm-mod-default').value) || 1 : 1,
        };
        if (i === -1) editingModifiers.push(opt);
        else editingModifiers[i] = opt;
        cmCloseModal('cm-mod-modal');
        renderOptions();
    }
    window.cmSaveModifier = cmSaveModifier;

    function cmDeleteMod(i) {
        editingModifiers.splice(i, 1);
        renderOptions();
    }
    window.cmDeleteMod = cmDeleteMod;

    function cmMoveMod(i, dir) {
        const ni = i + dir;
        if (ni < 0 || ni >= editingModifiers.length) return;
        [editingModifiers[i], editingModifiers[ni]] = [editingModifiers[ni], editingModifiers[i]];
        renderOptions();
    }
    window.cmMoveMod = cmMoveMod;

    // ── Modal utils ────────────────────────────────────────────────────────────
    function cmCloseModal(id) {
        document.getElementById(id).style.display = 'none';
    }
    window.cmCloseModal = cmCloseModal;

    // ── Template picker ────────────────────────────────────────────────────────
    var _templatePickerChecked = {};

    function cmAddFromTemplate() {
        _templatePickerChecked = {};
        const listEl = document.getElementById('cm-template-list');
        listEl.innerHTML = '<p style="color:#888;font-size:13px;font-style:italic;">Loading templates…</p>';
        document.getElementById('cm-template-picker').style.display = 'flex';

        fetch('<?php echo rest_url("caterme/v1/modifier-templates"); ?>', {
            headers: { 'X-WP-Nonce': API_NONCE }
        })
        .then(r => r.json())
        .then(templates => {
            if (!templates || !templates.length) {
                listEl.innerHTML = '<p style="color:#888;font-size:13px;">No templates yet. <a href="<?php echo admin_url('admin.php?page=caterme-modifiers'); ?>" target="_blank">Create some here →</a></p>';
                return;
            }
            listEl.innerHTML = templates.map((t, i) => {
                const typeLabel = t.type === 'select' ? '🔘 Select' : t.type === 'toggle' ? '☑️ Toggle' : '🔢 Number';
                const preview   = t.type === 'select' ? (t.choices||[]).slice(0,3).join(', ') + ((t.choices||[]).length > 3 ? ` +${(t.choices||[]).length-3} more` : '') : (t.type === 'toggle' ? (t.price > 0 ? `+$${parseFloat(t.price).toFixed(2)}` : 'Free') : `Min: ${t.min||1}`);
                const disabled  = editingModifiers.some(m => m.key === t.key);
                return `<label class="cm-template-row${disabled?' cm-template-disabled':''}" for="tpl_${i}">
                    <input type="checkbox" id="tpl_${i}" ${disabled?'disabled':''} onchange="window._templatePickerChecked['${t.key}'] = this.checked" />
                    <div style="flex:1;min-width:0;">
                        <span style="font-weight:700;font-size:13px;">${esc(t.label)}</span>
                        <span style="margin-left:8px;font-size:11px;padding:1px 7px;border-radius:20px;background:#e0f2fe;color:#0369a1;">${typeLabel}</span>
                        ${disabled ? '<span style="margin-left:6px;font-size:11px;color:#c8832a;">already added</span>' : ''}
                        <div style="font-size:11px;color:#888;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(preview)}</div>
                    </div>
                </label>`;
            }).join('');
            // Store the templates list for use on apply
            listEl._templates = templates;
        })
        .catch(() => {
            listEl.innerHTML = '<p style="color:#c33;font-size:13px;">Failed to load templates.</p>';
        });
    }
    window.cmAddFromTemplate = cmAddFromTemplate;

    function cmApplyTemplates() {
        const listEl    = document.getElementById('cm-template-list');
        const templates = listEl._templates || [];
        templates.forEach(t => {
            if (_templatePickerChecked[t.key] && !editingModifiers.some(m => m.key === t.key)) {
                editingModifiers.push(JSON.parse(JSON.stringify(t)));
            }
        });
        renderOptions();
        cmCloseModal('cm-template-picker');
    }
    window.cmApplyTemplates = cmApplyTemplates;

    // Close on backdrop click
    document.querySelectorAll('.cm-modal-wrap').forEach(el => {
        el.addEventListener('click', function(e) {
            if (e.target === this) cmCloseModal(this.id);
        });
    });

    // ── Save ───────────────────────────────────────────────────────────────────
    function cmSave() {
        const btn    = document.getElementById('cm-save');
        const status = document.getElementById('cm-save-status');
        btn.disabled = true;
        btn.textContent = 'Saving...';
        status.textContent = '';

        fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': API_NONCE },
            body: JSON.stringify(menu),
        })
        .then(r => r.json())
        .then(json => {
            btn.disabled = false;
            btn.textContent = '💾 Save Menu';
            if (json.success) {
                dirty = false;
                status.textContent = '✓ Saved';
                status.style.color = '#00a32a';
                setTimeout(() => { if (!dirty) status.textContent = ''; }, 3000);
            } else {
                status.textContent = '⚠ ' + (json.message || 'Save failed.');
                status.style.color = '#d63638';
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.textContent = '💾 Save Menu';
            status.textContent = '⚠ Network error — try again.';
            status.style.color = '#d63638';
        });
    }

    function cmResetMenu() {
        fetch(API_URL + '?reset=1', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': API_NONCE },
            body: JSON.stringify({ reset: true }),
        }).then(() => location.reload());
    }
    window.cmResetMenu = cmResetMenu;

    // ── Wire up top buttons ────────────────────────────────────────────────────
    document.getElementById('cm-add-cat').addEventListener('click', () => cmOpenCategory(-1));
    document.getElementById('cm-save').addEventListener('click', cmSave);

    // Warn on leaving with unsaved changes
    window.addEventListener('beforeunload', e => {
        if (dirty) { e.preventDefault(); e.returnValue = ''; }
    });

    // ── Boot ───────────────────────────────────────────────────────────────────
    render();
})();
</script>
    <?php
}
