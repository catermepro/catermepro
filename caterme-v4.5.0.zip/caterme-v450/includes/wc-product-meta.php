<?php
/**
 * CaterMe — WooCommerce Product Integration
 *
 * Replaces the standalone Menu Manager. Adds a CaterMe meta box to every WC
 * product edit screen for catering-specific fields:
 *   Unit suffix   (_caterme_unit)       e.g. "/lb", "/person"
 *   Sub-filter tag(_caterme_tag)        for in-category tag pills
 *   No Label flag (_caterme_no_print)   skip Avery label when printing
 *   Modifiers     (_caterme_modifiers)  JSON array of {key,label,type,...}
 *
 * Category icon   (_caterme_icon)       emoji added to product_cat taxonomy terms
 *
 * Public function caterme_get_wc_menu() returns the same internal format as the
 * old caterme_get_menu() so no other code changes are needed downstream.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─────────────────────────────────────────────────────────────────────────────
// MENU BUILDER  —  replaces caterme_get_menu()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Build catering menu data from WooCommerce products.
 *
 * Returns the same structure as the old caterme_get_menu():
 *   [ 'categories' => [ ['name'=>..., 'icon'=>..., 'items'=>[...]], ... ] ]
 *
 * Items include all CaterMe-specific post-meta fields plus the standard WC
 * product fields (name, price, short description).
 */
function caterme_get_wc_menu() {
    if ( ! function_exists('wc_get_product') ) {
        return array( 'categories' => array() );
    }

    $terms = get_terms( array(
        'taxonomy'   => 'product_cat',
        'hide_empty' => true,
        'orderby'    => 'menu_order',
        'order'      => 'ASC',
    ) );

    if ( is_wp_error($terms) || empty($terms) ) {
        return array( 'categories' => array() );
    }

    $result = array( 'categories' => array() );

    foreach ( $terms as $term ) {
        $icon = get_term_meta( $term->term_id, '_caterme_icon', true ) ?: '🍽️';

        $posts = get_posts( array(
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order title',
            'order'          => 'ASC',
            'tax_query'      => array( array(
                'taxonomy' => 'product_cat',
                'field'    => 'term_id',
                'terms'    => $term->term_id,
            ) ),
        ) );

        if ( empty($posts) ) continue;

        $items = array();
        foreach ( $posts as $post ) {
            $product = wc_get_product( $post->ID );
            if ( ! $product || ! $product->is_purchasable() ) continue;

            $modifiers_raw = get_post_meta( $post->ID, '_caterme_modifiers', true );
            $modifiers     = array();
            if ( $modifiers_raw ) {
                $decoded = json_decode( $modifiers_raw, true );
                if ( is_array($decoded) ) $modifiers = $decoded;
            }

            // Short description first, fall back to excerpt of full description
            $desc = $product->get_short_description();
            if ( ! $desc ) $desc = $product->get_description();
            $desc = wp_strip_all_tags( $desc );
            if ( mb_strlen($desc) > 140 ) $desc = mb_substr($desc, 0, 140) . '…';

            $img_id  = $product->get_image_id();
            $img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'woocommerce_thumbnail' ) : '';

            $items[] = array(
                'id'          => $post->ID,
                'name'        => $product->get_name(),
                'price'       => (float) $product->get_price(),
                'description' => $desc,
                'tag'         => (string) ( get_post_meta( $post->ID, '_caterme_tag', true ) ?: '' ),
                'unit'        => (string) ( get_post_meta( $post->ID, '_caterme_unit', true ) ?: '' ),
                'no_print'    => (bool)     get_post_meta( $post->ID, '_caterme_no_print', true ),
                'options'     => $modifiers,
                'image'       => (string) ( $img_url ?: '' ),
            );
        }

        if ( empty($items) ) continue;

        $result['categories'][] = array(
            'name'  => $term->name,
            'icon'  => $icon,
            'items' => $items,
        );
    }

    return $result;
}


// ─────────────────────────────────────────────────────────────────────────────
// CATEGORY ICON  —  adds CaterMe icon field to WC product category screens
// ─────────────────────────────────────────────────────────────────────────────

// Add form (new category)
add_action( 'product_cat_add_form_fields', function() { ?>
    <div class="form-field">
        <label for="caterme_icon">CaterMe Icon</label>
        <input type="text" name="caterme_icon" id="caterme_icon" value="" maxlength="10" style="width:80px;" />
        <p class="description">Emoji icon shown in the catering order form (e.g. 🥪 🥗 🍕).</p>
    </div>
<?php } );

// Edit form (existing category)
add_action( 'product_cat_edit_form_fields', function( $term ) {
    $icon = get_term_meta( $term->term_id, '_caterme_icon', true ); ?>
    <tr class="form-field">
        <th scope="row"><label for="caterme_icon">CaterMe Icon</label></th>
        <td>
            <input type="text" name="caterme_icon" id="caterme_icon"
                   value="<?php echo esc_attr($icon); ?>" maxlength="10" style="width:80px;" />
            <p class="description">Emoji icon shown in the catering order form (e.g. 🥪 🥗 🍕).</p>
        </td>
    </tr>
<?php } );

// Save icon on create
add_action( 'created_product_cat', function( $term_id ) {
    if ( isset($_POST['caterme_icon']) ) {
        update_term_meta( $term_id, '_caterme_icon', sanitize_text_field($_POST['caterme_icon']) );
    }
} );

// Save icon on edit
add_action( 'edited_product_cat', function( $term_id ) {
    if ( isset($_POST['caterme_icon']) ) {
        update_term_meta( $term_id, '_caterme_icon', sanitize_text_field($_POST['caterme_icon']) );
    }
} );


// ─────────────────────────────────────────────────────────────────────────────
// PRODUCT META BOX  —  CaterMe fields on product edit screen
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'add_meta_boxes', function() {
    add_meta_box(
        'caterme-product-settings',
        '🥡 CaterMe Settings',
        'caterme_product_meta_box',
        'product',
        'normal',
        'default'
    );
} );

function caterme_product_meta_box( $post ) {
    wp_nonce_field( 'caterme_save_product_meta', 'caterme_product_nonce' );

    $unit      = get_post_meta( $post->ID, '_caterme_unit',      true );
    $tag       = get_post_meta( $post->ID, '_caterme_tag',       true );
    $no_print  = get_post_meta( $post->ID, '_caterme_no_print',  true );
    $modifiers = get_post_meta( $post->ID, '_caterme_modifiers', true ) ?: '[]';

    $templates_rest_url = esc_url( rest_url('caterme/v1/modifier-templates') );
    $templates_page_url = esc_url( admin_url('admin.php?page=caterme-modifiers') );
    ?>
    <style>
    #caterme-product-settings .inside { padding:14px 16px; }
    .cm-meta-grid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; margin-bottom:18px; }
    .cm-meta-field label { display:block; font-size:12px; font-weight:700; margin-bottom:4px; text-transform:uppercase; letter-spacing:.04em; color:#555; }
    .cm-meta-field input[type=text] { width:100%; border:1.5px solid #ddd; border-radius:6px; padding:6px 9px; font-size:13px; box-sizing:border-box; }
    .cm-meta-field input[type=text]:focus { border-color:#c8832a; outline:none; box-shadow:0 0 0 2px rgba(200,131,42,.15); }
    .cm-meta-no-print { display:flex; align-items:center; gap:8px; background:#f9f9f9; border:1px solid #e0e0e0; border-radius:7px; padding:8px 12px; }
    .cm-meta-no-print input { width:16px; height:16px; flex-shrink:0; }
    /* Modifier list */
    .cm-mods-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; border-top:1px solid #e0d0b8; padding-top:14px; }
    .cm-mods-header h4 { margin:0; font-size:13px; color:#1a1208; }
    .cm-mods-toolbar { display:flex; gap:6px; }
    #cm-product-mod-list .cm-mod-row { display:flex; align-items:center; gap:6px; background:#faf7f2; border:1px solid #e8dcc8; border-radius:6px; padding:7px 10px; margin-bottom:6px; }
    #cm-product-mod-list .cm-mod-row:last-child { margin-bottom:0; }
    .cm-mod-type-badge { font-size:10px; padding:2px 7px; border-radius:10px; font-weight:700; letter-spacing:.04em; text-transform:uppercase; flex-shrink:0; }
    .cm-opt-type-select { background:#e0f2fe; color:#0369a1; }
    .cm-opt-type-toggle { background:#dcfce7; color:#166534; }
    .cm-opt-type-number { background:#fef9c3; color:#854d0e; }
    #cm-product-mod-list .cm-empty-mods { color:#888; font-size:13px; font-style:italic; padding:8px 0; }
    /* Modal */
    .cm-pmod-wrap { display:none; position:fixed; inset:0; background:rgba(0,0,0,.55); z-index:999999; align-items:center; justify-content:center; }
    .cm-pmod-wrap.open { display:flex; }
    .cm-pmod-box { background:#fff; border-radius:10px; padding:24px 28px; width:500px; max-width:95vw; max-height:90vh; overflow-y:auto; box-shadow:0 20px 60px rgba(0,0,0,.3); }
    .cm-pmod-box h3 { margin:0 0 18px; font-size:16px; color:#1a1208; }
    .cm-pmod-field { margin-bottom:14px; }
    .cm-pmod-field label { display:block; font-size:12px; font-weight:700; margin-bottom:4px; color:#555; text-transform:uppercase; letter-spacing:.04em; }
    .cm-pmod-field input,.cm-pmod-field select,.cm-pmod-field textarea { width:100%; border:1.5px solid #ddd; border-radius:6px; padding:7px 10px; font-size:13px; box-sizing:border-box; }
    .cm-pmod-field input:focus,.cm-pmod-field select:focus,.cm-pmod-field textarea:focus { border-color:#c8832a; outline:none; }
    .cm-pmod-footer { display:flex; gap:8px; justify-content:flex-end; margin-top:18px; border-top:1px solid #eee; padding-top:14px; }
    /* Template picker */
    .cm-tpl-row { display:flex; align-items:center; gap:10px; border:1px solid #e0d0b8; border-radius:7px; padding:8px 12px; margin-bottom:6px; background:#faf7f2; cursor:pointer; }
    .cm-tpl-row:hover { background:#f5ede0; }
    .cm-tpl-row.disabled { opacity:.5; cursor:default; }
    .cm-tpl-row input[type=checkbox] { width:16px; height:16px; flex-shrink:0; }
    </style>

    <!-- Basic CaterMe fields -->
    <div class="cm-meta-grid">
        <div class="cm-meta-field">
            <label for="_caterme_unit">Unit Suffix</label>
            <input type="text" id="_caterme_unit" name="_caterme_unit"
                   value="<?php echo esc_attr($unit); ?>" placeholder="/lb, /person…" style="width:130px;" />
            <p style="font-size:11px;color:#888;margin:4px 0 0;">Shown after price, e.g. $12.00<em>/lb</em></p>
        </div>
        <div class="cm-meta-field">
            <label for="_caterme_tag">Sub-filter Tag</label>
            <input type="text" id="_caterme_tag" name="_caterme_tag"
                   value="<?php echo esc_attr($tag); ?>" placeholder="e.g. Wrap, Box…" />
            <p style="font-size:11px;color:#888;margin:4px 0 0;">Customers can filter items by tag within a category.</p>
        </div>
        <div class="cm-meta-field" style="display:flex;flex-direction:column;justify-content:center;">
            <div class="cm-meta-no-print">
                <input type="checkbox" id="_caterme_no_print" name="_caterme_no_print" value="1"
                       <?php checked($no_print, '1'); ?> />
                <label for="_caterme_no_print" style="font-size:13px;font-weight:600;cursor:pointer;margin:0;">
                    🚫 No Label<br>
                    <span style="font-weight:400;font-size:11px;color:#888;">Skip Avery label for this item (drinks, sides, etc.)</span>
                </label>
            </div>
        </div>
    </div>

    <!-- Modifiers -->
    <div class="cm-mods-header">
        <h4>Modifiers <span style="font-weight:400;color:#888;font-size:12px;">(proteins, add-ons, quantities…)</span></h4>
        <div class="cm-mods-toolbar">
            <a href="<?php echo $templates_page_url; ?>" target="_blank"
               class="button" style="font-size:12px;">⚙️ Manage Templates</a>
            <button type="button" class="button button-secondary"
                    onclick="cmPmodFromTemplate()" style="font-size:12px;">📋 From Template</button>
            <button type="button" class="button button-secondary"
                    onclick="cmPmodAdd()" style="font-size:12px;">+ Add Modifier</button>
        </div>
    </div>

    <!-- Hidden storage field -->
    <input type="hidden" id="_caterme_modifiers" name="_caterme_modifiers"
           value="<?php echo esc_attr($modifiers); ?>" />

    <!-- Modifier list -->
    <div id="cm-product-mod-list"></div>

    <!-- ── Modifier edit modal ── -->
    <div id="cm-pmod-modal" class="cm-pmod-wrap">
        <div class="cm-pmod-box">
            <h3 id="cm-pmod-title">Add Modifier</h3>
            <input type="hidden" id="cm-pmod-idx" value="-1" />
            <div class="cm-pmod-field">
                <label>Label *</label>
                <input type="text" id="cm-pmod-label" placeholder="e.g. Bread Choice" />
            </div>
            <div class="cm-pmod-field">
                <label>Type</label>
                <select id="cm-pmod-type" onchange="cmPmodTypeChange(this.value)">
                    <option value="select">Select — choice list</option>
                    <option value="toggle">Toggle — yes/no add-on</option>
                    <option value="number">Number — quantity / weight</option>
                </select>
            </div>
            <div class="cm-pmod-field">
                <label><input type="checkbox" id="cm-pmod-required" style="width:auto;margin-right:6px;" />Required</label>
            </div>
            <!-- Select fields -->
            <div id="cm-pmod-select-fields">
                <div class="cm-pmod-field">
                    <label>Choices <span style="font-weight:400;">(one per line)</span></label>
                    <textarea id="cm-pmod-choices" rows="5" placeholder="White&#10;Wheat&#10;Gluten-Free"></textarea>
                </div>
                <div class="cm-pmod-field">
                    <label>Max Selections <span style="font-weight:400;font-size:11px;">(0 or 1 = single, 2+ = multi-select)</span></label>
                    <input type="number" id="cm-pmod-max-sel" value="1" min="0" max="99" style="width:80px;" />
                </div>
            </div>
            <!-- Toggle fields -->
            <div id="cm-pmod-toggle-fields" style="display:none;">
                <div class="cm-pmod-field">
                    <label>Price Add-on ($)</label>
                    <input type="number" id="cm-pmod-price" value="0" min="0" step="0.01" style="width:100px;" />
                </div>
            </div>
            <!-- Number fields -->
            <div id="cm-pmod-number-fields" style="display:none;">
                <div class="cm-pmod-field">
                    <label>Minimum</label>
                    <input type="number" id="cm-pmod-min" value="1" min="0" style="width:80px;" />
                </div>
                <div class="cm-pmod-field">
                    <label>Default</label>
                    <input type="number" id="cm-pmod-default" value="1" min="0" style="width:80px;" />
                </div>
            </div>
            <div class="cm-pmod-footer">
                <button type="button" class="button button-primary" onclick="cmPmodSave()">Save Modifier</button>
                <button type="button" class="button" onclick="cmPmodClose('cm-pmod-modal')">Cancel</button>
            </div>
        </div>
    </div>

    <!-- ── Template picker modal ── -->
    <div id="cm-pmod-tpl-picker" class="cm-pmod-wrap">
        <div class="cm-pmod-box">
            <h3>Add from Template</h3>
            <div id="cm-pmod-tpl-list"><p style="color:#888;">Loading…</p></div>
            <div class="cm-pmod-footer">
                <button type="button" class="button button-primary" onclick="cmPmodApplyTemplates()">Add Selected</button>
                <button type="button" class="button" onclick="cmPmodClose('cm-pmod-tpl-picker')">Cancel</button>
            </div>
        </div>
    </div>

    <script>
    (function() {
        // ── State ────────────────────────────────────────────────────────────
        var TMPL_REST = <?php echo wp_json_encode($templates_rest_url); ?>;
        var NONCE     = <?php echo wp_json_encode(wp_create_nonce('wp_rest')); ?>;

        var mods = [];
        try { mods = JSON.parse(document.getElementById('_caterme_modifiers').value || '[]') || []; } catch(e) {}

        var _tplChecked = {};

        // ── Render ───────────────────────────────────────────────────────────
        function esc(s) {
            return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        }

        function render() {
            var list = document.getElementById('cm-product-mod-list');
            if (!mods.length) {
                list.innerHTML = '<p class="cm-empty-mods">No modifiers yet. Add options to let customers customise this item.</p>';
                save();
                return;
            }
            list.innerHTML = mods.map(function(m, i) {
                var badge = '<span class="cm-mod-type-badge cm-opt-type-' + esc(m.type) + '">' + esc(m.type) + '</span>';
                var detail = '';
                if (m.type === 'select') detail = (m.choices||[]).slice(0,3).join(', ') + ((m.choices||[]).length > 3 ? ' +' + ((m.choices||[]).length - 3) + ' more' : '');
                if (m.type === 'toggle') detail = m.price > 0 ? '+$' + parseFloat(m.price).toFixed(2) : 'Free';
                if (m.type === 'number') detail = 'Min: ' + m.min + ', Default: ' + m.default;
                return '<div class="cm-mod-row">' +
                    badge +
                    '<span style="flex:1;font-size:13px;"><strong>' + esc(m.label) + '</strong>' +
                    (detail ? ' <span style="color:#888;font-size:12px;">' + esc(detail) + '</span>' : '') +
                    (m.required ? ' <span style="color:#c8832a;font-size:11px;">required</span>' : '') + '</span>' +
                    '<button type="button" onclick="cmPmodEdit(' + i + ')" class="button" style="padding:3px 8px;min-height:0;font-size:12px;">✏️</button>' +
                    '<button type="button" onclick="cmPmodMove(' + i + ',-1)" class="button" style="padding:3px 6px;min-height:0;" ' + (i===0?'disabled':'') + '>↑</button>' +
                    '<button type="button" onclick="cmPmodMove(' + i + ',1)" class="button" style="padding:3px 6px;min-height:0;" ' + (i===mods.length-1?'disabled':'') + '>↓</button>' +
                    '<button type="button" onclick="cmPmodDelete(' + i + ')" class="button" style="padding:3px 8px;min-height:0;color:#cc3333;border-color:#cc3333;font-size:12px;">🗑️</button>' +
                    '</div>';
            }).join('');
            save();
        }

        function save() {
            document.getElementById('_caterme_modifiers').value = JSON.stringify(mods);
        }

        function slug(s) {
            return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'') || ('mod-' + Date.now());
        }

        // ── Type change ──────────────────────────────────────────────────────
        window.cmPmodTypeChange = function(t) {
            document.getElementById('cm-pmod-select-fields').style.display  = t === 'select'  ? '' : 'none';
            document.getElementById('cm-pmod-toggle-fields').style.display  = t === 'toggle'  ? '' : 'none';
            document.getElementById('cm-pmod-number-fields').style.display  = t === 'number'  ? '' : 'none';
        };

        // ── Open/close modal ─────────────────────────────────────────────────
        window.cmPmodClose = function(id) {
            document.getElementById(id).classList.remove('open');
        };

        function openModal(id) {
            document.getElementById(id).classList.add('open');
        }

        // ── Add / Edit ───────────────────────────────────────────────────────
        window.cmPmodAdd = function() {
            document.getElementById('cm-pmod-title').textContent = 'Add Modifier';
            document.getElementById('cm-pmod-idx').value     = -1;
            document.getElementById('cm-pmod-label').value   = '';
            document.getElementById('cm-pmod-type').value    = 'select';
            document.getElementById('cm-pmod-required').checked = false;
            document.getElementById('cm-pmod-choices').value = '';
            document.getElementById('cm-pmod-max-sel').value = 1;
            document.getElementById('cm-pmod-price').value   = 0;
            document.getElementById('cm-pmod-min').value     = 1;
            document.getElementById('cm-pmod-default').value = 1;
            cmPmodTypeChange('select');
            openModal('cm-pmod-modal');
            setTimeout(function(){ document.getElementById('cm-pmod-label').focus(); }, 50);
        };

        window.cmPmodEdit = function(i) {
            var m = mods[i];
            document.getElementById('cm-pmod-title').textContent = 'Edit Modifier';
            document.getElementById('cm-pmod-idx').value     = i;
            document.getElementById('cm-pmod-label').value   = m.label || '';
            document.getElementById('cm-pmod-type').value    = m.type  || 'select';
            document.getElementById('cm-pmod-required').checked = m.required || false;
            document.getElementById('cm-pmod-choices').value = (m.choices||[]).join('\n');
            document.getElementById('cm-pmod-max-sel').value = m.max_selections || 1;
            document.getElementById('cm-pmod-price').value   = m.price   || 0;
            document.getElementById('cm-pmod-min').value     = m.min     || 1;
            document.getElementById('cm-pmod-default').value = m.default || 1;
            cmPmodTypeChange(m.type || 'select');
            openModal('cm-pmod-modal');
        };

        window.cmPmodSave = function() {
            var i      = parseInt(document.getElementById('cm-pmod-idx').value);
            var label  = document.getElementById('cm-pmod-label').value.trim();
            var type   = document.getElementById('cm-pmod-type').value;
            if (!label) { alert('Modifier label is required.'); return; }

            var mod = {
                key:            i === -1 ? slug(label) : mods[i].key,
                label:          label,
                type:           type,
                required:       document.getElementById('cm-pmod-required').checked,
                choices:        type === 'select' ? document.getElementById('cm-pmod-choices').value.split('\n').map(function(s){ return s.trim(); }).filter(Boolean) : [],
                max_selections: type === 'select' ? (parseInt(document.getElementById('cm-pmod-max-sel').value) || 1) : 1,
                price:          type === 'toggle' ? (parseFloat(document.getElementById('cm-pmod-price').value) || 0) : 0,
                min:            type === 'number' ? (parseInt(document.getElementById('cm-pmod-min').value) || 1) : 1,
                'default':      type === 'number' ? (parseInt(document.getElementById('cm-pmod-default').value) || 1) : 1,
            };

            if (i === -1) mods.push(mod);
            else mods[i] = mod;

            cmPmodClose('cm-pmod-modal');
            render();
        };

        window.cmPmodDelete = function(i) {
            mods.splice(i, 1);
            render();
        };

        window.cmPmodMove = function(i, dir) {
            var ni = i + dir;
            if (ni < 0 || ni >= mods.length) return;
            var tmp = mods[i]; mods[i] = mods[ni]; mods[ni] = tmp;
            render();
        };

        // ── Template picker ──────────────────────────────────────────────────
        window.cmPmodFromTemplate = function() {
            _tplChecked = {};
            var listEl = document.getElementById('cm-pmod-tpl-list');
            listEl.innerHTML = '<p style="color:#888;">Loading…</p>';
            openModal('cm-pmod-tpl-picker');

            fetch(TMPL_REST, { headers: { 'X-WP-Nonce': NONCE } })
                .then(function(r){ return r.json(); })
                .then(function(templates) {
                    if (!templates.length) {
                        listEl.innerHTML = '<p style="color:#888;">No templates yet. <a href="<?php echo $templates_page_url; ?>" target="_blank">Create templates →</a></p>';
                        return;
                    }
                    listEl._templates = templates;
                    listEl.innerHTML = templates.map(function(t, i) {
                        var already = mods.some(function(m){ return m.key === t.key; });
                        var preview = '';
                        if (t.type === 'select') preview = (t.choices||[]).slice(0,4).join(', ') + ((t.choices||[]).length > 4 ? '…' : '');
                        if (t.type === 'toggle') preview = t.price > 0 ? '+$' + parseFloat(t.price).toFixed(2) : 'Free add-on';
                        if (t.type === 'number') preview = 'Min ' + t.min;
                        var badge = '<span class="cm-mod-type-badge cm-opt-type-' + esc(t.type) + '">' + esc(t.type) + '</span>';
                        return '<label class="cm-tpl-row' + (already ? ' disabled' : '') + '">' +
                            '<input type="checkbox" ' + (already ? 'disabled title="Already added"' : '') +
                            ' onchange="_tplChecked[\'' + esc(t.key) + '\'] = this.checked" /> ' +
                            badge + ' <span><strong>' + esc(t.label) + '</strong>' +
                            (preview ? ' <span style="color:#888;font-size:12px;">' + esc(preview) + '</span>' : '') +
                            (already ? ' <em style="font-size:11px;color:#888;"> — already added</em>' : '') + '</span>' +
                            '</label>';
                    }).join('');
                })
                .catch(function(){ listEl.innerHTML = '<p style="color:#c33;">Failed to load templates.</p>'; });
        };

        window.cmPmodApplyTemplates = function() {
            var listEl    = document.getElementById('cm-pmod-tpl-list');
            var templates = listEl._templates || [];
            templates.forEach(function(t) {
                if (_tplChecked[t.key] && !mods.some(function(m){ return m.key === t.key; })) {
                    mods.push(JSON.parse(JSON.stringify(t)));
                }
            });
            cmPmodClose('cm-pmod-tpl-picker');
            render();
        };

        // ── Close on backdrop click ───────────────────────────────────────────
        ['cm-pmod-modal', 'cm-pmod-tpl-picker'].forEach(function(id) {
            document.getElementById(id).addEventListener('click', function(e) {
                if (e.target === this) cmPmodClose(id);
            });
        });

        // ── Boot ─────────────────────────────────────────────────────────────
        render();
    })();
    </script>
    <?php
}


// ─── Save product meta ────────────────────────────────────────────────────────

add_action( 'save_post_product', function( $post_id ) {
    if ( ! isset($_POST['caterme_product_nonce']) ) return;
    if ( ! wp_verify_nonce($_POST['caterme_product_nonce'], 'caterme_save_product_meta') ) return;
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( ! current_user_can('edit_post', $post_id) ) return;

    // Unit
    update_post_meta( $post_id, '_caterme_unit',
        sanitize_text_field( $_POST['_caterme_unit'] ?? '' ) );

    // Tag
    update_post_meta( $post_id, '_caterme_tag',
        sanitize_text_field( $_POST['_caterme_tag'] ?? '' ) );

    // No print
    update_post_meta( $post_id, '_caterme_no_print',
        isset($_POST['_caterme_no_print']) ? '1' : '' );

    // Modifiers — validate JSON, sanitize individual strings
    $raw = wp_unslash( $_POST['_caterme_modifiers'] ?? '[]' );
    $decoded = json_decode( $raw, true );
    if ( is_array($decoded) ) {
        $clean = array();
        foreach ( $decoded as $mod ) {
            if ( ! isset($mod['key'], $mod['label'], $mod['type']) ) continue;
            $choices = array();
            foreach ( (array)($mod['choices'] ?? array()) as $c ) {
                $c = sanitize_text_field($c);
                if ($c !== '') $choices[] = $c;
            }
            $clean[] = array(
                'key'            => sanitize_key( $mod['key'] ),
                'label'          => sanitize_text_field( $mod['label'] ),
                'type'           => in_array($mod['type'], array('select','toggle','number')) ? $mod['type'] : 'select',
                'required'       => (bool)($mod['required'] ?? false),
                'choices'        => $choices,
                'max_selections' => absint( $mod['max_selections'] ?? 1 ),
                'price'          => round( floatval($mod['price'] ?? 0), 2 ),
                'min'            => absint( $mod['min'] ?? 1 ),
                'default'        => absint( $mod['default'] ?? 1 ),
            );
        }
        update_post_meta( $post_id, '_caterme_modifiers', wp_json_encode($clean) );
    }
} );
