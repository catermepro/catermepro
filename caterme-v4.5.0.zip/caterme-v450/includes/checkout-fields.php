<?php
/**
 * CaterMe — WooCommerce Checkout Integration
 *
 * 1. Injects fulfillment fields (pickup/delivery, date, time, address, tip,
 *    notes) into the WC checkout page via a dedicated section.
 * 2. Validates blackout rules on checkout submission.
 * 3. Creates a caterme_orders + caterme_order_items record when WC order is placed.
 * 4. Shows per-item modifier summaries in WC checkout order review table.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Enqueue checkout JS + pass availability data ──────────────────────────────
add_action( 'wp_enqueue_scripts', function() {
    if ( ! is_checkout() ) return;

    $ver = CATERME_VERSION;
    $dir = plugin_dir_url( dirname(__FILE__) );
    $settings = caterme_get_settings();

    wp_enqueue_script( 'caterme-checkout',
        $dir . 'js/checkout.js?v=' . $ver,
        array(), null, true );

    $pub = array(
        'availability_url' => esc_url( rest_url('caterme/v1/availability') ),
        'delivery_fee_url' => esc_url( rest_url('caterme/v1/delivery-fee') ),
        'lead_time_hours'  => (int)($settings['lead_time_hours'] ?? 0),
        'tip_enabled'      => ($settings['tip_enabled'] ?? '1') === '1',
        'tip_presets'      => $settings['tip_presets'] ?? '15,20,25',
        'store_address'    => $settings['store_address'] ?? '',
        'nonce'            => wp_create_nonce('wp_rest'),
    );
    wp_add_inline_script( 'caterme-checkout',
        'var CATERME_CHECKOUT=' . wp_json_encode($pub) . ';', 'before' );

    wp_enqueue_style( 'caterme-shop',
        $dir . 'css/shop.css?v=' . $ver );
} );

// ── Add CaterMe fulfillment section to checkout ───────────────────────────────
add_action( 'woocommerce_checkout_before_order_review_heading', function() {
    ?>
    <div id="caterme-checkout-fields" class="caterme-checkout-section">
        <h3>📅 Fulfillment Details</h3>

        <div class="caterme-fulfillment-toggle">
            <label class="caterme-toggle-btn" id="cm-pickup-btn">
                <input type="radio" name="caterme_fulfillment" value="pickup" checked> 🏪 Pick Up
            </label>
            <label class="caterme-toggle-btn" id="cm-delivery-btn">
                <input type="radio" name="caterme_fulfillment" value="delivery"> 🚗 Delivery
            </label>
        </div>

        <div class="caterme-fields-grid">
            <div class="caterme-field-group">
                <label id="cm-date-label">Pick Up Date *</label>
                <input type="date" id="caterme_order_date" name="caterme_order_date" required />
                <span id="caterme-date-error" class="caterme-field-error"></span>
            </div>
            <div class="caterme-field-group">
                <label id="cm-time-label">Pick Up Time *</label>
                <input type="time" id="caterme_order_time" name="caterme_order_time" required />
                <span id="caterme-time-error" class="caterme-field-error"></span>
            </div>
        </div>

        <div id="caterme-delivery-address-wrap" class="caterme-field-group" style="display:none;">
            <label>Delivery Address *</label>
            <input type="text" id="caterme_delivery_address" name="caterme_delivery_address"
                   placeholder="Street address, City, State, ZIP" />
            <span id="caterme-addr-status" class="caterme-field-hint"></span>
        </div>

        <div class="caterme-field-group">
            <label>Special Notes / Instructions</label>
            <textarea id="caterme_notes" name="caterme_notes" rows="3"
                      placeholder="Any special requests, allergies, or instructions..."></textarea>
        </div>

        <!-- Tip -->
        <div id="caterme-tip-section">
            <label>💰 Add a Tip</label>
            <div id="caterme-tip-presets" class="caterme-tip-row"></div>
            <div id="caterme-custom-tip-wrap" style="display:none;">
                <span class="caterme-dollar">$</span>
                <input type="number" id="caterme-custom-tip-input" min="0" step="0.50" placeholder="0.00" />
            </div>
            <input type="hidden" id="caterme_tip" name="caterme_tip" value="0" />
        </div>

        <!-- Hidden fields for POST -->
        <input type="hidden" id="caterme_fulfillment_hidden" name="caterme_fulfillment_val" value="pickup" />
        <input type="hidden" id="caterme_delivery_fee_hidden" name="caterme_delivery_fee" value="0" />
    </div>
    <?php
} );

// ── Show modifier selections in checkout order review table ───────────────────
add_filter( 'woocommerce_get_item_data', function( $item_data, $cart_item ) {
    if ( ! empty( $cart_item['caterme_selections'] ) ) {
        $sels = $cart_item['caterme_selections'];
        if ( is_array($sels) && count($sels) ) {
            $item_data[] = array(
                'name'  => 'Selections',
                'value' => implode( ' · ', array_map('sanitize_text_field', $sels) ),
            );
        }
    }
    if ( ! empty( $cart_item['caterme_dietary'] ) ) {
        $item_data[] = array(
            'name'  => 'Dietary',
            'value' => sanitize_text_field( $cart_item['caterme_dietary'] ),
        );
    }
    if ( ! empty( $cart_item['caterme_label_name'] ) ) {
        $item_data[] = array(
            'name'  => '🏷️ Label Name',
            'value' => sanitize_text_field( $cart_item['caterme_label_name'] ),
        );
    }
    return $item_data;
}, 10, 2 );

// ── Validate fulfillment fields on checkout ───────────────────────────────────
add_action( 'woocommerce_checkout_process', function() {
    $fulfillment = sanitize_text_field( $_POST['caterme_fulfillment_val'] ?? 'pickup' );
    $order_date  = sanitize_text_field( $_POST['caterme_order_date']      ?? '' );
    $order_time  = sanitize_text_field( $_POST['caterme_order_time']      ?? '' );

    if ( ! $order_date ) {
        wc_add_notice( __('Please select a ' . ($fulfillment === 'delivery' ? 'delivery' : 'pick up') . ' date.'), 'error' );
    }
    if ( ! $order_time ) {
        wc_add_notice( __('Please select a ' . ($fulfillment === 'delivery' ? 'delivery' : 'pick up') . ' time.'), 'error' );
    }
    if ( $fulfillment === 'delivery' && empty(trim($_POST['caterme_delivery_address'] ?? '')) ) {
        wc_add_notice( __('Please enter a delivery address.'), 'error' );
    }

    // Lead time server-side check
    $settings   = caterme_get_settings();
    $lead_hours = absint( $settings['lead_time_hours'] ?? 0 );
    if ( $lead_hours > 0 && $order_date && $order_time ) {
        $order_dt    = strtotime( $order_date . ' ' . $order_time );
        $min_allowed = time() + ( $lead_hours * 3600 );
        if ( $order_dt && $order_dt < $min_allowed ) {
            wc_add_notice( sprintf(
                'Orders require at least %d hour%s advance notice. Please choose a later date/time.',
                $lead_hours, $lead_hours === 1 ? '' : 's'
            ), 'error' );
        }
    }

    // Blackout date check
    $avail = caterme_get_availability( $fulfillment );
    if ( $order_date ) {
        $dow = (int) date('w', strtotime($order_date)); // 0=Sun
        if ( in_array($dow, $avail['closed_days'] ?? array()) ) {
            wc_add_notice( 'We do not accept ' . ($fulfillment === 'delivery' ? 'delivery' : 'pick up') . ' orders on that day of the week. Please choose a different date.', 'error' );
        }
        if ( in_array($order_date, $avail['blocked_dates'] ?? array()) ) {
            wc_add_notice( 'That date is not available for ' . ($fulfillment === 'delivery' ? 'delivery' : 'pickup') . '. Please choose a different date.', 'error' );
        }
    }
    if ( $order_time && ( $avail['open_time'] || $avail['close_time'] ) ) {
        if ( $avail['open_time']  && $order_time < $avail['open_time'] ) {
            wc_add_notice( 'Please choose a time after ' . caterme_format_time($avail['open_time']) . '.', 'error' );
        }
        if ( $avail['close_time'] && $order_time > $avail['close_time'] ) {
            wc_add_notice( 'Please choose a time before ' . caterme_format_time($avail['close_time']) . '.', 'error' );
        }
    }
} );

function caterme_format_time( $t ) {
    if ( ! $t ) return $t;
    $parts = explode(':', $t);
    $h = (int)$parts[0]; $m = $parts[1] ?? '00';
    $ampm = $h >= 12 ? 'PM' : 'AM';
    $h12  = $h > 12 ? $h - 12 : ( $h === 0 ? 12 : $h );
    return $h12 . ':' . $m . ' ' . $ampm;
}

// ── Save fulfillment fields to WC order meta ──────────────────────────────────
add_action( 'woocommerce_checkout_update_order_meta', function( $wc_order_id ) {
    $fields = array(
        '_caterme_fulfillment'      => sanitize_text_field( $_POST['caterme_fulfillment_val']   ?? 'pickup' ),
        '_caterme_order_date'       => sanitize_text_field( $_POST['caterme_order_date']         ?? '' ),
        '_caterme_order_time'       => sanitize_text_field( $_POST['caterme_order_time']         ?? '' ),
        '_caterme_delivery_address' => sanitize_textarea_field( $_POST['caterme_delivery_address'] ?? '' ),
        '_caterme_delivery_fee'     => floatval( $_POST['caterme_delivery_fee']                  ?? 0 ),
        '_caterme_tip'              => floatval( $_POST['caterme_tip']                           ?? 0 ),
        '_caterme_notes'            => sanitize_textarea_field( $_POST['caterme_notes']          ?? '' ),
    );
    foreach ( $fields as $key => $val ) {
        update_post_meta( $wc_order_id, $key, $val );
    }
} );

// ── Create caterme_orders record when WC order is placed ─────────────────────
add_action( 'woocommerce_checkout_order_created', function( $wc_order ) {
    global $wpdb;

    $wc_order_id  = $wc_order->get_id();
    $orders_table = $wpdb->prefix . 'caterme_orders';
    $items_table  = $wpdb->prefix . 'caterme_order_items';

    // Read fulfillment data from order meta (just saved above)
    $fulfillment      = get_post_meta( $wc_order_id, '_caterme_fulfillment',      true ) ?: 'pickup';
    $order_date_raw   = get_post_meta( $wc_order_id, '_caterme_order_date',       true ) ?: '';
    $order_time_raw   = get_post_meta( $wc_order_id, '_caterme_order_time',       true ) ?: '';
    $delivery_address = get_post_meta( $wc_order_id, '_caterme_delivery_address', true ) ?: '';
    $delivery_fee     = floatval( get_post_meta( $wc_order_id, '_caterme_delivery_fee', true ) ?: 0 );
    $tip              = floatval( get_post_meta( $wc_order_id, '_caterme_tip',    true ) ?: 0 );
    $notes            = get_post_meta( $wc_order_id, '_caterme_notes',            true ) ?: '';

    $order_date_val = $order_date_raw ? date('Y-m-d', strtotime($order_date_raw)) : null;
    $order_time_val = $order_time_raw ? $order_time_raw . ':00' : null;

    $order_number = caterme_generate_order_number();

    // Build subtotal from WC cart items
    $subtotal = 0.0;
    $wc_items_raw = array();
    foreach ( $wc_order->get_items() as $item_id => $wc_item ) {
        $line_total = floatval( $wc_item->get_total() );
        $subtotal  += $line_total;
        $wc_items_raw[] = array(
            'wc_item'    => $wc_item,
            'line_total' => $line_total,
        );
    }

    $tax = round( floatval( $wc_order->get_total_tax() ), 2 );

    // Build billing info
    $first = $wc_order->get_billing_first_name();
    $last  = $wc_order->get_billing_last_name();
    $customer_name  = trim("$first $last");
    $customer_email = $wc_order->get_billing_email();
    $customer_phone = $wc_order->get_billing_phone();

    // Insert caterme order
    $wpdb->insert( $orders_table, array(
        'wc_order_id'      => $wc_order_id,
        'payment_status'   => 'pending',
        'order_number'     => $order_number,
        'status'           => 'new',
        'fulfillment'      => $fulfillment,
        'order_date'       => $order_date_val,
        'order_time'       => $order_time_val,
        'subtotal'         => round($subtotal, 2),
        'delivery_fee'     => $delivery_fee,
        'tax'              => $tax,
        'tip'              => $tip,
        'customer_name'    => $customer_name,
        'customer_phone'   => $customer_phone,
        'customer_email'   => $customer_email,
        'delivery_address' => $delivery_address,
        'notes'            => $notes,
        'created_at'       => current_time('mysql'),
    ) );

    $catering_order_id = $wpdb->insert_id;
    if ( ! $catering_order_id ) return;

    // Save reverse link on WC order
    update_post_meta( $wc_order_id, '_caterme_order_id', $catering_order_id );
    $wc_order->update_meta_data( '_caterme_order_id', $catering_order_id );
    $wc_order->update_meta_data( '_caterme_order_number', $order_number );
    $wc_order->save();

    // Insert caterme order items (from WC cart items, with modifier meta)
    foreach ( $wc_items_raw as $row ) {
        $wc_item   = $row['wc_item'];
        $product   = $wc_item->get_product();
        $item_name = $wc_item->get_name();
        $qty       = $wc_item->get_quantity();
        $unit_price = $qty > 0 ? round( $row['line_total'] / $qty, 2 ) : 0;

        // Retrieve catering meta stored on cart item → saved to order item meta by WC
        $cart_item_key = $wc_item->get_meta('_caterme_cart_key');
        $sels_raw  = $wc_item->get_meta('_caterme_selections');
        $dietary   = $wc_item->get_meta('_caterme_dietary')    ?: '';
        $label     = $wc_item->get_meta('_caterme_label_name') ?: '';

        $sels = array();
        if ( $sels_raw ) {
            $decoded = json_decode($sels_raw, true);
            if ( is_array($decoded) ) $sels = $decoded;
        }

        $wpdb->insert( $items_table, array(
            'order_id'   => $catering_order_id,
            'item_name'  => $item_name,
            'qty'        => $qty,
            'unit_price' => $unit_price,
            'line_total' => round($row['line_total'], 2),
            'selections' => wp_json_encode($sels),
            'dietary'    => sanitize_text_field($dietary),
            'label_name' => sanitize_text_field($label),
        ) );
    }

    // Fire new-order notification
    caterme_notify_new_order( $catering_order_id );

    // Google Sheets webhook
    $settings = caterme_get_settings();
    $webhook  = $settings['sheets_webhook'] ?? '';
    if ( $webhook ) {
        $payload = array(
            'order_number'   => $order_number,
            'timestamp'      => current_time('c'),
            'fulfillment'    => $fulfillment,
            'orderDate'      => $order_date_raw,
            'orderTime'      => $order_time_raw,
            'subtotal'       => $subtotal,
            'delivery_fee'   => $delivery_fee,
            'tax'            => $tax,
            'tip'            => $tip,
            'customer_name'  => $customer_name,
            'customer_phone' => $customer_phone,
            'customer_email' => $customer_email,
            'notes'          => $notes,
        );
        wp_remote_post( $webhook, array(
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($payload),
            'timeout' => 15,
        ));
    }
} );

// ── Persist cart item meta through WC session → order item ───────────────────
// WC only saves meta added via woocommerce_checkout_create_order_line_item.
add_action( 'woocommerce_checkout_create_order_line_item',
    function( $item, $cart_item_key, $cart_item, $order ) {
        foreach ( array('_caterme_selections','_caterme_dietary','_caterme_label_name','_caterme_cart_key','_caterme_no_print') as $meta_key ) {
            if ( isset($cart_item[$meta_key]) ) {
                $item->add_meta_data( $meta_key, $cart_item[$meta_key], true );
            }
        }
    }, 10, 4
);

// ── REST: add item to WC cart with CaterMe meta ───────────────────────────────
// shop.js calls this to add products with modifier data to the WC cart.
add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/cart/add', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $req ) {
            if ( ! function_exists('WC') || ! WC()->cart ) {
                // Init WC session + cart for REST context
                if ( ! WC()->session ) {
                    WC()->initialize_session();
                }
                WC()->initialize_cart();
            }

            $body       = $req->get_json_params() ?: array();
            $product_id = absint( $body['product_id'] ?? 0 );
            $qty        = max(1, absint( $body['qty'] ?? 1 ));

            if ( ! $product_id ) {
                return new WP_REST_Response( array('success'=>false,'message'=>'No product_id.'), 400 );
            }

            $product = wc_get_product($product_id);
            if ( ! $product || ! $product->is_purchasable() ) {
                return new WP_REST_Response( array('success'=>false,'message'=>'Product not available.'), 400 );
            }

            $cart_item_data = array(
                '_caterme_selections' => wp_json_encode( $body['selections'] ?? array() ),
                '_caterme_dietary'    => sanitize_text_field( implode(', ', (array)($body['dietary'] ?? array())) ),
                '_caterme_label_name' => sanitize_text_field( $body['label_name'] ?? '' ),
                '_caterme_no_print'   => (bool) get_post_meta($product_id, '_caterme_no_print', true),
                '_caterme_cart_key'   => wp_generate_uuid4(),
            );

            // Override price if modifiers change it
            $custom_price = floatval( $body['price'] ?? 0 );
            if ( $custom_price > 0 && $custom_price != floatval($product->get_price()) ) {
                $cart_item_data['_caterme_custom_price'] = $custom_price;
                add_filter( 'woocommerce_add_cart_item', function($cart_item) use ($custom_price) {
                    if ( isset($cart_item['_caterme_custom_price']) ) {
                        $cart_item['data']->set_price( $cart_item['_caterme_custom_price'] );
                    }
                    return $cart_item;
                }, 10 );
                add_filter( 'woocommerce_get_cart_item_from_session', function($cart_item) {
                    if ( isset($cart_item['_caterme_custom_price']) ) {
                        $cart_item['data']->set_price( $cart_item['_caterme_custom_price'] );
                    }
                    return $cart_item;
                }, 10 );
            }

            $cart_key = WC()->cart->add_to_cart( $product_id, $qty, 0, array(), $cart_item_data );

            if ( ! $cart_key ) {
                return new WP_REST_Response( array('success'=>false,'message'=>'Could not add to cart.'), 500 );
            }

            WC()->cart->calculate_totals();

            return new WP_REST_Response( array(
                'success'    => true,
                'cart_key'   => $cart_key,
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_total(),
            ), 200 );
        },
    ));

    // GET cart contents for React
    register_rest_route( 'caterme/v1', '/cart', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function() {
            if ( ! function_exists('WC') ) {
                return new WP_REST_Response( array('items'=>array(),'count'=>0,'subtotal'=>0), 200 );
            }
            if ( ! WC()->session ) WC()->initialize_session();
            if ( ! WC()->cart )    WC()->initialize_cart();

            $items = array();
            foreach ( WC()->cart->get_cart() as $key => $cart_item ) {
                $product  = $cart_item['data'];
                $sels_raw = $cart_item['_caterme_selections'] ?? '[]';
                $sels     = json_decode($sels_raw, true) ?: array();
                $items[] = array(
                    'cart_key'   => $key,
                    'product_id' => $cart_item['product_id'],
                    'name'       => $product->get_name(),
                    'qty'        => $cart_item['quantity'],
                    'price'      => floatval( $product->get_price() ),
                    'line_total' => floatval( $cart_item['line_total'] ?? ($cart_item['quantity'] * $product->get_price()) ),
                    'selections' => $sels,
                    'dietary'    => $cart_item['_caterme_dietary']    ?? '',
                    'label_name' => $cart_item['_caterme_label_name'] ?? '',
                    'no_print'   => $cart_item['_caterme_no_print']   ?? false,
                );
            }

            return new WP_REST_Response( array(
                'items'    => $items,
                'count'    => WC()->cart->get_cart_contents_count(),
                'subtotal' => floatval( WC()->cart->get_subtotal() ),
            ), 200 );
        },
    ));

    // DELETE cart item
    register_rest_route( 'caterme/v1', '/cart/remove', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $req ) {
            if ( ! function_exists('WC') ) return new WP_REST_Response( array('success'=>false), 400 );
            if ( ! WC()->session ) WC()->initialize_session();
            if ( ! WC()->cart )    WC()->initialize_cart();

            $body     = $req->get_json_params() ?: array();
            $cart_key = sanitize_text_field( $body['cart_key'] ?? '' );
            $removed  = WC()->cart->remove_cart_item($cart_key);
            WC()->cart->calculate_totals();
            return new WP_REST_Response( array(
                'success'  => $removed,
                'count'    => WC()->cart->get_cart_contents_count(),
                'subtotal' => floatval( WC()->cart->get_subtotal() ),
            ), 200 );
        },
    ));

    // UPDATE cart item qty
    register_rest_route( 'caterme/v1', '/cart/update', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $req ) {
            if ( ! function_exists('WC') ) return new WP_REST_Response( array('success'=>false), 400 );
            if ( ! WC()->session ) WC()->initialize_session();
            if ( ! WC()->cart )    WC()->initialize_cart();

            $body     = $req->get_json_params() ?: array();
            $cart_key = sanitize_text_field( $body['cart_key'] ?? '' );
            $qty      = max(0, absint( $body['qty'] ?? 0 ));

            if ( $qty === 0 ) {
                WC()->cart->remove_cart_item($cart_key);
            } else {
                WC()->cart->set_quantity($cart_key, $qty);
            }
            WC()->cart->calculate_totals();
            return new WP_REST_Response( array(
                'success'  => true,
                'count'    => WC()->cart->get_cart_contents_count(),
                'subtotal' => floatval( WC()->cart->get_subtotal() ),
            ), 200 );
        },
    ));
} );

// ── Restore custom price from session ─────────────────────────────────────────
add_filter( 'woocommerce_get_cart_item_from_session', function( $cart_item, $values, $key ) {
    if ( isset($values['_caterme_custom_price']) ) {
        $cart_item['_caterme_custom_price'] = $values['_caterme_custom_price'];
        $cart_item['data']->set_price( $values['_caterme_custom_price'] );
    }
    return $cart_item;
}, 10, 3 );

// ── Display fulfillment summary in WC admin order ─────────────────────────────
add_action( 'woocommerce_admin_order_data_after_shipping_address', function( $order ) {
    $fulfillment = get_post_meta( $order->get_id(), '_caterme_fulfillment', true );
    if ( ! $fulfillment ) return;
    $date = get_post_meta( $order->get_id(), '_caterme_order_date', true );
    $time = get_post_meta( $order->get_id(), '_caterme_order_time', true );
    $addr = get_post_meta( $order->get_id(), '_caterme_delivery_address', true );
    $tip  = get_post_meta( $order->get_id(), '_caterme_tip', true );
    ?>
    <div style="margin-top:16px;">
        <h4>🍽️ CaterMe Fulfillment</h4>
        <p><strong>Type:</strong> <?php echo $fulfillment === 'delivery' ? '🚗 Delivery' : '🏪 Pick Up'; ?></p>
        <?php if ($date): ?><p><strong>Date:</strong> <?php echo esc_html(date('l, F j, Y', strtotime($date))); ?></p><?php endif; ?>
        <?php if ($time): ?><p><strong>Time:</strong> <?php echo esc_html(date('g:i a', strtotime('2000-01-01 '.$time))); ?></p><?php endif; ?>
        <?php if ($addr): ?><p><strong>Address:</strong> <?php echo esc_html($addr); ?></p><?php endif; ?>
        <?php if ($tip > 0): ?><p><strong>Tip:</strong> $<?php echo number_format(floatval($tip),2); ?></p><?php endif; ?>
    </div>
    <?php
} );
