<?php
/**
 * CaterMe — Sample Data Importer
 *
 * Creates WooCommerce product categories and products for the full Boone's Deli
 * sample menu. Run once from CaterMe → Settings → Tools tab, or via WP-CLI:
 *
 *   wp eval-file wp-content/plugins/caterme/includes/sample-data.php
 *
 * Safe to re-run — skips products that already exist (matched by slug).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Admin page hook ──────────────────────────────────────────────────────────

add_action( 'admin_init', function() {
    if ( ( $_GET['caterme_action'] ?? '' ) !== 'import_sample_data' ) return;
    if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
    if ( ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'caterme_import_sample' ) ) wp_die('Invalid nonce');

    $result = caterme_import_sample_data();
    $msg    = rawurlencode( $result['message'] );
    wp_redirect( admin_url("admin.php?page=caterme-settings&tab=tools&caterme_import_result={$msg}") );
    exit;
} );


// ─── Core importer ───────────────────────────────────────────────────────────

/**
 * Import all sample categories and products.
 * Returns array( 'created'=>int, 'skipped'=>int, 'message'=>string ).
 */
function caterme_import_sample_data() {
    if ( ! function_exists('wc_create_product') && ! class_exists('WC_Product_Simple') ) {
        return array( 'created'=>0, 'skipped'=>0, 'message'=>'WooCommerce is not active.' );
    }

    $created = 0;
    $skipped = 0;

    foreach ( caterme_sample_menu() as $cat_data ) {
        $cat_id = caterme_ensure_product_category(
            $cat_data['name'],
            $cat_data['icon']
        );

        foreach ( $cat_data['items'] as $item ) {
            $slug = 'caterme-' . sanitize_title( $item['name'] );

            // Skip if product with this slug already exists
            $existing = get_page_by_path( $slug, OBJECT, 'product' );
            if ( $existing ) {
                $skipped++;
                continue;
            }

            $product = new WC_Product_Simple();
            $product->set_name( $item['name'] );
            $product->set_slug( $slug );
            $product->set_status( 'publish' );
            $product->set_catalog_visibility( 'hidden' ); // don't show in WC shop front
            $product->set_short_description( $item['description'] );
            $product->set_regular_price( (string) $item['price'] );
            $product->set_manage_stock( false );
            $product->set_sold_individually( false );
            $product->set_virtual( true );   // no shipping
            $product->set_category_ids( array( $cat_id ) );

            $product_id = $product->save();

            if ( ! $product_id || is_wp_error($product_id) ) continue;

            // CaterMe-specific meta
            if ( ! empty($item['unit']) ) {
                update_post_meta( $product_id, '_caterme_unit', $item['unit'] );
            }
            if ( ! empty($item['tag']) ) {
                update_post_meta( $product_id, '_caterme_tag', $item['tag'] );
            }
            if ( ! empty($item['no_print']) ) {
                update_post_meta( $product_id, '_caterme_no_print', '1' );
            }
            if ( ! empty($item['options']) ) {
                update_post_meta( $product_id, '_caterme_modifiers', wp_json_encode( $item['options'] ) );
            }

            $created++;
        }
    }

    $message = sprintf(
        'Import complete. %d product%s created, %d already existed and were skipped.',
        $created, $created === 1 ? '' : 's',
        $skipped
    );

    return array( 'created' => $created, 'skipped' => $skipped, 'message' => $message );
}


// ─── Sample menu data ─────────────────────────────────────────────────────────

function caterme_sample_menu() {
    return array(

        // ── Boxes ─────────────────────────────────────────────────────────────
        array(
            'name' => 'Boxes',
            'icon' => '🥡',
            'items' => array(

                array(
                    'name'        => 'Standard Sandwich Box',
                    'price'       => 12.00,
                    'tag'         => 'Sandwich',
                    'unit'        => '',
                    'description' => "Choice of one protein, homemade chicken salad, or Papa's pimento cheese. Served on a mini-bun with cheddar cheese, lettuce, tomato, and red onion. Includes pickle spear, Zapp's chips or small homemade potato salad, and a cookie. *GF bread +$2.00",
                    'options'     => array(
                        array('key'=>'protein','label'=>'Protein / Filling','type'=>'select','required'=>true,'choices'=>array("Homemade Chicken Salad","Papa's Pimento Cheese","Ham","Chicken","Turkey","Roast Beef","Corned Beef"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Small Homemade Potato Salad","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'gf','label'=>'Gluten-Free Bread (+$2.00)','type'=>'toggle','required'=>false,'choices'=>array(),'price'=>2.00,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Premium Sandwich Box',
                    'price'       => 15.00,
                    'tag'         => 'Sandwich',
                    'unit'        => '',
                    'description' => "Full sandwich with choice of one protein, Club, chicken salad, or Papa's pimento cheese. Served on wheat or white bread with cheddar cheese, lettuce, tomato, and red onion. Includes pickle spear, Zapp's chips or small homemade potato salad, and a cookie. *GF bread +\$2.00",
                    'options'     => array(
                        array('key'=>'protein','label'=>'Protein / Filling','type'=>'select','required'=>true,'choices'=>array("Club","Homemade Chicken Salad","Papa's Pimento Cheese","Ham","Chicken","Turkey","Roast Beef","Corned Beef"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'bread','label'=>'Bread','type'=>'select','required'=>true,'choices'=>array("Wheat","White"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Small Homemade Potato Salad","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'gf','label'=>'Gluten-Free Bread (+$2.00)','type'=>'toggle','required'=>false,'choices'=>array(),'price'=>2.00,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Standard Wrap Box',
                    'price'       => 15.00,
                    'tag'         => 'Wrap',
                    'unit'        => '',
                    'description' => "Choice of one protein, cheddar cheese, lettuce, tomato, and onion. Served on white or wheat wrap with pickle spear, Zapp's chips, and a cookie. Mustard and mayo packet included.",
                    'options'     => array(
                        array('key'=>'protein','label'=>'Protein','type'=>'select','required'=>true,'choices'=>array("Ham","Chicken","Turkey","Roast Beef","Corned Beef"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'wrap','label'=>'Wrap Type','type'=>'select','required'=>true,'choices'=>array("White","Wheat"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'The HBH Wrap Box',
                    'price'       => 15.00,
                    'tag'         => 'Wrap',
                    'unit'        => '',
                    'description' => "Ham, bacon, cheddar cheese, shredded lettuce, tomato, red onion, and honey mustard. Served on white or wheat wrap with pickle spear, Zapp's chips, and a cookie.",
                    'options'     => array(
                        array('key'=>'wrap','label'=>'Wrap Type','type'=>'select','required'=>true,'choices'=>array("White","Wheat"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Chicken Caesar Wrap Box',
                    'price'       => 15.00,
                    'tag'         => 'Wrap',
                    'unit'        => '',
                    'description' => "Sliced rotisserie chicken, romaine lettuce, croutons, shredded Parmesan, Caesar dressing. Served on white or wheat wrap with pickle spear, Zapp's chips, and a cookie.",
                    'options'     => array(
                        array('key'=>'wrap','label'=>'Wrap Type','type'=>'select','required'=>true,'choices'=>array("White","Wheat"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'House Salad Box',
                    'price'       => 15.00,
                    'tag'         => 'Salad',
                    'unit'        => '',
                    'description' => "Shredded iceberg lettuce with choice of protein, diced tomato, red onion, shredded cheddar cheese, and croutons. Accompanied by homemade dressings. Served with Zapp's chips, a cookie, and a utensil packet.",
                    'options'     => array(
                        array('key'=>'protein','label'=>'Protein','type'=>'select','required'=>true,'choices'=>array("Ham","Chicken","Turkey","Roast Beef","Corned Beef"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array("Ranch","Spicy Ranch","Italian","Greek","Honey Mustard","Caesar"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Veggie Salad Box',
                    'price'       => 14.00,
                    'tag'         => 'Salad',
                    'unit'        => '',
                    'description' => "Shredded iceberg lettuce, diced tomato, onion, cucumber, carrot, bell pepper, banana peppers, and shredded cheddar cheese. Accompanied by homemade dressings. Served with Zapp's chips, a cookie, and a utensil packet.",
                    'options'     => array(
                        array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array("Ranch","Spicy Ranch","Italian","Greek","Honey Mustard","Caesar"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Classic Club Salad Box',
                    'price'       => 16.00,
                    'tag'         => 'Salad',
                    'unit'        => '',
                    'description' => "Shredded iceberg lettuce, ham, turkey, bacon, diced tomato, red onion, croutons. Accompanied by homemade dressings. Served with Zapp's chips, a cookie, and a utensil packet.",
                    'options'     => array(
                        array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array("Ranch","Spicy Ranch","Italian","Greek","Honey Mustard","Caesar"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Chicken Caesar Salad Box',
                    'price'       => 15.00,
                    'tag'         => 'Salad',
                    'unit'        => '',
                    'description' => "Romaine lettuce, sliced rotisserie chicken, shredded Parmesan cheese, croutons. Accompanied by homemade dressings. Served with Zapp's chips, a cookie, and a utensil packet.",
                    'options'     => array(
                        array('key'=>'dressing','label'=>'Dressing','type'=>'select','required'=>true,'choices'=>array("Ranch","Spicy Ranch","Italian","Greek","Honey Mustard","Caesar"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                        array('key'=>'side','label'=>'Side','type'=>'select','required'=>true,'choices'=>array("Zapp's Chips","Upgrade to Hal's Chips (+\$0.75)"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),
            ),
        ),

        // ── Platters ──────────────────────────────────────────────────────────
        array(
            'name' => 'Platters',
            'icon' => '🍽️',
            'items' => array(
                array(
                    'name'        => 'Sandwich Tray',
                    'price'       => 81.00,
                    'tag'         => '',
                    'unit'        => '',
                    'description' => "18 mini-buns filled with your choice of any of our proteins, or The Veg, topped with lettuce and tomato. Served with onions on the side and mayo/mustard packets.",
                    'options'     => array(
                        array('key'=>'protein','label'=>'Protein / Filling','type'=>'select','required'=>true,'choices'=>array("The Veg","Ham","Chicken","Turkey","Roast Beef","Corned Beef","Homemade Chicken Salad","Papa's Pimento Cheese"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),
            ),
        ),

        // ── Sides ─────────────────────────────────────────────────────────────
        array(
            'name' => 'Sides',
            'icon' => '🥔',
            'items' => array(

                array(
                    'name'        => "Assorted Hal's Chips",
                    'price'       => 3.00,
                    'tag'         => '',
                    'unit'        => '',
                    'no_print'    => true,
                    'description' => 'Imported directly from New York City, and unique to us.',
                    'options'     => array(),
                ),

                array(
                    'name'        => 'Signature Potato Salad',
                    'price'       => 10.00,
                    'tag'         => '',
                    'unit'        => '/lb',
                    'description' => 'Diced potatoes in a creamy mayo and mustard dressing. Serves approx. 4 individuals per pound.',
                    'options'     => array(
                        array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Cole Slaw',
                    'price'       => 7.00,
                    'tag'         => '',
                    'unit'        => '/lb',
                    'description' => 'Red & white cabbage, carrot, in a creamy coleslaw dressing. Serves approx. 5 individuals per pound.',
                    'options'     => array(
                        array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Rotating Pasta Salad',
                    'price'       => 9.00,
                    'tag'         => '',
                    'unit'        => '/lb',
                    'description' => "Inquire about this week's pasta salad. Serves approx. 4 individuals per pound. For specific requests, please provide 48-hour notice.",
                    'options'     => array(
                        array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Fresh Cut Fruit',
                    'price'       => 8.00,
                    'tag'         => '',
                    'unit'        => '/lb',
                    'description' => 'Selection of freshly diced fruit. Fruit selection dependent on season and market availability. Serves approx. 5 individuals per pound.',
                    'options'     => array(
                        array('key'=>'lbs','label'=>'Pounds','type'=>'number','required'=>false,'choices'=>array(),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),
            ),
        ),

        // ── Drinks ────────────────────────────────────────────────────────────
        array(
            'name' => 'Drinks',
            'icon' => '🥤',
            'items' => array(

                array(
                    'name'        => 'Assorted Bottled Soft Drinks',
                    'price'       => 3.00,
                    'tag'         => '',
                    'unit'        => '',
                    'no_print'    => true,
                    'description' => 'Assorted flavors.',
                    'options'     => array(),
                ),

                array(
                    'name'        => 'Assorted Bottled Gold Peak Tea',
                    'price'       => 3.00,
                    'tag'         => '',
                    'unit'        => '',
                    'no_print'    => true,
                    'description' => 'Assorted varieties.',
                    'options'     => array(),
                ),

                array(
                    'name'        => 'Dasani Bottled Water',
                    'price'       => 3.00,
                    'tag'         => '',
                    'unit'        => '',
                    'no_print'    => true,
                    'description' => '',
                    'options'     => array(),
                ),
            ),
        ),

        // ── Desserts ──────────────────────────────────────────────────────────
        array(
            'name' => 'Desserts',
            'icon' => '🍪',
            'items' => array(

                array(
                    'name'        => 'Killer Brownie',
                    'price'       => 3.50,
                    'tag'         => '',
                    'unit'        => '',
                    'description' => 'Choose from either Brookie (Chocolate chip cookie brownie) or Chocolatier.',
                    'options'     => array(
                        array('key'=>'type','label'=>'Brownie Type','type'=>'select','required'=>true,'choices'=>array("Brookie (Chocolate Chip Cookie Brownie)","Chocolatier"),'price'=>0,'min'=>1,'default'=>1,'max_selections'=>1),
                    ),
                ),

                array(
                    'name'        => 'Chocolate Chip Cookie',
                    'price'       => 2.00,
                    'tag'         => '',
                    'unit'        => '',
                    'description' => 'Baked fresh and individually wrapped. Other cookie options available with 48-hour notice.',
                    'options'     => array(),
                ),
            ),
        ),

    );
}


// ─── Helper: get or create a product category with CaterMe icon ───────────────

function caterme_ensure_product_category( $name, $icon ) {
    $term = get_term_by( 'name', $name, 'product_cat' );
    if ( $term ) {
        // Update icon if not already set
        if ( ! get_term_meta($term->term_id, '_caterme_icon', true) ) {
            update_term_meta( $term->term_id, '_caterme_icon', $icon );
        }
        return $term->term_id;
    }

    $result = wp_insert_term( $name, 'product_cat' );
    if ( is_wp_error($result) ) return 0;

    $term_id = $result['term_id'];
    update_term_meta( $term_id, '_caterme_icon', $icon );
    return $term_id;
}
