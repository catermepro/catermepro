<?php
/**
 * CaterMe — WooCommerce Shop Page Override
 *
 * Replaces the WooCommerce shop/product-archive output with the CaterMe React
 * UI (category tabs, tag filters, product grid, modifier modal, cart drawer).
 *
 * Strategy:
 *   1. On is_shop() || is_product_category(), remove all WC product-loop hooks.
 *   2. Inject the React mount point + data globals via the_content filter on
 *      the shop page, or via woocommerce_before_shop_loop.
 *   3. Remove WC's native cart widget and inject the floating cart button.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Only run on WC shop/archive pages ────────────────────────────────────────
function caterme_is_shop_page() {
    return function_exists('is_shop') && ( is_shop() || is_product_category() );
}

// ── Enqueue shop assets ───────────────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', function() {
    if ( ! caterme_is_shop_page() ) return;

    $ver = CATERME_VERSION;
    $dir = plugin_dir_url( dirname(__FILE__) );

    // React + ReactDOM + Babel (CDN)
    wp_enqueue_script( 'react',     'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js',     array(), null, true );
    wp_enqueue_script( 'react-dom', 'https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js', array('react'), null, true );
    wp_enqueue_script( 'babel',     'https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.23.2/babel.min.js',          array(), null, true );

    // Our shop React app
    wp_register_script( 'caterme-shop', $dir . 'js/shop.js?v=' . $ver, array('react','react-dom','babel'), null, true );

    // Inline the settings + menu data before shop.js executes
    $settings  = caterme_get_settings();
    $pub       = array();
    foreach ( $settings as $k => $v ) {
        if ( $k === 'sheets_webhook' ) continue;
        $pub[$k] = ($v === null) ? '' : $v;
    }
    $pub['rest_url']          = esc_url( rest_url('caterme/v1/submit') );
    $pub['rest_nonce']        = wp_create_nonce('wp_rest');
    $pub['delivery_fee_url']  = esc_url( rest_url('caterme/v1/delivery-fee') );
    $pub['availability_url']  = esc_url( rest_url('caterme/v1/availability') );
    $pub['checkout_url']      = esc_url( wc_get_checkout_url() );
    $pub['wc_cart_url']       = esc_url( wc_get_cart_url() );
    $pub['wc_active']         = caterme_wc_active() && (($settings['wc_enabled']??'1')==='1') && (($settings['test_mode']??'0')!=='1');
    $pub['test_mode']         = ($settings['test_mode']??'0') === '1';
    $pub['lead_time_hours']   = (int)($settings['lead_time_hours'] ?? 0);
    $pub['store_lat']         = (float)($settings['store_lat'] ?? 0);
    $pub['store_lng']         = (float)($settings['store_lng'] ?? 0);
    $pub['wc_preauth_note']   = (string)($settings['wc_preauth_note'] ?? '');

    // Menu data
    $menu_raw    = caterme_get_wc_menu();
    $menu_for_js = array('categories' => array(), 'items' => array());
    foreach ( ($menu_raw['categories'] ?? array()) as $cat ) {
        $cat_name = $cat['name'] ?? '';
        $menu_for_js['categories'][] = array('name' => $cat_name, 'icon' => $cat['icon'] ?? '🍽️');
        $menu_for_js['items'][$cat_name] = $cat['items'] ?? array();
    }

    $inline = 'var CATERME_SETTINGS=' . wp_json_encode($pub) . ';';
    $inline .= 'var CATERME_MENU='     . wp_json_encode($menu_for_js) . ';';
    wp_add_inline_script( 'caterme-shop', $inline, 'before' );
    wp_enqueue_script( 'caterme-shop' );

    // Shop CSS
    wp_enqueue_style( 'caterme-shop', $dir . 'css/shop.css?v=' . $ver );
} );

// ── Remove WC product loop and replace with React mount ──────────────────────
add_action( 'wp', function() {
    if ( ! caterme_is_shop_page() ) return;

    // Remove WC product loop hooks
    remove_action( 'woocommerce_before_shop_loop',       'woocommerce_output_all_notices',      10 );
    remove_action( 'woocommerce_before_shop_loop',       'woocommerce_result_count',             20 );
    remove_action( 'woocommerce_before_shop_loop',       'woocommerce_catalog_ordering',         30 );
    remove_action( 'woocommerce_after_shop_loop',        'woocommerce_pagination',               10 );
    remove_action( 'woocommerce_no_products_found',      'wc_no_products_found',                 10 );
    remove_action( 'woocommerce_shop_loop',              'woocommerce_template_loop_product',    10 );

    // Inject React mount point
    add_action( 'woocommerce_before_main_content', function() {
        echo '<div id="caterme-shop-root" class="caterme-shop-wrap"></div>';
        echo '<script type="text/babel" src="' . esc_url( plugin_dir_url(dirname(__FILE__)) . 'js/shop.js?v=' . CATERME_VERSION ) . '"></script>';
    }, 5 );

    // Suppress WC's own product list output entirely
    add_filter( 'woocommerce_product_loop', '__return_false' );
} );

// ── Floating cart button (all front-end pages when CaterMe shop active) ───────
// Inject a persistent floating cart button + React cart drawer mount outside
// the shop wrapper so it persists across page navigation if WC persists cart.
add_action( 'wp_footer', function() {
    if ( ! caterme_is_shop_page() ) return;
    // The shop.js React app mounts into #caterme-shop-root and manages its own
    // cart drawer — no separate injection needed.
} );
