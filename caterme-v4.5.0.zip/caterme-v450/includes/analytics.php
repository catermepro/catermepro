<?php
/**
 * CaterMe — Analytics & Error Tracking
 *
 * Captures:
 *   - Business events: order submitted, label printed, features used
 *   - PHP errors: caught via set_error_handler + register_shutdown_function
 *   - JS errors: collected via REST endpoint from the frontend
 *   - Customer flow: page views, cart events, checkout funnel
 *
 * All data is stored locally in caterme_events / caterme_errors tables
 * and optionally forwarded to a telemetry endpoint.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─────────────────────────────────────────────────────────────────────────────
// DATABASE TABLES (created by caterme_create_tables in caterme.php)
// ─────────────────────────────────────────────────────────────────────────────

function caterme_create_analytics_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $events = $wpdb->prefix . 'caterme_events';
    $errors = $wpdb->prefix . 'caterme_errors';

    $wpdb->query( "CREATE TABLE IF NOT EXISTS `{$events}` (
        `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `event_type` VARCHAR(80)     NOT NULL DEFAULT '',
        `session_id` VARCHAR(64)     NOT NULL DEFAULT '',
        `meta`       LONGTEXT,
        `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `event_type` (`event_type`),
        KEY `created_at` (`created_at`)
    ) {$charset}" );

    $wpdb->query( "CREATE TABLE IF NOT EXISTS `{$errors}` (
        `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `error_type` VARCHAR(40)     NOT NULL DEFAULT 'php',
        `message`    TEXT            NOT NULL,
        `context`    LONGTEXT,
        `url`        VARCHAR(500)    NOT NULL DEFAULT '',
        `resolved`   TINYINT(1)      NOT NULL DEFAULT 0,
        `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `error_type` (`error_type`),
        KEY `resolved`   (`resolved`),
        KEY `created_at` (`created_at`)
    ) {$charset}" );
}

// ─────────────────────────────────────────────────────────────────────────────
// SITE ID — unique identifier for this installation
// ─────────────────────────────────────────────────────────────────────────────

function caterme_get_site_id() {
    $id = get_option( 'caterme_site_id' );
    if ( ! $id ) {
        $id = wp_generate_uuid4();
        update_option( 'caterme_site_id', $id );
    }
    return $id;
}

// ─────────────────────────────────────────────────────────────────────────────
// EVENT TRACKING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Track a business event.
 *
 * @param string $type  e.g. 'order_submitted', 'label_printed', 'error'
 * @param array  $meta  Arbitrary metadata (will be JSON-encoded)
 */
function caterme_track_event( $type, $meta = array() ) {
    global $wpdb;

    // Always add plan + timestamp context
    $meta['plan']       = caterme_get_plan();
    $meta['site_id']    = caterme_get_site_id();
    $meta['wp_version'] = get_bloginfo('version');
    $meta['cm_version'] = CATERME_VERSION;

    $session_id = caterme_session_id();

    $events_table = $wpdb->prefix . 'caterme_events';

    // Suppress errors if table doesn't exist yet (e.g. during activation)
    $wpdb->query( $wpdb->prepare(
        "INSERT INTO `{$events_table}` (event_type, session_id, meta, created_at) VALUES (%s, %s, %s, %s)",
        $type,
        $session_id,
        wp_json_encode( $meta ),
        current_time( 'mysql' )
    ) );

    // Enqueue for telemetry (batched, sent on shutdown)
    caterme_telemetry_enqueue( $type, $meta, $session_id );
}

/**
 * Get or create an anonymous session ID for this browser session.
 * Used to reconstruct customer flow funnels.
 */
function caterme_session_id() {
    // For admin events, use user ID based key
    if ( is_user_logged_in() ) {
        return 'admin_' . get_current_user_id();
    }
    // For frontend, use a cookie-based session
    $cookie_key = 'caterme_sid';
    if ( isset( $_COOKIE[ $cookie_key ] ) && preg_match('/^[a-f0-9]{32}$/', $_COOKIE[ $cookie_key ]) ) {
        return $_COOKIE[ $cookie_key ];
    }
    $sid = md5( uniqid( '', true ) );
    // Set cookie for 24h (won't work in REST context but that's ok)
    if ( ! headers_sent() ) {
        setcookie( $cookie_key, $sid, time() + 86400, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
    }
    return $sid;
}

// ─────────────────────────────────────────────────────────────────────────────
// ERROR LOGGING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Log a CaterMe-specific error.
 *
 * @param string $message  Human-readable error message
 * @param array  $context  Additional context (stack trace, request data, etc.)
 * @param string $type     'php' | 'js' | 'api' | 'db'
 */
function caterme_log_error( $message, $context = array(), $type = 'php' ) {
    global $wpdb;

    $context['plan']    = caterme_get_plan();
    $context['site_id'] = caterme_get_site_id();
    $context['version'] = CATERME_VERSION;

    $errors_table = $wpdb->prefix . 'caterme_errors';

    $wpdb->query( $wpdb->prepare(
        "INSERT INTO `{$errors_table}` (error_type, message, context, url, created_at) VALUES (%s, %s, %s, %s, %s)",
        $type,
        $message,
        wp_json_encode( $context ),
        $_SERVER['REQUEST_URI'] ?? '',
        current_time( 'mysql' )
    ) );

    // Also track as an event so it shows in the timeline
    caterme_track_event( 'error', array_merge( $context, array(
        'error_type' => $type,
        'message'    => $message,
    ) ) );

    // ── Instant email alert ──────────────────────────────────────────────────
    caterme_send_error_alert( $message, $context, $type );
}

/**
 * Send an immediate email alert when an error is logged.
 * Respects a 5-minute cooldown per unique error message to prevent floods.
 * Recipient is set in Settings → Integrations → Error Alert Email.
 */
function caterme_send_error_alert( $message, $context = array(), $type = 'php' ) {
    // ── Permanent alert recipient — always receives error reports ───────────────
    // This ensures the CaterMe developer gets every error from every beta site
    // regardless of what individual plugin users configure.
    $permanent_recipient = 'catermepro@gmail.com';

    // Site admin may also configure a secondary recipient in Settings → Integrations
    $settings           = caterme_get_settings();
    $site_recipient     = sanitize_email( $settings['error_alert_email'] ?? '' );

    // Allow filters to override site recipient (used by test alert button)
    $site_recipient = apply_filters( 'caterme_error_alert_recipient', $site_recipient );

    // Build recipient list — permanent always included, site admin added if different
    $recipients = array( $permanent_recipient );
    if ( $site_recipient && $site_recipient !== $permanent_recipient ) {
        $recipients[] = $site_recipient;
    }
    $recipient = implode( ', ', $recipients );

    // ── Cooldown: don't flood the inbox with the same error ──────────────────
    // Key is based on error type + first 80 chars of message
    $cooldown_key = 'caterme_err_cooldown_' . md5( $type . substr( $message, 0, 80 ) );
    if ( get_transient( $cooldown_key ) ) return;
    set_transient( $cooldown_key, 1, 5 * MINUTE_IN_SECONDS );

    $site_name   = get_bloginfo( 'name' );
    $site_url    = get_site_url();
    $plan        = caterme_get_plan();
    $version     = CATERME_VERSION;
    $admin_url   = admin_url( 'admin.php?page=caterme-analytics' );
    $time        = current_time( 'D, M j Y @ g:i a' );
    $request_url = $context['url'] ?? ( $_SERVER['REQUEST_URI'] ?? '' );
    $file        = $context['file'] ?? '';
    $line        = isset( $context['line'] ) ? (int) $context['line'] : 0;
    $stack       = $context['stack'] ?? '';
    $user_agent  = $context['user_agent'] ?? ( $_SERVER['HTTP_USER_AGENT'] ?? '' );

    $type_upper  = strtoupper( $type );

    $subject = "[CaterMe {$type_upper} Error] {$site_name}: " . substr( $message, 0, 60 ) . ( strlen($message) > 60 ? '…' : '' );

    // ── Plain text body ──────────────────────────────────────────────────────
    $text_body = "CaterMe Error Alert
";
    $text_body .= str_repeat("=", 60) . "

";
    $text_body .= "Site:     {$site_name} ({$site_url})
";
    $text_body .= "Time:     {$time}
";
    $text_body .= "Type:     {$type_upper}
";
    $text_body .= "Plan:     {$plan}
";
    $text_body .= "Version:  CaterMe {$version}

";
    $text_body .= "ERROR:
{$message}

";
    if ( $file ) $text_body .= "File: {$file}" . ( $line ? ":{$line}" : "" ) . "
";
    if ( $request_url ) $text_body .= "URL:  {$request_url}
";
    if ( $stack ) $text_body .= "
Stack Trace:
{$stack}
";
    $text_body .= "
View all errors: {$admin_url}
";

    // ── HTML body ────────────────────────────────────────────────────────────
    $type_color = array(
        'php'       => '#dc2626',
        'php_fatal' => '#7f1d1d',
        'js'        => '#d97706',
        'api'       => '#2563eb',
        'db'        => '#7c3aed',
    )[ $type ] ?? '#555';

    $stack_html = $stack
        ? "<div style='margin-top:12px;'><strong>Stack Trace:</strong><pre style='background:#1a1208;color:#f5e6c8;padding:14px;border-radius:8px;font-size:12px;overflow-x:auto;white-space:pre-wrap;'>" . esc_html( $stack ) . "</pre></div>"
        : '';

    $file_html = $file
        ? "<tr><td style='padding:6px 12px;color:#888;width:100px;'>File</td><td style='padding:6px 12px;font-family:monospace;font-size:13px;'>" . esc_html($file) . ( $line ? ":{$line}" : "" ) . "</td></tr>"
        : '';

    $url_html = $request_url
        ? "<tr><td style='padding:6px 12px;color:#888;'>URL</td><td style='padding:6px 12px;font-size:13px;'>" . esc_html($request_url) . "</td></tr>"
        : '';

    $ua_html = $user_agent && $type === 'js'
        ? "<tr><td style='padding:6px 12px;color:#888;'>Browser</td><td style='padding:6px 12px;font-size:13px;'>" . esc_html( substr($user_agent,0,120) ) . "</td></tr>"
        : '';

    $html_body = "
    <div style='font-family:system-ui,sans-serif;max-width:640px;margin:0 auto;background:#f9f7f4;padding:24px;'>

      <!-- Header -->
      <div style='background:#1a1208;border-radius:10px 10px 0 0;padding:18px 24px;display:flex;align-items:center;gap:14px;'>
        <div style='background:{$type_color};border-radius:6px;padding:6px 14px;font-weight:800;font-size:13px;color:#fff;letter-spacing:1px;text-transform:uppercase;'>{$type_upper}</div>
        <div>
          <div style='color:#f5e6c8;font-weight:700;font-size:16px;'>CaterMe Error Alert</div>
          <div style='color:#c8a67a;font-size:12px;margin-top:2px;'>{$site_name} &nbsp;·&nbsp; {$time}</div>
        </div>
      </div>

      <!-- Error message -->
      <div style='background:#fff;border:1.5px solid {$type_color};border-top:none;border-radius:0 0 10px 10px;padding:0;margin-bottom:16px;overflow:hidden;'>
        <div style='background:{$type_color};color:#fff;padding:10px 20px;font-size:13px;font-weight:700;'>Error Message</div>
        <div style='padding:16px 20px;font-size:14px;font-weight:600;color:#1a1208;line-height:1.5;word-break:break-word;'>" . esc_html($message) . "</div>

        <!-- Meta table -->
        <table style='width:100%;border-collapse:collapse;border-top:1px solid #f0e8d8;font-size:13px;'>
          <tr style='background:#faf7f2;'>
            <td style='padding:6px 12px;color:#888;width:100px;'>Plan</td>
            <td style='padding:6px 12px;'><span style='background:{$type_color};color:#fff;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;text-transform:uppercase;'>{$plan}</span></td>
          </tr>
          <tr>
            <td style='padding:6px 12px;color:#888;'>Version</td>
            <td style='padding:6px 12px;font-family:monospace;font-size:12px;'>CaterMe {$version}</td>
          </tr>
          {$file_html}
          {$url_html}
          {$ua_html}
        </table>

        {$stack_html}
      </div>

      <!-- CTA -->
      <div style='text-align:center;margin-top:8px;'>
        <a href='{$admin_url}' style='display:inline-block;background:#c8522a;color:#fff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;font-size:14px;'>
          View Error Log →
        </a>
      </div>

      <p style='text-align:center;font-size:11px;color:#bbb;margin-top:20px;'>
        This alert was sent because an error occurred in the CaterMe plugin on <a href='{$site_url}' style='color:#c8a67a;'>{$site_url}</a>.<br>
        To change the recipient, go to <strong>CaterMe → Settings → Integrations</strong>.
      </p>
    </div>";

    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'X-CaterMe-Error-Type: ' . $type,
        'X-CaterMe-Version: ' . $version,
    );

    wp_mail( $recipient, $subject, $html_body, $headers );
}

// ─────────────────────────────────────────────────────────────────────────────
// PHP ERROR HANDLER
// ─────────────────────────────────────────────────────────────────────────────

// Catch PHP errors that occur within CaterMe functions
add_action( 'plugins_loaded', function() {
    // Only capture errors in CaterMe's own code (by checking the file path)
    $original_handler = set_error_handler( function( $errno, $errstr, $errfile, $errline ) use ( &$original_handler ) {
        // Only handle errors from our plugin
        if ( strpos( $errfile, 'caterme' ) !== false ) {
            caterme_log_error( $errstr, array(
                'errno'   => $errno,
                'file'    => str_replace( ABSPATH, '', $errfile ),
                'line'    => $errline,
            ), 'php' );
        }
        // Call the original handler so WordPress still handles it
        if ( $original_handler ) {
            return call_user_func( $original_handler, $errno, $errstr, $errfile, $errline );
        }
        return false;
    }, E_ERROR | E_WARNING | E_NOTICE );
}, 999 );

// Catch fatal errors on shutdown
register_shutdown_function( function() {
    $error = error_get_last();
    if ( $error && in_array( $error['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR ) ) ) {
        if ( strpos( $error['file'], 'caterme' ) !== false ) {
            // Can't use caterme_log_error here (might cause recursion), use direct DB
            global $wpdb;
            if ( $wpdb ) {
                $errors_table = $wpdb->prefix . 'caterme_errors';
                $wpdb->query( $wpdb->prepare(
                    "INSERT INTO `{$errors_table}` (error_type, message, context, url, created_at) VALUES ('php_fatal', %s, %s, %s, %s)",
                    $error['message'],
                    wp_json_encode( array(
                        'file'    => str_replace( ABSPATH, '', $error['file'] ),
                        'line'    => $error['line'],
                        'version' => CATERME_VERSION,
                    ) ),
                    $_SERVER['REQUEST_URI'] ?? '',
                    current_time( 'mysql' )
                ) );
            }
        }
    }
} );

// ─────────────────────────────────────────────────────────────────────────────
// JS ERROR REST ENDPOINT
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/log-error', array(
        'methods'             => 'POST',
        'callback'            => 'caterme_rest_log_js_error',
        'permission_callback' => '__return_true', // anyone can report errors
    ) );
} );

function caterme_rest_log_js_error( WP_REST_Request $request ) {
    $body = $request->get_json_params();
    if ( empty( $body['message'] ) ) {
        return new WP_REST_Response( array( 'ok' => false ), 400 );
    }

    caterme_log_error(
        sanitize_text_field( $body['message'] ),
        array(
            'source'     => sanitize_text_field( $body['source']    ?? '' ),
            'line'       => absint( $body['line']       ?? 0 ),
            'column'     => absint( $body['column']     ?? 0 ),
            'stack'      => sanitize_textarea_field( $body['stack'] ?? '' ),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'page_url'   => sanitize_url( $body['url'] ?? '' ),
        ),
        'js'
    );

    return new WP_REST_Response( array( 'ok' => true ), 200 );
}

// ─────────────────────────────────────────────────────────────────────────────
// JS ERROR SNIPPET (inject into frontend)
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'wp_footer', function() {
    // Only inject on pages with the CaterMe shortcode
    if ( ! is_singular() ) return;
    global $post;
    if ( ! $post || strpos( $post->post_content, 'CaterMe_Menu' ) === false ) return;

    $error_url = esc_url( rest_url( 'caterme/v1/log-error' ) );
    $nonce     = wp_create_nonce( 'wp_rest' );
    ?>
    <script>
    (function() {
        var CM_ERROR_URL = '<?php echo $error_url; ?>';
        var CM_NONCE     = '<?php echo $nonce; ?>';
        window.onerror = function(msg, source, line, col, error) {
            // Only report errors from CaterMe JS
            if (!source || source.indexOf('caterme') === -1) return false;
            fetch(CM_ERROR_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CM_NONCE },
                body: JSON.stringify({
                    message: String(msg),
                    source:  String(source),
                    line:    line,
                    column:  col,
                    stack:   error ? String(error.stack || '') : '',
                    url:     window.location.href
                })
            });
            return false;
        };
    })();
    </script>
    <?php
} );

// ─────────────────────────────────────────────────────────────────────────────
// CUSTOMER FLOW TRACKING (frontend events via REST)
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/track', array(
        'methods'             => 'POST',
        'callback'            => 'caterme_rest_track_frontend_event',
        'permission_callback' => '__return_true',
    ) );
} );

function caterme_rest_track_frontend_event( WP_REST_Request $request ) {
    $body = $request->get_json_params();

    $allowed_events = array(
        'menu_viewed', 'category_selected', 'item_viewed',
        'item_added_to_cart', 'item_removed_from_cart',
        'cart_viewed', 'checkout_started', 'checkout_completed',
        'checkout_abandoned', 'order_confirmed_by_customer',
        'payment_redirect', 'payment_success', 'payment_failed',
    );

    $event = sanitize_text_field( $body['event'] ?? '' );
    if ( ! in_array( $event, $allowed_events ) ) {
        return new WP_REST_Response( array( 'ok' => false, 'reason' => 'Unknown event' ), 400 );
    }

    $meta = array();
    $safe_keys = array( 'category', 'item_name', 'item_price', 'cart_total', 'cart_count', 'order_number', 'fulfillment', 'page_url' );
    foreach ( $safe_keys as $k ) {
        if ( isset( $body[ $k ] ) ) {
            $meta[ $k ] = is_numeric( $body[$k] ) ? floatval( $body[$k] ) : sanitize_text_field( $body[$k] );
        }
    }

    caterme_track_event( $event, $meta );
    return new WP_REST_Response( array( 'ok' => true ), 200 );
}

// ─────────────────────────────────────────────────────────────────────────────
// ANALYTICS ADMIN PAGE
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'admin_menu', function() {
    add_submenu_page(
        'caterme-orders',
        'Analytics',
        '📈 Analytics',
        'manage_options',
        'caterme-analytics',
        'caterme_analytics_page'
    );
}, 20 );

function caterme_analytics_page() {
    global $wpdb;
    $events_table = $wpdb->prefix . 'caterme_events';
    $errors_table = $wpdb->prefix . 'caterme_errors';
    $orders_table = $wpdb->prefix . 'caterme_orders';

    // Handle error resolution
    if ( isset( $_POST['resolve_error'], $_POST['error_id'], $_POST['_wpnonce'] )
        && wp_verify_nonce( $_POST['_wpnonce'], 'caterme_resolve_error' ) ) {
        $wpdb->update( $errors_table, array('resolved'=>1), array('id'=> absint($_POST['error_id'])) );
    }
    if ( isset( $_POST['resolve_all_errors'], $_POST['_wpnonce'] )
        && wp_verify_nonce( $_POST['_wpnonce'], 'caterme_resolve_all' ) ) {
        $wpdb->query( "UPDATE `{$errors_table}` SET resolved=1 WHERE resolved=0" );
    }

    $period_days = absint( $_GET['days'] ?? 30 );
    $since = date( 'Y-m-d H:i:s', strtotime( "-{$period_days} days" ) );

    // ── Aggregate stats ──────────────────────────────────────────────────────
    $total_orders        = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$orders_table}`" );
    $orders_this_month   = caterme_get_monthly_order_count();
    $total_events        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$events_table}` WHERE created_at >= %s", $since ) );
    $unresolved_errors   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$errors_table}` WHERE resolved=0" );

    // Orders by status
    $orders_by_status = $wpdb->get_results( "SELECT status, COUNT(*) as cnt FROM `{$orders_table}` GROUP BY status ORDER BY cnt DESC" );

    // Orders by fulfillment
    $orders_by_fulfillment = $wpdb->get_results( "SELECT fulfillment, COUNT(*) as cnt FROM `{$orders_table}` GROUP BY fulfillment" );

    // Daily order volume (last 30d)
    $daily_orders = $wpdb->get_results( $wpdb->prepare(
        "SELECT DATE(created_at) as day, COUNT(*) as cnt FROM `{$orders_table}` WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY day ASC",
        $since
    ) );

    // Top events
    $top_events = $wpdb->get_results( $wpdb->prepare(
        "SELECT event_type, COUNT(*) as cnt FROM `{$events_table}` WHERE created_at >= %s AND event_type NOT IN ('error') GROUP BY event_type ORDER BY cnt DESC LIMIT 12",
        $since
    ) );

    // Customer funnel
    $funnel_events = array( 'menu_viewed', 'item_added_to_cart', 'checkout_started', 'order_submitted' );
    $funnel = array();
    foreach ( $funnel_events as $fe ) {
        $funnel[$fe] = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT session_id) FROM `{$events_table}` WHERE event_type=%s AND created_at >= %s",
            $fe, $since
        ) );
    }

    // Recent errors (unresolved)
    $recent_errors = $wpdb->get_results( "SELECT * FROM `{$errors_table}` WHERE resolved=0 ORDER BY created_at DESC LIMIT 20" );

    // Recent events timeline
    $recent_events = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM `{$events_table}` WHERE created_at >= %s ORDER BY created_at DESC LIMIT 50",
        $since
    ) );

    // Feature usage
    $feature_events = $wpdb->get_results( $wpdb->prepare(
        "SELECT event_type, COUNT(*) as cnt FROM `{$events_table}` WHERE event_type IN ('label_printed','kitchen_ticket_printed','invoice_printed','ezcater_imported','settings_saved','order_submitted','order_confirmed') AND created_at >= %s GROUP BY event_type ORDER BY cnt DESC",
        $since
    ) );

    $status_icons = array( 'new'=>'🆕','confirmed'=>'✅','preparing'=>'👨‍🍳','ready'=>'📦','completed'=>'✔️','cancelled'=>'❌' );
    $error_type_colors = array( 'php'=>'#dc2626','php_fatal'=>'#7f1d1d','js'=>'#d97706','api'=>'#2563eb','db'=>'#7c3aed' );
    ?>
    <div class="wrap" style="max-width:1100px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
            <h1 style="margin:0;">📈 CaterMe Analytics</h1>
            <div style="display:flex;gap:8px;align-items:center;">
                <span style="font-size:13px;color:#888;">Period:</span>
                <?php foreach ( array(7=>'7d',30=>'30d',90=>'90d') as $d=>$label ): ?>
                <a href="?page=caterme-analytics&days=<?php echo $d; ?>"
                   style="padding:5px 12px;border-radius:6px;font-size:13px;font-weight:600;text-decoration:none;<?php echo $period_days===$d ? 'background:#c8522a;color:#fff;' : 'background:#f0e8d8;color:#6b4a32;'; ?>">
                    <?php echo $label; ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if ( $unresolved_errors > 0 ): ?>
        <div style="background:#fef2f2;border:1.5px solid #fca5a5;border-radius:8px;padding:12px 18px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
            <div style="display:flex;align-items:center;gap:10px;">
                <span style="font-size:20px;">🚨</span>
                <div>
                    <strong style="color:#7f1d1d;"><?php echo $unresolved_errors; ?> unresolved error<?php echo $unresolved_errors>1?'s':''; ?></strong>
                    <span style="font-size:13px;color:#b91c1c;margin-left:8px;">Review below</span>
                </div>
            </div>
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('caterme_resolve_all'); ?>
                <button type="submit" name="resolve_all_errors" class="button" style="border-color:#dc2626;color:#dc2626;">✓ Mark all resolved</button>
            </form>
        </div>
        <?php endif; ?>

        <!-- KPI Cards -->
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px;">
            <?php
            $kpis = array(
                array( 'Total Orders', $total_orders, '📦', '#c8522a' ),
                array( 'This Month', $orders_this_month . '/' . CATERME_FREE_ORDER_LIMIT, '📅', '#d4943a' ),
                array( 'Events (' . $period_days . 'd)', number_format($total_events), '📊', '#16a34a' ),
                array( 'Open Errors', $unresolved_errors, '🚨', $unresolved_errors > 0 ? '#dc2626' : '#16a34a' ),
            );
            foreach ( $kpis as list($label, $value, $icon, $color) ):
            ?>
            <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;padding:18px 20px;">
                <div style="font-size:24px;margin-bottom:6px;"><?php echo $icon; ?></div>
                <div style="font-size:28px;font-weight:900;color:<?php echo $color; ?>;"><?php echo $value; ?></div>
                <div style="font-size:12px;color:#888;margin-top:4px;text-transform:uppercase;letter-spacing:1px;"><?php echo $label; ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Two-col layout -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;">

            <!-- Orders by Status -->
            <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Orders by Status</div>
                <div style="padding:16px;">
                    <?php if ( empty($orders_by_status) ): ?>
                    <p style="color:#888;font-size:13px;">No orders yet.</p>
                    <?php else: ?>
                    <?php $max_cnt = max(array_column((array)$orders_by_status,'cnt')); ?>
                    <?php foreach ( $orders_by_status as $row ): ?>
                    <div style="margin-bottom:10px;">
                        <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
                            <span><?php echo ($status_icons[$row->status]??'📋') . ' ' . ucfirst($row->status); ?></span>
                            <strong><?php echo $row->cnt; ?></strong>
                        </div>
                        <div style="background:#f0e8d8;border-radius:999px;height:5px;overflow:hidden;">
                            <div style="background:#c8522a;height:100%;width:<?php echo round(($row->cnt/$max_cnt)*100); ?>%;border-radius:999px;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Customer Funnel -->
            <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Customer Funnel (<?php echo $period_days; ?>d)</div>
                <div style="padding:16px;">
                    <?php
                    $funnel_labels = array(
                        'menu_viewed'      => '👁 Menu viewed',
                        'item_added_to_cart' => '🛒 Item added',
                        'checkout_started'  => '💳 Checkout started',
                        'order_submitted'  => '✅ Order submitted',
                    );
                    $max_f = max(1, max(array_values($funnel)));
                    $prev  = null;
                    foreach ( $funnel_labels as $key => $label ):
                        $val = $funnel[$key] ?? 0;
                        $pct = $prev > 0 ? round(($val/$prev)*100) . '%' : '—';
                        $bar = round(($val/$max_f)*100);
                    ?>
                    <div style="margin-bottom:12px;">
                        <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
                            <span><?php echo $label; ?></span>
                            <span>
                                <strong><?php echo number_format($val); ?></strong>
                                <?php if ($prev !== null): ?>
                                <span style="font-size:11px;color:<?php echo $val>0?'#16a34a':'#888'; ?>;margin-left:6px;">(<?php echo $pct; ?>)</span>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div style="background:#f0e8d8;border-radius:999px;height:5px;overflow:hidden;">
                            <div style="background:#d4943a;height:100%;width:<?php echo $bar; ?>%;border-radius:999px;"></div>
                        </div>
                    </div>
                    <?php $prev = $val; endforeach; ?>
                </div>
            </div>

            <!-- Feature Usage -->
            <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Feature Usage (<?php echo $period_days; ?>d)</div>
                <div style="padding:16px;">
                    <?php if ( empty($feature_events) ): ?>
                    <p style="color:#888;font-size:13px;">No feature events recorded yet.</p>
                    <?php else: ?>
                    <?php $max_fe = max(array_column((array)$feature_events,'cnt')); ?>
                    <?php foreach ( $feature_events as $fe ): ?>
                    <div style="margin-bottom:8px;">
                        <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:3px;">
                            <span style="color:#555;"><?php echo str_replace('_', ' ', $fe->event_type); ?></span>
                            <strong><?php echo $fe->cnt; ?></strong>
                        </div>
                        <div style="background:#f0e8d8;border-radius:999px;height:4px;overflow:hidden;">
                            <div style="background:#c8522a;height:100%;width:<?php echo round(($fe->cnt/$max_fe)*100); ?>%;border-radius:999px;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Fulfillment Split -->
            <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Orders by Fulfillment</div>
                <div style="padding:20px;display:flex;justify-content:center;gap:30px;">
                    <?php
                    $total_ft = array_sum( array_column( (array)$orders_by_fulfillment, 'cnt' ) );
                    foreach ( $orders_by_fulfillment as $row ):
                        $pct_ft = $total_ft > 0 ? round(($row->cnt/$total_ft)*100) : 0;
                        $icon_ft = $row->fulfillment === 'delivery' ? '🚗' : '🏪';
                        $color_ft = $row->fulfillment === 'delivery' ? '#2563eb' : '#c8522a';
                    ?>
                    <div style="text-align:center;">
                        <div style="font-size:36px;font-weight:900;color:<?php echo $color_ft; ?>;"><?php echo $pct_ft; ?>%</div>
                        <div style="font-size:14px;margin-top:4px;"><?php echo $icon_ft . ' ' . ucfirst($row->fulfillment); ?></div>
                        <div style="font-size:12px;color:#888;"><?php echo $row->cnt; ?> orders</div>
                    </div>
                    <?php endforeach; ?>
                    <?php if ( empty($orders_by_fulfillment) ): ?>
                    <p style="color:#888;font-size:13px;">No orders yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Error Log -->
        <div style="background:#fff;border:1.5px solid <?php echo $unresolved_errors > 0 ? '#fca5a5' : '#e0d0b8'; ?>;border-radius:10px;overflow:hidden;margin-bottom:20px;">
            <div style="background:#<?php echo $unresolved_errors > 0 ? '7f1d1d' : '1a1208'; ?>;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;display:flex;justify-content:space-between;align-items:center;">
                <span>🚨 Error Log <?php if($unresolved_errors>0): ?><span style="background:#dc2626;color:#fff;font-size:11px;padding:2px 8px;border-radius:20px;margin-left:8px;"><?php echo $unresolved_errors; ?> open</span><?php endif; ?></span>
            </div>
            <?php if ( empty( $recent_errors ) ): ?>
            <div style="padding:24px;text-align:center;color:#16a34a;font-size:14px;">✅ No unresolved errors. Looking good!</div>
            <?php else: ?>
            <table class="wp-list-table widefat" style="border:none;">
                <thead><tr>
                    <th style="width:100px;">Type</th>
                    <th>Message</th>
                    <th style="width:80px;">URL</th>
                    <th style="width:130px;">Time</th>
                    <th style="width:80px;">Action</th>
                </tr></thead>
                <tbody>
                <?php foreach ( $recent_errors as $err ):
                    $ctx = json_decode( $err->context, true ) ?: array();
                    $type_color = $error_type_colors[$err->error_type] ?? '#555';
                ?>
                <tr>
                    <td>
                        <span style="background:<?php echo $type_color; ?>;color:#fff;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;text-transform:uppercase;"><?php echo esc_html($err->error_type); ?></span>
                    </td>
                    <td>
                        <div style="font-size:13px;font-weight:600;color:#1a1208;"><?php echo esc_html($err->message); ?></div>
                        <?php if ( !empty($ctx['file']) ): ?>
                        <div style="font-size:11px;color:#888;margin-top:2px;font-family:monospace;"><?php echo esc_html($ctx['file']); ?><?php if(!empty($ctx['line'])): ?>:<?php echo $ctx['line']; ?><?php endif; ?></div>
                        <?php endif; ?>
                        <?php if ( !empty($ctx['stack']) ): ?>
                        <details style="margin-top:4px;"><summary style="font-size:11px;color:#c8522a;cursor:pointer;">Stack trace</summary><pre style="font-size:10px;color:#555;overflow-x:auto;max-height:100px;background:#faf7f2;padding:6px;border-radius:4px;white-space:pre-wrap;"><?php echo esc_html($ctx['stack']); ?></pre></details>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:11px;color:#888;word-break:break-all;"><?php echo esc_html(substr($err->url??'',0,40)); ?></td>
                    <td style="font-size:12px;color:#888;white-space:nowrap;"><?php echo human_time_diff(strtotime($err->created_at)); ?> ago</td>
                    <td>
                        <form method="post" style="display:inline;">
                            <?php wp_nonce_field('caterme_resolve_error'); ?>
                            <input type="hidden" name="error_id" value="<?php echo $err->id; ?>" />
                            <button type="submit" name="resolve_error" class="button button-small" style="font-size:11px;">✓ Resolve</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- Recent Event Timeline -->
        <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
            <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Recent Event Timeline (last <?php echo $period_days; ?>d, 50 most recent)</div>
            <?php if ( empty($recent_events) ): ?>
            <p style="padding:20px;color:#888;font-size:13px;">No events recorded yet. Events will appear here as users interact with CaterMe.</p>
            <?php else: ?>
            <div style="padding:16px;max-height:400px;overflow-y:auto;">
                <?php
                $event_icons = array(
                    'order_submitted'   => '📦',
                    'label_printed'     => '🏷️',
                    'invoice_printed'   => '🧾',
                    'kitchen_ticket_printed' => '👨‍🍳',
                    'ezcater_imported'  => '📥',
                    'plan_changed'      => '🔄',
                    'beta_keys_generated' => '🔑',
                    'settings_saved'    => '💾',
                    'error'             => '🚨',
                    'menu_viewed'       => '👁',
                    'item_added_to_cart' => '🛒',
                    'checkout_started'  => '💳',
                    'order_confirmed_by_customer' => '✅',
                );
                foreach ( $recent_events as $ev ):
                    $meta = json_decode($ev->meta, true) ?: array();
                    $icon = $event_icons[$ev->event_type] ?? '📌';
                    $is_error = $ev->event_type === 'error';
                ?>
                <div style="display:flex;gap:12px;padding:8px 0;border-bottom:1px solid #f0e8d8;align-items:flex-start;">
                    <span style="font-size:16px;flex-shrink:0;margin-top:1px;"><?php echo $icon; ?></span>
                    <div style="flex:1;min-width:0;">
                        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
                            <span style="font-size:13px;font-weight:<?php echo $is_error ? '700' : '500'; ?>;color:<?php echo $is_error ? '#dc2626' : '#1a1208'; ?>;">
                                <?php echo str_replace('_', ' ', $ev->event_type); ?>
                            </span>
                            <span style="font-size:11px;color:#aaa;flex-shrink:0;"><?php echo human_time_diff(strtotime($ev->created_at)); ?> ago</span>
                        </div>
                        <?php
                        $interesting = array_filter($meta, function($k) {
                            return !in_array($k, array('plan','site_id','wp_version','cm_version','session_id'));
                        }, ARRAY_FILTER_USE_KEY);
                        if (!empty($interesting)):
                        ?>
                        <div style="font-size:11px;color:#888;margin-top:2px;font-family:monospace;">
                            <?php
                            $parts = array();
                            foreach ( array_slice($interesting, 0, 4) as $k => $v ) {
                                $parts[] = $k . ': ' . (is_array($v) ? json_encode($v) : substr((string)$v, 0, 50));
                            }
                            echo esc_html( implode(' · ', $parts) );
                            ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
