<?php
/**
 * CaterMe — Order Notification Emails
 *
 * Sends rich HTML emails to a configurable list of recipients on:
 *   1. New order submitted (before payment)
 *   2. Payment pre-authorized (WC order moves to on-hold)
 *   3. Order confirmed by admin (payment captured)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Parse the notify_emails setting into a clean array.
 */
function caterme_get_notify_recipients() {
    $s    = caterme_get_settings();
    $raw  = $s['notify_emails'] ?? '';
    if ( empty( trim($raw) ) ) return array();
    $list = array_filter( array_map( 'trim', preg_split('/[\s,;]+/', $raw) ) );
    return array_values( array_unique( array_filter( $list, 'is_email' ) ) );
}

/**
 * Resolve the email subject, replacing {order_number} tokens.
 */
function caterme_notify_subject( $template, $order_number, $event_label = '' ) {
    $s = str_replace( '{order_number}', $order_number, $template );
    if ( $event_label ) $s .= ' — ' . $event_label;
    return $s;
}

/**
 * Get full order + items data for email body.
 *
 * @param  int        $catering_order_id
 * @return object|null {order, items}
 */
function caterme_get_order_for_email( $catering_order_id ) {
    global $wpdb;
    $order = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}caterme_orders WHERE id = %d", $catering_order_id
    ));
    if ( ! $order ) return null;
    $items = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}caterme_order_items WHERE order_id = %d ORDER BY id ASC", $catering_order_id
    ));
    return (object) array( 'order' => $order, 'items' => $items );
}

// ─────────────────────────────────────────────────────────────────────────────
// EMAIL SENDER
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Send a notification email to all configured recipients.
 *
 * @param string $event       'new' | 'paid' | 'confirmed'
 * @param object $order       Row from wp_caterme_orders
 * @param array  $items       Rows from wp_caterme_order_items
 */
function caterme_send_order_notification( $event, $order, $items ) {
    $recipients = caterme_get_notify_recipients();
    if ( empty($recipients) ) return;

    $s = caterme_get_settings();

    // Check the per-event toggle
    $toggle_map = array(
        'new'       => 'notify_on_new',
        'paid'      => 'notify_on_paid',
        'confirmed' => 'notify_on_confirmed',
    );
    $toggle = $toggle_map[ $event ] ?? null;
    if ( $toggle && ( $s[ $toggle ] ?? '0' ) !== '1' ) return;

    $event_labels = array(
        'new'       => '🆕 New Order Received',
        'paid'      => '💳 Payment Pre-Authorized',
        'confirmed' => '✅ Order Confirmed & Charged',
    );
    $event_colors = array(
        'new'       => '#2271b1',
        'paid'      => '#8c5e00',
        'confirmed' => '#00a32a',
    );

    $event_label = $event_labels[ $event ] ?? 'Order Update';
    $event_color = $event_colors[ $event ] ?? '#1a1208';

    $subject = caterme_notify_subject(
        $s['notify_subject'] ?? 'New Catering Order: {order_number}',
        $order->order_number,
        $event_label
    );

    $body = caterme_build_notification_email( $event, $event_label, $event_color, $order, $items, $s );

    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $s['store_name'] . ' <' . $s['store_email'] . '>',
    );

    // Send to each recipient separately so addresses aren't exposed to one another
    foreach ( $recipients as $to ) {
        wp_mail( $to, $subject, $body, $headers );
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// EMAIL TEMPLATE
// ─────────────────────────────────────────────────────────────────────────────

function caterme_build_notification_email( $event, $event_label, $event_color, $order, $items, $s ) {
    $store_name    = esc_html( $s['store_name']    ?? 'My Catering Co.' );
    $store_address = esc_html( $s['store_address'] ?? '' );
    $store_phone   = esc_html( $s['store_phone']   ?? '' );
    $store_email   = esc_html( $s['store_email']   ?? '' );
    $admin_url     = esc_url( admin_url('admin.php?page=caterme-orders&view=' . $order->id) );

    $fulfillment_label = $order->fulfillment === 'delivery' ? '🚗 Delivery' : '🏪 Pick Up';
    $dt = '';
    if ( $order->order_date ) {
        $dt .= date('l, F j, Y', strtotime($order->order_date));
    }
    if ( $order->order_time ) {
        $dt .= ' at ' . date('g:i a', strtotime($order->order_time));
    }

    // Payment badge text
    $payment_labels = array(
        'none'       => 'No Payment',
        'pending'    => 'Awaiting Payment',
        'authorized' => 'Pre-Authorized 🔒',
        'captured'   => 'Captured ✅',
        'refunded'   => 'Refunded',
        'voided'     => 'Voided',
        'failed'     => 'Failed',
    );
    $payment_label = $payment_labels[ $order->payment_status ?? 'none' ] ?? $order->payment_status;

    // Build items rows
    $items_html = '';
    foreach ( $items as $item ) {
        $sels_arr  = json_decode( $item->selections, true ) ?: array();
        $sels_text = $sels_arr ? esc_html( implode(' · ', $sels_arr) ) : '';
        $dietary   = $item->dietary ? '<div style="font-size:11px;color:#c8832a;margin-top:2px;">⚠️ ' . esc_html($item->dietary) . '</div>' : '';

        $items_html .= '
        <tr>
            <td style="padding:10px 14px;border-bottom:1px solid #f0e8d8;vertical-align:top;">
                <div style="font-weight:700;font-size:13px;color:#1a1208;">' . esc_html($item->item_name) . '</div>
                ' . ( $sels_text ? '<div style="font-size:11px;color:#888;margin-top:3px;line-height:1.5;">' . $sels_text . '</div>' : '' ) . '
                ' . $dietary . '
            </td>
            <td style="padding:10px 14px;border-bottom:1px solid #f0e8d8;text-align:center;font-size:13px;">' . (int)$item->qty . '</td>
            <td style="padding:10px 14px;border-bottom:1px solid #f0e8d8;text-align:right;font-size:13px;">$' . number_format($item->unit_price,2) . '</td>
            <td style="padding:10px 14px;border-bottom:1px solid #f0e8d8;text-align:right;font-size:13px;font-weight:700;">$' . number_format($item->line_total,2) . '</td>
        </tr>';
    }

    // Event-specific message
    $event_messages = array(
        'new'       => 'A new catering order has been submitted and is awaiting payment pre-authorization.',
        'paid'      => 'The customer\'s card has been successfully pre-authorized. The order is ready for your review. Confirm the order in the admin panel to capture payment.',
        'confirmed' => 'This order has been confirmed and the pre-authorized payment has been captured. The card has been charged.',
    );
    $event_message = $event_messages[ $event ] ?? 'A catering order has been updated.';

    // WC order link
    $wc_link = '';
    if ( $order->wc_order_id ) {
        $wc_link = '<p style="margin:14px 0 0;font-size:12px;color:#888;">WooCommerce Order: <a href="' . esc_url(admin_url('post.php?post=' . $order->wc_order_id . '&action=edit')) . '" style="color:#2271b1;">#' . $order->wc_order_id . '</a></p>';
    }

    ob_start();
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<title><?php echo esc_html($event_label); ?></title>
</head>
<body style="margin:0;padding:0;background:#f4f0eb;font-family:Georgia,serif;color:#1a1208;">

<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f0eb;padding:30px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

    <!-- Header -->
    <tr>
        <td style="background:#1a1208;border-radius:10px 10px 0 0;padding:22px 28px;">
            <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                    <td>
                        <div style="font-size:22px;font-weight:900;color:#f5e6c8;letter-spacing:3px;text-transform:uppercase;"><?php echo $store_name; ?></div>
                        <div style="font-size:11px;color:#b8996a;letter-spacing:2px;text-transform:uppercase;margin-top:2px;">Catering Notification</div>
                    </td>
                    <td align="right">
                        <span style="background:<?php echo $event_color; ?>;color:#fff;border-radius:6px;padding:6px 14px;font-size:12px;font-weight:700;font-family:Arial,sans-serif;white-space:nowrap;"><?php echo esc_html($event_label); ?></span>
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <!-- Event message -->
    <tr>
        <td style="background:#fff7ed;border-left:4px solid <?php echo $event_color; ?>;padding:16px 24px;">
            <p style="margin:0;font-size:13.5px;color:#444;line-height:1.7;"><?php echo esc_html($event_message); ?></p>
        </td>
    </tr>

    <!-- Order summary bar -->
    <tr>
        <td style="background:#fff;padding:20px 28px;border-top:1px solid #f0e8d8;">
            <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                    <td style="padding-right:20px;">
                        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#a07848;font-weight:700;margin-bottom:4px;">Order Number</div>
                        <div style="font-size:20px;font-weight:900;color:#1a1208;"><?php echo esc_html($order->order_number); ?></div>
                    </td>
                    <td style="padding-right:20px;">
                        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#a07848;font-weight:700;margin-bottom:4px;">Fulfillment</div>
                        <div style="font-size:14px;font-weight:700;color:#1a1208;"><?php echo $fulfillment_label; ?></div>
                        <?php if ($dt): ?><div style="font-size:12px;color:#888;margin-top:2px;"><?php echo esc_html($dt); ?></div><?php endif; ?>
                    </td>
                    <td style="padding-right:20px;">
                        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#a07848;font-weight:700;margin-bottom:4px;">Payment</div>
                        <div style="font-size:13px;font-weight:700;color:#1a1208;"><?php echo esc_html($payment_label); ?></div>
                    </td>
                    <td align="right">
                        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#a07848;font-weight:700;margin-bottom:4px;">Total</div>
                        <div style="font-size:22px;font-weight:900;color:#c8832a;">$<?php echo number_format($order->subtotal,2); ?>+</div>
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <!-- Customer info -->
    <?php if ($order->customer_name || $order->customer_email || $order->customer_phone): ?>
    <tr>
        <td style="background:#faf7f2;border-top:1px solid #f0e8d8;padding:14px 28px;">
            <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                    <td>
                        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#a07848;font-weight:700;margin-bottom:6px;">Customer</div>
                        <table cellpadding="0" cellspacing="0">
                            <?php if($order->customer_name): ?><tr><td style="font-size:13px;color:#1a1208;padding-right:20px;padding-bottom:2px;">👤 <?php echo esc_html($order->customer_name); ?></td></tr><?php endif; ?>
                            <?php if($order->customer_phone): ?><tr><td style="font-size:13px;color:#1a1208;padding-right:20px;padding-bottom:2px;">📞 <?php echo esc_html($order->customer_phone); ?></td></tr><?php endif; ?>
                            <?php if($order->customer_email): ?><tr><td style="font-size:13px;padding-bottom:2px;"><a href="mailto:<?php echo esc_attr($order->customer_email); ?>" style="color:#c8832a;">✉️ <?php echo esc_html($order->customer_email); ?></a></td></tr><?php endif; ?>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <?php endif; ?>

    <!-- Items table -->
    <tr>
        <td style="background:#fff;padding:0;">
            <table width="100%" cellpadding="0" cellspacing="0">
                <thead>
                    <tr style="background:#1a1208;">
                        <th style="padding:10px 14px;text-align:left;font-size:11px;color:#f5e6c8;text-transform:uppercase;letter-spacing:1px;font-family:Arial,sans-serif;width:50%;">Item</th>
                        <th style="padding:10px 14px;text-align:center;font-size:11px;color:#f5e6c8;text-transform:uppercase;letter-spacing:1px;font-family:Arial,sans-serif;">Qty</th>
                        <th style="padding:10px 14px;text-align:right;font-size:11px;color:#f5e6c8;text-transform:uppercase;letter-spacing:1px;font-family:Arial,sans-serif;">Unit</th>
                        <th style="padding:10px 14px;text-align:right;font-size:11px;color:#f5e6c8;text-transform:uppercase;letter-spacing:1px;font-family:Arial,sans-serif;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo $items_html; ?>
                </tbody>
                <tfoot>
                    <tr style="background:#faf7f2;">
                        <td colspan="3" style="padding:12px 14px;text-align:right;font-weight:700;font-size:14px;color:#1a1208;">Order Total</td>
                        <td style="padding:12px 14px;text-align:right;font-weight:900;font-size:16px;color:#c8832a;">$<?php echo number_format($order->subtotal,2); ?>+</td>
                    </tr>
                </tfoot>
            </table>
        </td>
    </tr>

    <!-- Notes -->
    <?php if ($order->notes): ?>
    <tr>
        <td style="background:#fffdf8;border-top:1px solid #f0e8d8;padding:14px 28px;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#a07848;font-weight:700;margin-bottom:6px;">Notes</div>
            <p style="margin:0;font-size:13px;color:#444;line-height:1.6;"><?php echo nl2br(esc_html($order->notes)); ?></p>
        </td>
    </tr>
    <?php endif; ?>

    <!-- Admin CTA -->
    <tr>
        <td style="background:#fff;border-top:1px solid #f0e8d8;padding:20px 28px;text-align:center;">
            <a href="<?php echo $admin_url; ?>" style="display:inline-block;background:#c8832a;color:#fff;text-decoration:none;font-weight:700;font-size:14px;padding:13px 30px;border-radius:8px;font-family:Arial,sans-serif;">View Order in Admin →</a>
            <?php echo $wc_link; ?>
        </td>
    </tr>

    <!-- Footer -->
    <tr>
        <td style="background:#1a1208;border-radius:0 0 10px 10px;padding:16px 28px;text-align:center;">
            <p style="margin:0;font-size:11px;color:#b8996a;line-height:1.8;">
                <?php echo $store_name; ?> · <?php echo $store_address; ?><br>
                <?php echo $store_phone; ?> · <?php echo $store_email; ?><br>
                <span style="color:#6a4e2a;font-size:10px;">This email was sent to notification recipients configured in the catering plugin settings.</span>
            </p>
        </td>
    </tr>

</table>
</td></tr>
</table>

</body>
</html>
    <?php
    return ob_get_clean();
}

// ─────────────────────────────────────────────────────────────────────────────
// HOOK: Fire notification after REST submission (new order)
// ─────────────────────────────────────────────────────────────────────────────

// Called from the REST handler after order + items are saved
function caterme_notify_new_order( $catering_order_id ) {
    $data = caterme_get_order_for_email( $catering_order_id );
    if ( ! $data ) return;
    caterme_send_order_notification( 'new', $data->order, $data->items );
}

// ─────────────────────────────────────────────────────────────────────────────
// HOOK: Fire notification when WC order moves to on-hold (payment authorized)
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'woocommerce_order_status_on-hold', function( $wc_order_id ) {
    global $wpdb;
    $catering_order = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}caterme_orders WHERE wc_order_id = %d", $wc_order_id
    ));
    if ( ! $catering_order ) return;

    $items = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}caterme_order_items WHERE order_id = %d ORDER BY id ASC", $catering_order->id
    ));

    // Update payment status
    $wpdb->update(
        $wpdb->prefix . 'caterme_orders',
        array( 'payment_status' => 'authorized' ),
        array( 'id' => $catering_order->id )
    );
    $catering_order->payment_status = 'authorized';

    caterme_send_order_notification( 'paid', $catering_order, $items );
}, 10, 1 );

// ─────────────────────────────────────────────────────────────────────────────
// HOOK: Fire notification when admin confirms (captured)
// ─────────────────────────────────────────────────────────────────────────────

// We tap into the payment_status update to send a 'confirmed' email.
// This fires from caterme_orders_page when status is changed to 'confirmed'.
function caterme_notify_order_confirmed( $catering_order_id ) {
    $data = caterme_get_order_for_email( $catering_order_id );
    if ( ! $data ) return;
    // Reflect current payment_status
    $data->order->payment_status = 'captured';
    caterme_send_order_notification( 'confirmed', $data->order, $data->items );
}

// ─────────────────────────────────────────────────────────────────────────────
// ALSO extend WC's own "new order" email to CC the notify list
// ─────────────────────────────────────────────────────────────────────────────

add_filter( 'woocommerce_email_recipient_new_order', function( $recipient, $order ) {
    if ( ! $order ) return $recipient;
    // Only extend for orders linked to a CaterMe catering order
    if ( ! $order->get_meta('_caterme_order_id') ) return $recipient;

    $extra = caterme_get_notify_recipients();
    if ( empty($extra) ) return $recipient;

    $all = array_filter( array_merge( array($recipient), $extra ) );
    return implode(',', array_unique($all));
}, 10, 2 );

// Also extend WC's "customer on-hold order" email recipient list
add_filter( 'woocommerce_email_recipient_customer_on_hold_order', function( $recipient, $order ) {
    // This one goes to the customer — don't add staff to customer emails.
    return $recipient;
}, 10, 2 );

// Extend WC's "processing order" email (fires on capture/confirmation)
add_filter( 'woocommerce_email_recipient_customer_processing_order', function( $recipient, $order ) {
    return $recipient; // customer only
}, 10, 2 );
