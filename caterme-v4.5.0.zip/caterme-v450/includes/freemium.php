<?php
/**
 * CaterMe — Freemium Plan Enforcement
 *
 * Manages plan tiers, monthly order limits, upgrade prompts,
 * and beta tester provisioning.
 *
 * Plans:
 *   free  — 5 orders/month, core features only
 *   beta  — 5 orders/month, all features, marked as beta tester
 *   pro   — unlimited orders, all features
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

define( 'CATERME_FREE_ORDER_LIMIT', 5 );
define( 'CATERME_TELEMETRY_VERSION', '1.0' );

// ─────────────────────────────────────────────────────────────────────────────
// PLAN HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Get the current plan: 'free' | 'beta' | 'pro'
 */
function caterme_get_plan() {
    $plan = get_option( 'caterme_plan', 'free' );
    return in_array( $plan, array( 'free', 'beta', 'pro' ) ) ? $plan : 'free';
}

/**
 * Set the plan for this installation.
 */
function caterme_set_plan( $plan ) {
    if ( ! in_array( $plan, array( 'free', 'beta', 'pro' ) ) ) return false;
    update_option( 'caterme_plan', $plan );
    caterme_track_event( 'plan_changed', array( 'new_plan' => $plan ) );
    return true;
}

/**
 * Activate a license key by validating with the external CaterMe License Server.
 * No validation logic lives in the plugin — the server decides everything.
 */
function caterme_activate_license( $key ) {
    $key = strtoupper( trim( $key ) );
    if ( empty( $key ) ) return array( 'success' => false, 'message' => 'No key provided.' );

    // Basic format sanity check before hitting the server
    if ( ! preg_match( '/^CM-(BETA|PRO)-[A-Z0-9]{8,12}$/', $key ) ) {
        return array( 'success' => false, 'message' => 'Invalid key format. Keys look like CM-BETA-XXXXXXXXXX.' );
    }

    if ( ! defined('CATERME_LICENSE_SERVER_URL') || ! CATERME_LICENSE_SERVER_URL ) {
        return array( 'success' => false, 'message' => 'License server not configured. Please contact support.' );
    }

    $response = wp_remote_post( CATERME_LICENSE_SERVER_URL, array(
        'headers' => array( 'Content-Type' => 'application/json' ),
        'body'    => wp_json_encode( array(
            'action'  => 'activate',
            'key'     => $key,
            'domain'  => parse_url( get_site_url(), PHP_URL_HOST ),
            'site_id' => caterme_get_site_id(),
        ) ),
        'timeout' => 15,
    ) );

    if ( is_wp_error( $response ) ) {
        return array( 'success' => false, 'message' => 'Could not reach license server. Check your connection and try again.' );
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( ! $body || ! isset( $body['success'] ) ) {
        return array( 'success' => false, 'message' => 'Unexpected response from license server.' );
    }

    if ( ! $body['success'] ) {
        return array( 'success' => false, 'message' => $body['message'] ?? 'License activation failed.' );
    }

    $plan = $body['plan'] ?? 'free';
    update_option( 'caterme_license_key', $key );
    caterme_set_plan( $plan );
    caterme_track_event( 'plan_changed', array( 'plan' => $plan, 'source' => 'license_key' ) );

    return array(
        'success' => true,
        'plan'    => $plan,
        'message' => $body['message'] ?? 'License activated.',
    );
}

/**
 * Deactivate the current license and release the key on the server
 * so it can be activated on a different site.
 */
function caterme_deactivate_license() {
    $key = get_option( 'caterme_license_key', '' );

    if ( $key && defined('CATERME_LICENSE_SERVER_URL') && CATERME_LICENSE_SERVER_URL ) {
        wp_remote_post( CATERME_LICENSE_SERVER_URL, array(
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body'    => wp_json_encode( array(
                'action' => 'deactivate',
                'key'    => $key,
                'domain' => parse_url( get_site_url(), PHP_URL_HOST ),
            ) ),
            'timeout'  => 10,
            'blocking' => false, // fire and forget
        ) );
    }

    delete_option( 'caterme_license_key' );
    caterme_set_plan( 'free' );
    caterme_track_event( 'plan_changed', array( 'plan' => 'free', 'source' => 'deactivation' ) );
}

// Key generation is handled exclusively by the external CaterMe License Server.

// ─────────────────────────────────────────────────────────────────────────────
// WEEKLY LICENSE REVALIDATION
// Silently re-checks the key against the server once a week.
// If the key is revoked or transferred, the site reverts to free.
// ─────────────────────────────────────────────────────────────────────────────

define( 'CATERME_REVALIDATE_HOOK', 'caterme_revalidate_license' );

add_action( 'plugins_loaded', function() {
    if ( ! wp_next_scheduled( CATERME_REVALIDATE_HOOK ) ) {
        wp_schedule_event( time(), 'weekly', CATERME_REVALIDATE_HOOK );
    }
} );

add_action( CATERME_REVALIDATE_HOOK, function() {
    $key  = get_option( 'caterme_license_key', '' );
    $plan = caterme_get_plan();

    if ( ! $key || $plan === 'free' ) return;
    if ( ! defined('CATERME_LICENSE_SERVER_URL') || ! CATERME_LICENSE_SERVER_URL ) return;

    $response = wp_remote_post( CATERME_LICENSE_SERVER_URL, array(
        'headers' => array( 'Content-Type' => 'application/json' ),
        'body'    => wp_json_encode( array(
            'action' => 'validate',
            'key'    => $key,
            'domain' => parse_url( get_site_url(), PHP_URL_HOST ),
        ) ),
        'timeout' => 15,
    ) );

    if ( is_wp_error( $response ) ) return; // Network failure — keep current plan, try again next week

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( ! $body ) return;

    if ( isset( $body['valid'] ) && ! $body['valid'] ) {
        // Key revoked or domain conflict — downgrade silently
        $reason = $body['reason'] ?? 'server_invalid';
        caterme_log_error( 'license_revalidation_failed', array(
            'key_prefix' => substr( $key, 0, 12 ),
            'reason'     => $reason,
        ) );
        caterme_deactivate_license();
    } elseif ( isset( $body['valid'] ) && $body['valid'] && isset( $body['plan'] ) ) {
        // Plan may have been upgraded on server side
        if ( $body['plan'] !== $plan ) {
            caterme_set_plan( $body['plan'] );
        }
    }
} );

// Also hook deactivate_plugin to release the key from the server
register_deactivation_hook( CATERME_PLUGIN_FILE, function() {
    caterme_deactivate_license();
} );

// ─────────────────────────────────────────────────────────────────────────────
// ORDER COUNTING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Get the option key for this month's order count.
 */
function caterme_monthly_count_key() {
    return 'caterme_orders_' . date( 'Ym' ); // e.g. caterme_orders_202602
}

/**
 * Get current month's order count.
 */
function caterme_get_monthly_order_count() {
    return (int) get_option( caterme_monthly_count_key(), 0 );
}

/**
 * Increment this month's order count by 1.
 */
function caterme_increment_order_count() {
    $key   = caterme_monthly_count_key();
    $count = (int) get_option( $key, 0 ) + 1;
    update_option( $key, $count, false ); // false = don't autoload
    return $count;
}

/**
 * Check if the site is allowed to accept a new order.
 * Returns true if allowed, false if limit exceeded.
 */
function caterme_order_allowed() {
    $plan = caterme_get_plan();

    // Pro and beta have no order limit
    if ( $plan === 'pro' || $plan === 'beta' ) return true;

    // Free is capped at CATERME_FREE_ORDER_LIMIT
    $count = caterme_get_monthly_order_count();
    return $count < CATERME_FREE_ORDER_LIMIT;
}

/**
 * How many orders remain this month (null = unlimited).
 */
function caterme_orders_remaining() {
    $plan = caterme_get_plan();
    if ( $plan === 'pro' || $plan === 'beta' ) return null; // unlimited
    $remaining = CATERME_FREE_ORDER_LIMIT - caterme_get_monthly_order_count();
    return max( 0, $remaining );
}

// ─────────────────────────────────────────────────────────────────────────────
// FEATURE FLAGS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Feature map: which plans get which features.
 * free  = basic order intake + labels only
 * beta  = everything (same as pro but flagged as beta tester)
 * pro   = everything
 */
function caterme_features() {
    return array(
        // ── Always free ─────────────────────────────────────────────────────────
        'order_intake'        => array( 'free', 'beta', 'pro' ),  // Customer order intake is ALWAYS unlimited
        'invoice_printing'    => array( 'free', 'beta', 'pro' ),  // Invoices are free for all
        // ── Beta + Pro ──────────────────────────────────────────────────────────
        'label_printing'      => array( 'beta', 'pro' ),
        'kitchen_tickets'     => array( 'beta', 'pro' ),
        'manual_order_create' => array( 'beta', 'pro' ),          // Admin creates order manually
        'quote_email'         => array( 'beta', 'pro' ),          // Send quote to customer
        'payment_link'        => array( 'beta', 'pro' ),          // Send WooCommerce pay link
        'ezcater_import'      => array( 'beta', 'pro' ),
        'google_sheets'       => array( 'beta', 'pro' ),
        'email_notifications' => array( 'beta', 'pro' ),
        'delivery_tiers'      => array( 'beta', 'pro' ),
        'multi_recipients'    => array( 'beta', 'pro' ),
        'custom_branding'     => array( 'beta', 'pro' ),
        'woocommerce_payments' => array( 'beta', 'pro' ),
        // ── Pro only ────────────────────────────────────────────────────────────
        'menu_photos'         => array( 'pro' ),
    );
}

/**
 * Check if the current plan has access to a feature.
 */
function caterme_has_feature( $feature ) {
    $plan     = caterme_get_plan();
    $features = caterme_features();
    if ( ! isset( $features[ $feature ] ) ) return false;
    return in_array( $plan, $features[ $feature ] );
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN: USAGE BANNER
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'admin_notices', function() {
    // Only show on CaterMe pages
    $page = $_GET['page'] ?? '';
    if ( strpos( $page, 'caterme' ) === false ) return;

    $plan = caterme_get_plan();
    if ( $plan !== 'free' ) return; // Only show for free plan

    $upgrade_url = admin_url( 'admin.php?page=caterme-settings&tab=plan' );
    ?>
    <div style="background:#fffbeb;border:1.5px solid #fcd34d;border-radius:8px;padding:12px 18px;margin:10px 0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
        <div style="display:flex;align-items:center;gap:12px;">
            <span style="font-size:20px;">🔒</span>
            <div>
                <strong style="color:#78350f;font-size:14px;">🆓 Free Plan</strong>
                <div style="font-size:13px;color:#92400e;margin-top:3px;">
                    Label printing, invoices, kitchen tickets &amp; more require Beta or Pro.
                    Order intake is always unlimited.
                </div>
            </div>
        </div>
        <a href="<?php echo $upgrade_url; ?>" style="background:#c8522a;color:#fff;text-decoration:none;padding:8px 18px;border-radius:6px;font-size:13px;font-weight:700;white-space:nowrap;">
            ⬆️ Upgrade Plan →
        </a>
    </div>
    <?php
} );

// ─────────────────────────────────────────────────────────────────────────────
// BETA KEY GENERATOR PAGE (hidden, admin only)

// ─────────────────────────────────────────────────────────────────────────────
// PLAN TAB IN SETTINGS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Render the Plan tab content (called from settings page).
 */
function caterme_render_plan_tab() {
    $plan      = caterme_get_plan();
    $key       = get_option( 'caterme_license_key', '' );
    $count     = caterme_get_monthly_order_count();
    $remaining = caterme_orders_remaining();
    $site_id   = caterme_get_site_id();

    // Handle key activation
    $notice = '';
    if ( isset( $_POST['caterme_activate_license'], $_POST['_caterme_plan_nonce'] )
        && wp_verify_nonce( $_POST['_caterme_plan_nonce'], 'caterme_plan_action' ) ) {
        $result = caterme_activate_license( sanitize_text_field( $_POST['license_key'] ?? '' ) );
        $notice = $result['success']
            ? '<div class="notice notice-success is-dismissible"><p>' . esc_html($result['message']) . '</p></div>'
            : '<div class="notice notice-error is-dismissible"><p>⚠️ ' . esc_html($result['message']) . '</p></div>';
        // Re-read after activation
        $plan = caterme_get_plan();
        $key  = get_option( 'caterme_license_key', '' );
    }

    if ( isset( $_POST['caterme_deactivate_license'], $_POST['_caterme_plan_nonce'] )
        && wp_verify_nonce( $_POST['_caterme_plan_nonce'], 'caterme_plan_action' ) ) {
        caterme_deactivate_license();
        $plan = 'free'; $key = '';
        $notice = '<div class="notice notice-info is-dismissible"><p>License deactivated. Plan set to Free.</p></div>';
    }

    echo $notice;

    $plan_colors = array(
        'free' => array( 'bg' => '#f9fafb', 'border' => '#d1d5db', 'badge' => '#6b7280' ),
        'beta' => array( 'bg' => '#eff6ff', 'border' => '#93c5fd', 'badge' => '#2563eb' ),
        'pro'  => array( 'bg' => '#fdf4ff', 'border' => '#d8b4fe', 'badge' => '#7c3aed' ),
    );
    $pc = $plan_colors[ $plan ];
    ?>
    <div style="max-width:680px;">

        <!-- Current Plan Card -->
        <div style="background:<?php echo $pc['bg']; ?>;border:2px solid <?php echo $pc['border']; ?>;border-radius:12px;padding:24px 28px;margin-bottom:24px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;">
                <div>
                    <span style="background:<?php echo $pc['badge']; ?>;color:#fff;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;letter-spacing:1px;text-transform:uppercase;">
                        <?php echo $plan === 'free' ? '🆓 FREE' : ($plan === 'beta' ? '🧪 BETA' : '🚀 PRO'); ?>
                    </span>
                    <h2 style="margin:10px 0 4px;font-size:22px;color:#1a1208;">
                        <?php echo $plan === 'free' ? 'Free Plan' : ($plan === 'beta' ? 'Beta Plan' : 'Pro Plan'); ?>
                    </h2>
                    <?php if ( $plan === 'free' ): ?>
                    <p style="margin:0;font-size:14px;color:#555;">
                        Unlimited order intake &nbsp;·&nbsp; Order management only
                    </p>
                    <?php elseif ( $plan === 'beta' ): ?>
                    <p style="margin:0;font-size:14px;color:#555;">
                        Unlimited orders &nbsp;·&nbsp; All features unlocked 🧪
                    </p>
                    <?php else: ?>
                    <p style="margin:0;font-size:14px;color:#555;">Unlimited orders &nbsp;·&nbsp; All features</p>
                    <?php endif; ?>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:28px;font-weight:900;color:#1a1208;"><?php echo $count; ?><span style="font-size:16px;color:#888;">/<?php echo $plan === 'pro' ? '∞' : CATERME_FREE_ORDER_LIMIT; ?></span></div>
                    <div style="font-size:12px;color:#888;margin-top:2px;">orders in <?php echo date('F'); ?></div>
                </div>
            </div>
            <?php if ( $plan === 'free' ): ?>
            <div style="margin-top:16px;background:#e5e7eb;border-radius:999px;height:8px;overflow:hidden;">
                <?php $pct = CATERME_FREE_ORDER_LIMIT > 0 ? round(($count / CATERME_FREE_ORDER_LIMIT) * 100) : 0; ?>
                <div style="background:<?php echo $remaining === 0 ? '#dc2626' : ($remaining === 1 ? '#d97706' : $pc['badge']); ?>;height:100%;width:<?php echo $pct; ?>%;border-radius:999px;"></div>
            </div>
            <p style="margin:8px 0 0;font-size:12px;color:#888;"><?php echo $remaining === 0 ? '⛔ Limit reached for this month. Resets ' . date('M 1', strtotime('+1 month')) . '.' : $remaining . ' orders remaining this month.'; ?></p>
            <?php endif; ?>
            <?php if ( $key ): ?>
            <div style="margin-top:12px;font-size:12px;color:#888;">Key: <code><?php echo esc_html( substr($key, 0, 7) . str_repeat('•', strlen($key) - 7) ); ?></code></div>
            <?php endif; ?>
        </div>

        <!-- Activate Key -->
        <?php if ( $plan !== 'pro' ): ?>
        <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;padding:22px 26px;margin-bottom:20px;">
            <h3 style="margin-top:0;font-size:16px;">🔑 Enter License Key</h3>
            <p style="font-size:13px;color:#666;margin-bottom:16px;">Have a beta key or pro license? Enter it below to unlock your plan.</p>
            <form method="post">
                <?php wp_nonce_field('caterme_plan_action', '_caterme_plan_nonce'); ?>
                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <input type="text" name="license_key" value="<?php echo esc_attr($key); ?>"
                        placeholder="CM-BETA-XXXXXXXX or CM-PRO-XXXXXXXX"
                        style="flex:1;min-width:260px;border:1.5px solid #ddd;border-radius:6px;padding:9px 12px;font-size:14px;font-family:monospace;letter-spacing:1px;" />
                    <button type="submit" name="caterme_activate_license" class="button button-primary">Activate</button>
                    <?php if ( $key ): ?>
                    <button type="submit" name="caterme_deactivate_license" class="button" style="color:#dc2626;border-color:#dc2626;">Remove</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- Feature Comparison Table -->
        <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
            <div style="background:#1a1208;color:#f5e6c8;padding:12px 18px;font-weight:700;">Feature Comparison</div>
            <table style="width:100%;border-collapse:collapse;font-size:13px;">
                <thead>
                    <tr style="background:#faf7f2;">
                        <th style="padding:10px 16px;text-align:left;">Feature</th>
                        <th style="padding:10px 14px;text-align:center;width:80px;">Free</th>
                        <th style="padding:10px 14px;text-align:center;width:80px;">Beta</th>
                        <th style="padding:10px 14px;text-align:center;width:80px;">Pro</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $rows = array(
                    'Order intake (always unlimited)' => array( 'free', 'beta', 'pro' ),
                    'Invoice printing'               => array( 'free', 'beta', 'pro' ),
                    'Label printing (Avery 5163)'    => array( false, 'beta', 'pro' ),
                    'Kitchen tickets & prep sheets'  => array( false, 'beta', 'pro' ),
                    'Manual order creation'          => array( false, 'beta', 'pro' ),
                    'Quote & payment link emails'    => array( false, 'beta', 'pro' ),
                    'Menu item photos'               => array( false, false,  'pro' ),

                    'ezCater import'             => array( false, 'beta', 'pro' ),
                    'Google Sheets sync'         => array( false, 'beta', 'pro' ),
                    'Email notifications'        => array( false, 'beta', 'pro' ),
                    'WooCommerce payments'       => array( false, 'beta', 'pro' ),
                    'Delivery fee tiers'         => array( false, 'beta', 'pro' ),
                    'Custom branding'            => array( false, 'beta', 'pro' ),
                    'Priority support'           => array( false, false, 'pro' ),
                );
                foreach ( $rows as $feature => $access ):
                    $cells = array();
                    foreach ( $access as $val ) {
                        if ( $val === false ) { $cells[] = '<span style="color:#ddd;">✕</span>'; }
                        elseif ( $val === true || in_array($val, array('free','beta','pro')) ) { $cells[] = '<span style="color:#16a34a;">✓</span>'; }
                        else { $cells[] = '<span style="color:#666;font-size:12px;">'.$val.'</span>'; }
                    }
                ?>
                <tr style="border-top:1px solid #f0e8d8;">
                    <td style="padding:9px 16px;color:#1a1208;"><?php echo $feature; ?></td>
                    <?php foreach ($cells as $cell): ?><td style="padding:9px 14px;text-align:center;"><?php echo $cell; ?></td><?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Site ID (for support) -->
        <p style="margin-top:16px;font-size:12px;color:#aaa;">Site ID: <code style="font-size:11px;"><?php echo esc_html($site_id); ?></code> — include this if contacting support.</p>
    </div>
    <?php
}
