<?php
/**
 * CaterMe — Modifier Templates
 * Allows admins to define reusable modifier groups (proteins, sides, bread types, etc.)
 * that can be instantly applied to any menu item from the Menu Manager.
 *
 * Storage: wp_options key `caterme_modifier_templates` — JSON array of modifier objects.
 * Each modifier shares the same shape as item-level modifiers:
 *   { key, label, type, required, choices[], max_selections, price, min, default }
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Default / seed templates ─────────────────────────────────────────────────

define( 'CATERME_MOD_TEMPLATES_SEED_VERSION', '1' );

/**
 * The built-in default modifier templates shipped with CaterMe.
 * These are seeded once on first activation or when the seed version changes.
 * Admins can edit/delete/add from the Modifier Templates page.
 */
function caterme_default_modifier_templates() {
    return array(
        array(
            'key'            => 'dietary_restrictions',
            'label'          => 'Dietary Restrictions & Allergies',
            'type'           => 'select',
            'required'       => false,
            'max_selections' => 12,
            'price'          => 0,
            'min'            => 1,
            'default'        => 1,
            'choices'        => array(
                '🌾 Gluten-Free',
                '🥛 Dairy-Free',
                '🥜 Nut Allergy',
                '🥦 Vegetarian',
                '🌱 Vegan',
                '🧅 No Onion',
                '🍅 No Tomato',
                '🍞 No Croutons',
                '🧀 No Cheese',
                '🧂 Low Sodium',
                '☪️ Halal',
                '✡️ Kosher',
            ),
        ),
    );
}

function caterme_get_modifier_templates() {
    // Seed defaults on first install or seed version bump
    if ( get_option('caterme_mod_templates_seed') !== CATERME_MOD_TEMPLATES_SEED_VERSION ) {
        $defaults = caterme_default_modifier_templates();
        caterme_save_modifier_templates( $defaults );
        update_option( 'caterme_mod_templates_seed', CATERME_MOD_TEMPLATES_SEED_VERSION );
        return $defaults;
    }
    $raw = get_option( 'caterme_modifier_templates', '' );
    if ( ! $raw ) return array();
    $data = json_decode( $raw, true );
    return is_array($data) ? $data : array();
}

function caterme_save_modifier_templates( array $templates ) {
    return update_option( 'caterme_modifier_templates', wp_json_encode( $templates ), false );
}

// ─── REST API ─────────────────────────────────────────────────────────────────

add_action( 'rest_api_init', 'caterme_register_modifier_templates_api' );

function caterme_register_modifier_templates_api() {
    register_rest_route( 'caterme/v1', '/modifier-templates', array(
        array(
            'methods'             => 'GET',
            'callback'            => function() {
                return new WP_REST_Response( caterme_get_modifier_templates(), 200 );
            },
            'permission_callback' => function() { return current_user_can('manage_options'); },
        ),
        array(
            'methods'             => 'POST',
            'callback'            => 'caterme_handle_save_modifier_templates',
            'permission_callback' => function() { return current_user_can('manage_options'); },
        ),
    ));
}

function caterme_handle_save_modifier_templates( WP_REST_Request $request ) {
    $body = $request->get_json_params();

    if ( ! is_array($body) ) {
        return new WP_REST_Response( array('success'=>false,'message'=>'Invalid payload.'), 400 );
    }

    $clean = array();
    foreach ( $body as $t ) {
        if ( empty($t['key']) || empty($t['label']) ) continue;
        $entry = array(
            'key'            => sanitize_key( $t['key'] ),
            'label'          => sanitize_text_field( $t['label'] ),
            'type'           => in_array($t['type']??'select', array('select','toggle','number')) ? $t['type'] : 'select',
            'required'       => (bool)($t['required'] ?? false),
            'max_selections' => max(0, (int)($t['max_selections'] ?? 1)),
            'price'          => (float)($t['price'] ?? 0),
            'min'            => max(1, (int)($t['min'] ?? 1)),
            'default'        => max(1, (int)($t['default'] ?? 1)),
            'choices'        => array(),
        );
        if ( isset($t['choices']) && is_array($t['choices']) ) {
            $entry['choices'] = array_values( array_filter( array_map('sanitize_text_field', $t['choices']) ) );
        }
        $clean[] = $entry;
    }

    caterme_save_modifier_templates( $clean );
    return new WP_REST_Response( array('success'=>true,'count'=>count($clean)), 200 );
}

// ─── Admin page ───────────────────────────────────────────────────────────────

function caterme_modifiers_page() {
    $templates  = caterme_get_modifier_templates();
    $api_url    = rest_url('caterme/v1/modifier-templates');
    $nonce      = wp_create_nonce('wp_rest');
    $menu_url   = admin_url('admin.php?page=caterme-menu-manager');
    ?>
    <div class="wrap" id="caterme-modifiers-wrap">

        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:4px;">
            <h1 style="display:flex;align-items:center;gap:12px;margin:0;">
                🔧 Modifier Templates
                <span id="cmt-status" style="font-size:13px;font-weight:400;color:#666;"></span>
            </h1>
            <a href="<?php echo esc_url($menu_url); ?>" class="button">← Back to Menu Manager</a>
        </div>
        <p style="color:#666;margin:6px 0 22px;">Define reusable modifiers — proteins, sides, bread types, add-ons, etc. — that can be applied to any menu item with one click from the Menu Manager.</p>

        <div style="display:flex;gap:10px;align-items:center;margin-bottom:18px;flex-wrap:wrap;">
            <button id="cmt-add" class="button button-secondary" style="font-size:14px;padding:6px 16px;">+ New Template</button>
            <button id="cmt-save" class="button button-primary" style="font-size:14px;padding:6px 18px;">💾 Save Templates</button>
        </div>

        <div id="cmt-app">
            <p style="color:#888;font-size:13px;font-style:italic;">Loading…</p>
        </div>

    </div>

    <!-- ── Template Edit Modal ── -->
    <div id="cmt-edit-modal" class="cmt-modal-wrap" style="display:none;">
        <div class="cmt-modal">
            <h2 id="cmt-modal-title">New Template</h2>
            <input type="hidden" id="cmt-edit-idx" value="-1" />

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="cmt-field" style="grid-column:1/-1;">
                    <label>Label * <span style="font-weight:400;color:#888;">(shown to customers)</span></label>
                    <input type="text" id="cmt-label" placeholder="e.g. Protein / Filling, Bread Type, Side" class="large-text" />
                </div>
                <div class="cmt-field">
                    <label>Key * <span style="font-weight:400;color:#888;">(unique ID, auto-filled)</span></label>
                    <input type="text" id="cmt-key" placeholder="protein_filling" style="width:100%;" />
                </div>
                <div class="cmt-field">
                    <label>Type *</label>
                    <select id="cmt-type" onchange="cmtTypeChange(this.value)" style="width:100%;">
                        <option value="select">Select — pick from a list</option>
                        <option value="toggle">Toggle — yes/no add-on</option>
                        <option value="number">Number — quantity entry</option>
                    </select>
                </div>
                <div id="cmt-required-wrap" class="cmt-field">
                    <label><input type="checkbox" id="cmt-required" /> Required</label>
                </div>
            </div>

            <!-- Select-specific fields -->
            <div id="cmt-choices-wrap" class="cmt-field" style="margin-top:8px;">
                <label>Choices <span style="font-weight:400;color:#888;">(one per line)</span></label>
                <textarea id="cmt-choices" rows="6" class="large-text" placeholder="Ham&#10;Chicken&#10;Turkey&#10;Roast Beef&#10;Corned Beef"></textarea>
            </div>
            <div id="cmt-maxsel-wrap" class="cmt-field">
                <label>Max Selections <span style="font-weight:400;color:#888;">0 or 1 = single choice. 2+ = multi-select up to N.</span></label>
                <input type="number" id="cmt-maxsel" value="1" min="0" max="20" style="width:80px;" />
            </div>

            <!-- Toggle-specific -->
            <div id="cmt-price-wrap" class="cmt-field" style="display:none;">
                <label>Price Add-on ($) <span style="font-weight:400;color:#888;">(0 if free)</span></label>
                <input type="number" id="cmt-price" value="0" min="0" step="0.01" style="width:120px;" />
            </div>

            <!-- Number-specific -->
            <div id="cmt-number-wrap" style="display:none;">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div class="cmt-field">
                        <label>Minimum</label>
                        <input type="number" id="cmt-min" value="1" min="1" style="width:80px;" />
                    </div>
                    <div class="cmt-field">
                        <label>Default</label>
                        <input type="number" id="cmt-default" value="1" min="1" style="width:80px;" />
                    </div>
                </div>
            </div>

            <div class="cmt-modal-footer">
                <button class="button button-primary" onclick="cmtSave()">Save Template</button>
                <button class="button" onclick="cmtCloseModal()">Cancel</button>
            </div>
        </div>
    </div>

<style>
/* ── Layout ── */
.cmt-modal-wrap { position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px; }
.cmt-modal { background:#fff;border-radius:10px;padding:28px 32px;width:100%;max-width:540px;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.3); }
.cmt-modal h2 { margin:0 0 20px;font-size:18px;color:#1a1208; }
.cmt-field { margin-bottom:14px; }
.cmt-field label { display:block;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#5a3e20;margin-bottom:5px; }
.cmt-field input[type=text], .cmt-field input[type=number], .cmt-field select, .cmt-field textarea { border:1px solid #ddd;border-radius:6px;padding:7px 10px;font-size:13px; }
.cmt-modal-footer { border-top:1px solid #f0e8d8;padding-top:16px;margin-top:20px;display:flex;gap:10px;align-items:center; }
/* ── Template cards ── */
#cmt-app { display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px; }
.cmt-card { background:#fff;border:1.5px solid #e0d0b8;border-radius:10px;padding:16px 18px;display:flex;flex-direction:column;gap:6px; }
.cmt-card-head { display:flex;align-items:flex-start;gap:10px; }
.cmt-card-label { font-size:14px;font-weight:800;color:#1a1208;flex:1; }
.cmt-card-type { font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;background:#e0f2fe;color:#0369a1;white-space:nowrap; }
.cmt-card-preview { font-size:12px;color:#7a6040;line-height:1.5;flex:1; }
.cmt-card-actions { display:flex;gap:6px;margin-top:4px; }
.cmt-card-actions button { font-size:12px;padding:4px 10px;min-height:0; }
.cmt-empty { grid-column:1/-1;text-align:center;padding:48px 24px;color:#a07848; }
.cmt-empty .cmt-empty-icon { font-size:42px;margin-bottom:10px; }
.cmt-empty p { font-size:14px;margin:0 0 16px; }
</style>

<script>
(function(){
    const API_URL   = '<?php echo esc_js($api_url); ?>';
    const API_NONCE = '<?php echo esc_js($nonce); ?>';
    let templates   = <?php echo wp_json_encode($templates); ?>;
    let dirty       = false;

    function esc(s) {
        return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
    function slug(s) {
        return s.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');
    }

    // ── Render ─────────────────────────────────────────────────────────────────
    function render() {
        const app = document.getElementById('cmt-app');
        if (!templates.length) {
            app.innerHTML = `<div class="cmt-empty">
                <div class="cmt-empty-icon">🔧</div>
                <p>No modifier templates yet.</p>
                <button class="button button-primary" onclick="cmtOpenNew()">+ Create Your First Template</button>
            </div>`;
            return;
        }
        app.innerHTML = templates.map((t, i) => {
            const typeLabel = t.type === 'select' ? '🔘 Select' : t.type === 'toggle' ? '☑️ Toggle' : '🔢 Number';
            let preview = '';
            if (t.type === 'select')  preview = (t.choices||[]).join(', ') || '(no choices)';
            if (t.type === 'toggle')  preview = t.price > 0 ? `+$${parseFloat(t.price).toFixed(2)} add-on` : 'Free add-on';
            if (t.type === 'number')  preview = `Min: ${t.min||1} · Default: ${t.default||1}`;
            if (t.type === 'select' && (t.max_selections||1) > 1) preview += ` · Multi-select up to ${t.max_selections}`;
            if (t.required) preview += ' · Required';
            return `<div class="cmt-card">
                <div class="cmt-card-head">
                    <span class="cmt-card-label">${esc(t.label)}</span>
                    <span class="cmt-card-type">${typeLabel}</span>
                </div>
                <div class="cmt-card-preview" title="${esc(preview)}">${esc(preview)}</div>
                <div class="cmt-card-key" style="font-size:11px;color:#b8996a;font-family:monospace;">key: ${esc(t.key)}</div>
                <div class="cmt-card-actions">
                    <button class="button" onclick="cmtEdit(${i})">✏️ Edit</button>
                    <button class="button" onclick="cmtDelete(${i})" style="color:#c33;border-color:#c33;">🗑️ Delete</button>
                    ${i > 0                    ? `<button class="button" onclick="cmtMove(${i},-1)" title="Move up"  style="padding:4px 8px;">↑</button>` : '<button class="button" disabled style="padding:4px 8px;">↑</button>'}
                    ${i < templates.length - 1 ? `<button class="button" onclick="cmtMove(${i},1)"  title="Move down" style="padding:4px 8px;">↓</button>` : '<button class="button" disabled style="padding:4px 8px;">↓</button>'}
                </div>
            </div>`;
        }).join('');
    }

    // ── Modal ──────────────────────────────────────────────────────────────────
    function cmtTypeChange(type) {
        document.getElementById('cmt-choices-wrap').style.display  = type === 'select' ? '' : 'none';
        document.getElementById('cmt-maxsel-wrap').style.display   = type === 'select' ? '' : 'none';
        document.getElementById('cmt-required-wrap').style.display = type !== 'number' ? '' : 'none';
        document.getElementById('cmt-price-wrap').style.display    = type === 'toggle' ? '' : 'none';
        document.getElementById('cmt-number-wrap').style.display   = type === 'number' ? '' : 'none';
    }
    window.cmtTypeChange = cmtTypeChange;

    function cmtOpenNew() {
        document.getElementById('cmt-modal-title').textContent = 'New Template';
        document.getElementById('cmt-edit-idx').value = -1;
        document.getElementById('cmt-label').value   = '';
        document.getElementById('cmt-key').value     = '';
        document.getElementById('cmt-type').value    = 'select';
        document.getElementById('cmt-required').checked = false;
        document.getElementById('cmt-choices').value = '';
        document.getElementById('cmt-maxsel').value  = 1;
        document.getElementById('cmt-price').value   = 0;
        document.getElementById('cmt-min').value     = 1;
        document.getElementById('cmt-default').value = 1;
        cmtTypeChange('select');
        document.getElementById('cmt-edit-modal').style.display = 'flex';
        setTimeout(() => document.getElementById('cmt-label').focus(), 50);
    }
    window.cmtOpenNew = cmtOpenNew;
    document.getElementById('cmt-add').addEventListener('click', cmtOpenNew);

    function cmtEdit(i) {
        const t = templates[i];
        document.getElementById('cmt-modal-title').textContent = 'Edit Template';
        document.getElementById('cmt-edit-idx').value = i;
        document.getElementById('cmt-label').value    = t.label || '';
        document.getElementById('cmt-key').value      = t.key   || '';
        document.getElementById('cmt-type').value     = t.type  || 'select';
        document.getElementById('cmt-required').checked = t.required || false;
        document.getElementById('cmt-choices').value  = (t.choices||[]).join('\n');
        document.getElementById('cmt-maxsel').value   = t.max_selections || 1;
        document.getElementById('cmt-price').value    = t.price   || 0;
        document.getElementById('cmt-min').value      = t.min     || 1;
        document.getElementById('cmt-default').value  = t.default || 1;
        cmtTypeChange(t.type || 'select');
        document.getElementById('cmt-edit-modal').style.display = 'flex';
    }
    window.cmtEdit = cmtEdit;

    function cmtSave() {
        const idx   = parseInt(document.getElementById('cmt-edit-idx').value);
        const label = document.getElementById('cmt-label').value.trim();
        const rawKey = document.getElementById('cmt-key').value.trim();
        if (!label) { alert('Label is required.'); return; }
        const key = rawKey || slug(label);
        const type = document.getElementById('cmt-type').value;
        // Check key uniqueness (excluding current item)
        const duplicate = templates.some((t, i) => t.key === key && i !== idx);
        if (duplicate) { alert(`Key "${key}" is already used by another template. Please use a different label or edit the key manually.`); return; }
        const entry = {
            key,
            label,
            type,
            required:       document.getElementById('cmt-required').checked,
            choices:        type === 'select' ? document.getElementById('cmt-choices').value.split('\n').map(s=>s.trim()).filter(Boolean) : [],
            max_selections: type === 'select' ? (parseInt(document.getElementById('cmt-maxsel').value)||1) : 1,
            price:          type === 'toggle' ? parseFloat(document.getElementById('cmt-price').value)||0 : 0,
            min:            type === 'number' ? parseInt(document.getElementById('cmt-min').value)||1 : 1,
            default:        type === 'number' ? parseInt(document.getElementById('cmt-default').value)||1 : 1,
        };
        if (idx === -1) templates.push(entry);
        else templates[idx] = entry;
        dirty = true;
        cmtCloseModal();
        render();
    }
    window.cmtSave = cmtSave;

    function cmtDelete(i) {
        if (!confirm(`Delete template "${templates[i].label}"?`)) return;
        templates.splice(i, 1);
        dirty = true;
        render();
    }
    window.cmtDelete = cmtDelete;

    function cmtMove(i, dir) {
        const ni = i + dir;
        if (ni < 0 || ni >= templates.length) return;
        [templates[i], templates[ni]] = [templates[ni], templates[i]];
        dirty = true;
        render();
    }
    window.cmtMove = cmtMove;

    function cmtCloseModal() {
        document.getElementById('cmt-edit-modal').style.display = 'none';
    }
    window.cmtCloseModal = cmtCloseModal;

    document.getElementById('cmt-edit-modal').addEventListener('click', function(e) {
        if (e.target === this) cmtCloseModal();
    });

    // Auto-generate key from label
    document.getElementById('cmt-label').addEventListener('input', function() {
        const keyEl = document.getElementById('cmt-key');
        const idx   = parseInt(document.getElementById('cmt-edit-idx').value);
        // Only auto-fill on new templates OR if key matches auto-generated
        if (idx === -1 || keyEl.value === slug(keyEl.dataset.prev||'')) {
            keyEl.value = slug(this.value);
        }
        keyEl.dataset.prev = this.value;
    });

    // ── Save ───────────────────────────────────────────────────────────────────
    document.getElementById('cmt-save').addEventListener('click', function() {
        const btn    = this;
        const status = document.getElementById('cmt-status');
        btn.disabled = true;
        btn.textContent = 'Saving…';

        fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': API_NONCE },
            body: JSON.stringify(templates),
        })
        .then(r => r.json())
        .then(json => {
            btn.disabled = false;
            btn.textContent = '💾 Save Templates';
            if (json.success) {
                dirty = false;
                status.textContent = '✓ Saved ' + json.count + ' template' + (json.count !== 1 ? 's' : '');
                status.style.color = '#16a34a';
                setTimeout(() => { status.textContent = ''; }, 3000);
            } else {
                status.textContent = '✗ Save failed';
                status.style.color = '#c33';
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.textContent = '💾 Save Templates';
            status.textContent = '✗ Network error';
            status.style.color = '#c33';
        });
    });

    window.addEventListener('beforeunload', function(e) {
        if (dirty) { e.preventDefault(); e.returnValue = ''; }
    });

    render();
})();
</script>
    <?php
}
