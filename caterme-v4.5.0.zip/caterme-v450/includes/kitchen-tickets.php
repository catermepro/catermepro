<?php
/**
 * Kitchen Ticket Printing
 * Professional kitchen prep sheets and individual item tickets
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Add Kitchen Tickets submenu
 */
add_action( 'admin_menu', function() {
    add_submenu_page( '', 'Kitchen Tickets', 'Kitchen Tickets', 'manage_options', 'caterme-kitchen-tickets', '__return_false' );
}, 100 );

/**
 * Intercept kitchen ticket print requests
 */
add_action( 'admin_init', function() {
    if ( ( $_GET['page'] ?? '' ) !== 'caterme-kitchen-tickets' ) return;

    // ── Feature gate: kitchen tickets require beta or pro ─────────────────────
    if ( ! caterme_has_feature( 'kitchen_tickets' ) ) {
        ?><!DOCTYPE html><html><head><title>Feature Locked</title>
        <style>body{font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f9f7f4;}
        .box{max-width:480px;text-align:center;padding:40px;background:#fff;border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,.08);}
        h2{color:#1a1208;margin-bottom:8px;}p{color:#555;line-height:1.5;}
        a{display:inline-block;margin-top:20px;background:#c8522a;color:#fff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;}</style>
        </head><body><div class="box">
        <div style="font-size:48px;margin-bottom:16px;">🔒</div>
        <h2>Kitchen Tickets is a Beta/Pro Feature</h2>
        <p>Upgrade your plan to unlock kitchen prep sheets, summary tickets, individual tickets, and more.</p>
        <a href="<?php echo esc_url( admin_url('admin.php?page=caterme-settings&tab=plan') ); ?>">View Plans →</a>
        </div></body></html><?php
        exit;
    }
    if ( ! current_user_can('manage_options') ) wp_die('Unauthorized.');

    $order_id = absint( $_GET['order_id'] ?? 0 );
    $format = sanitize_text_field( $_GET['format'] ?? 'prep_sheet' );
    
    if ( ! $order_id ) wp_die('Invalid order ID.');
    
    global $wpdb;
    $orders_table = $wpdb->prefix . 'caterme_orders';
    $order = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$orders_table} WHERE id=%d", $order_id) );
    
    if ( ! $order ) wp_die('Order not found.');
    
    // Get items with sorting
    $sort_by = $_GET['sort'] ?? 'type_dietary';
    $items = caterme_get_order_items_sorted( $order_id, $sort_by );
    
    // Initialize session for sort
    if ( ! session_id() ) session_start();
    
    // Render the appropriate ticket format
    switch ( $format ) {
        case 'individual':
            caterme_print_individual_tickets( $order, $items );
            break;
        case 'summary':
            caterme_print_kitchen_summary( $order, $items, $sort_by );
            break;
        case 'prep_sheet':
        default:
            caterme_print_kitchen_prep_sheet( $order, $items, $sort_by );
            break;
    }
    
    exit;
});

/**
 * Render kitchen prep sheet - Main production list
 */
function caterme_print_kitchen_prep_sheet( $order, $items, $sort_by ) {
    $total_items = count($items);
    $dietary_count = count( array_filter( $items, function($item) { return !empty($item->dietary); } ) );
    
    // Count by type
    $type_counts = array();
    foreach ( $items as $item ) {
        $type = caterme_get_item_type_label( $item->item_name );
        $type_counts[$type] = ($type_counts[$type] ?? 0) + 1;
    }
    
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Kitchen Prep Sheet - Order <?php echo esc_html($order->order_number); ?></title>
        <style>
            @page { margin: 0.5in; }
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: 'Courier New', Courier, monospace; 
                font-size: 11pt;
                line-height: 1.4;
                color: #000;
            }
            .header {
                border: 3px solid #000;
                padding: 15px 20px;
                margin-bottom: 20px;
                background: #f8f8f8;
            }
            .header h1 {
                font-size: 24pt;
                font-weight: bold;
                margin-bottom: 8px;
                text-transform: uppercase;
                letter-spacing: 2px;
            }
            .header-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-top: 12px;
                padding-top: 12px;
                border-top: 2px solid #000;
            }
            .header-grid div {
                font-size: 10pt;
            }
            .header-grid strong {
                display: inline-block;
                min-width: 120px;
                font-weight: bold;
            }
            .stats-bar {
                background: #000;
                color: #fff;
                padding: 10px 15px;
                margin-bottom: 20px;
                display: flex;
                justify-content: space-between;
                font-size: 10pt;
                font-weight: bold;
            }
            .stats-bar div {
                padding: 0 15px;
            }
            .section-header {
                background: #000;
                color: #fff;
                padding: 12px 15px;
                margin: 25px 0 10px 0;
                font-size: 14pt;
                font-weight: bold;
                letter-spacing: 1px;
                text-transform: uppercase;
                page-break-after: avoid;
            }
            .section-header:first-of-type {
                margin-top: 0;
            }
            .item {
                padding: 10px 15px;
                margin: 3px 0;
                border-left: 4px solid #ccc;
                page-break-inside: avoid;
                background: #fff;
            }
            .item.dietary {
                background: #fff9e6;
                border-left-color: #ff6b00;
            }
            .item-header {
                display: flex;
                justify-content: space-between;
                align-items: baseline;
                margin-bottom: 5px;
            }
            .item-number {
                font-size: 9pt;
                color: #666;
                min-width: 35px;
            }
            .item-name {
                font-size: 12pt;
                font-weight: bold;
                flex: 1;
            }
            .label-name {
                font-size: 11pt;
                color: #ff6b00;
                font-weight: bold;
                margin-top: 3px;
            }
            .label-name:before {
                content: "→ ";
            }
            .selections {
                font-size: 9pt;
                color: #444;
                margin-top: 4px;
                padding-left: 40px;
            }
            .dietary-tag {
                display: inline-block;
                background: #ff6b00;
                color: #fff;
                padding: 3px 8px;
                font-size: 8pt;
                font-weight: bold;
                border-radius: 3px;
                margin-top: 5px;
            }
            .section-footer {
                text-align: right;
                padding: 8px 15px;
                font-size: 9pt;
                color: #666;
                border-top: 1px solid #ccc;
                margin-bottom: 15px;
            }
            .footer {
                margin-top: 30px;
                padding-top: 15px;
                border-top: 3px solid #000;
                font-size: 9pt;
                text-align: center;
                color: #666;
            }
            @media print {
                body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
                .no-print { display: none; }
            }
        </style>
    </head>
    <body>
        <!-- Print Button -->
        <div class="no-print" style="position: fixed; top: 20px; right: 20px; z-index: 1000;">
            <button onclick="window.print()" style="padding: 12px 24px; font-size: 14pt; background: #000; color: #fff; border: none; cursor: pointer; border-radius: 5px;">
                🖨️ PRINT
            </button>
        </div>
        
        <!-- Header -->
        <div class="header">
            <h1>🍽️ Kitchen Prep Sheet</h1>
            <div class="header-grid">
                <div>
                    <strong>Order Number:</strong> <?php echo esc_html($order->order_number); ?><br>
                    <strong>Customer:</strong> <?php echo esc_html($order->customer_name); ?><br>
                    <strong>Phone:</strong> <?php echo esc_html($order->customer_phone); ?>
                </div>
                <div>
                    <strong>Fulfillment:</strong> <?php echo esc_html(ucfirst($order->fulfillment)); ?><br>
                    <strong>Date:</strong> <?php echo date('l, F j, Y', strtotime($order->order_date)); ?><br>
                    <strong>Time:</strong> <?php echo date('g:i A', strtotime($order->order_time)); ?>
                </div>
            </div>
        </div>
        
        <!-- Stats Bar -->
        <div class="stats-bar">
            <div>📦 TOTAL: <?php echo $total_items; ?> ITEMS</div>
            <?php if ($dietary_count > 0): ?>
            <div>⚠️ DIETARY: <?php echo $dietary_count; ?> ITEMS</div>
            <?php endif; ?>
            <div>📄 SORTED: <?php 
                $sort_labels = array(
                    'type_dietary' => 'BY TYPE + DIETARY',
                    'type' => 'BY TYPE',
                    'dietary' => 'DIETARY FIRST',
                    'label_name' => 'BY NAME',
                    'original' => 'ORIGINAL ORDER'
                );
                echo $sort_labels[$sort_by] ?? 'BY TYPE';
            ?></div>
        </div>
        
        <!-- Items -->
        <?php
        $current_group = null;
        $group_count = 0;
        $item_counter = 0;
        $show_grouping = in_array( $sort_by, array( 'type', 'type_dietary' ) );
        
        foreach ( $items as $item ):
            $item_counter++;
            
            // Show group header if sorting by type
            if ( $show_grouping ) {
                $item_group = caterme_get_item_type_label( $item->item_name );
                
                if ( $current_group !== $item_group ) {
                    // Close previous group
                    if ( $current_group !== null ) {
                        echo '<div class="section-footer">✓ Section Complete: ' . $group_count . ' items</div>';
                    }
                    
                    // Start new group
                    $current_group = $item_group;
                    $group_count = 0;
                    
                    echo '<div class="section-header">' . esc_html($item_group) . ' (' . $type_counts[$item_group] . ')</div>';
                }
                $group_count++;
            }
            
            $has_dietary = !empty($item->dietary);
            ?>
            <div class="item <?php echo $has_dietary ? 'dietary' : ''; ?>">
                <div class="item-header">
                    <span class="item-number">#<?php echo $item_counter; ?></span>
                    <span class="item-name"><?php echo esc_html($item->item_name); ?></span>
                    <?php if ($item->qty > 1): ?>
                    <span style="font-weight: bold;">×<?php echo (int)$item->qty; ?></span>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($item->label_name)): ?>
                <div class="label-name"><?php echo esc_html($item->label_name); ?></div>
                <?php endif; ?>
                
                <?php if ($item->selections): ?>
                <div class="selections">
                    <?php
                    $raw_sels = json_decode($item->selections, true) ?: array();
                    $sel_parts = array();
                    foreach ($raw_sels as $key => $val) {
                        if ($key === 'dietary' || $key === 'text') continue;
                        if ($val === false || $val === 0 || $val === '') continue;
                        if (is_array($val)) { foreach($val as $v) $sel_parts[] = $v; continue; }
                        if ($val === true) { $sel_parts[] = ucfirst(str_replace('_',' ',$key)); continue; }
                        $sel_parts[] = (string)$val;
                    }
                    // Also check for 'text' key (from ezCater imports)
                    if (isset($raw_sels['text']) && !empty($raw_sels['text'])) {
                        echo esc_html($raw_sels['text']);
                    } elseif (!empty($sel_parts)) {
                        echo esc_html(implode(' • ', $sel_parts));
                    }
                    ?>
                </div>
                <?php endif; ?>
                
                <?php if ($has_dietary): ?>
                <div class="dietary-tag">⚠️ <?php echo esc_html($item->dietary); ?></div>
                <?php endif; ?>
            </div>
            <?php
        endforeach;
        
        // Close final group
        if ( $show_grouping && $current_group !== null ) {
            echo '<div class="section-footer">✓ Section Complete: ' . $group_count . ' items</div>';
        }
        ?>
        
        <!-- Footer -->
        <div class="footer">
            <strong>END OF PREP SHEET</strong> • <?php echo $total_items; ?> Items Total
            <?php if ($dietary_count > 0): ?>
            • <?php echo $dietary_count; ?> with Dietary Restrictions
            <?php endif; ?>
            <br>
            Printed: <?php echo date('Y-m-d g:i A'); ?>
        </div>
        
        <script>
            // Auto-print on load (optional - comment out if not desired)
            // window.onload = function() { window.print(); }
        </script>
    </body>
    </html>
    <?php
}

/**
 * Render kitchen summary - Quick reference sheet
 */
function caterme_print_kitchen_summary( $order, $items, $sort_by ) {
    // Count by item type
    $type_breakdown = array();
    $dietary_items = array();
    
    foreach ( $items as $item ) {
        $type = $item->item_name;
        if ( !isset($type_breakdown[$type]) ) {
            $type_breakdown[$type] = array(
                'total' => 0,
                'with_dietary' => 0,
                'items' => array()
            );
        }
        $type_breakdown[$type]['total']++;
        
        if ( !empty($item->dietary) ) {
            $type_breakdown[$type]['with_dietary']++;
            $dietary_items[] = $item;
        }
    }
    
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Kitchen Summary - Order <?php echo esc_html($order->order_number); ?></title>
        <style>
            @page { margin: 0.5in; }
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: Arial, Helvetica, sans-serif;
                font-size: 11pt;
                color: #000;
            }
            .header {
                background: #000;
                color: #fff;
                padding: 20px;
                margin-bottom: 20px;
            }
            .header h1 {
                font-size: 28pt;
                margin-bottom: 10px;
            }
            .header-info {
                display: grid;
                grid-template-columns: 1fr 1fr 1fr;
                gap: 15px;
                font-size: 10pt;
            }
            .header-info strong {
                display: block;
                margin-bottom: 3px;
                font-size: 8pt;
                opacity: 0.7;
            }
            .totals-box {
                background: #f0f0f0;
                border: 2px solid #000;
                padding: 15px;
                margin-bottom: 20px;
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 10px;
                text-align: center;
            }
            .totals-box div {
                padding: 10px;
            }
            .totals-box .number {
                font-size: 32pt;
                font-weight: bold;
                line-height: 1;
            }
            .totals-box .label {
                font-size: 9pt;
                color: #666;
                margin-top: 5px;
            }
            .section {
                margin-bottom: 25px;
                page-break-inside: avoid;
            }
            .section h2 {
                background: #333;
                color: #fff;
                padding: 10px 15px;
                font-size: 14pt;
                margin-bottom: 10px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                font-size: 10pt;
            }
            th {
                background: #f0f0f0;
                padding: 8px 10px;
                text-align: left;
                border-bottom: 2px solid #000;
                font-weight: bold;
            }
            td {
                padding: 8px 10px;
                border-bottom: 1px solid #ddd;
            }
            tr:nth-child(even) {
                background: #fafafa;
            }
            .dietary-list {
                background: #fff9e6;
                border-left: 4px solid #ff6b00;
                padding: 10px 15px;
                margin: 5px 0;
            }
            .dietary-list strong {
                color: #ff6b00;
            }
            @media print {
                body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
                .no-print { display: none; }
            }
        </style>
    </head>
    <body>
        <!-- Print Button -->
        <div class="no-print" style="position: fixed; top: 20px; right: 20px; z-index: 1000;">
            <button onclick="window.print()" style="padding: 12px 24px; font-size: 14pt; background: #000; color: #fff; border: none; cursor: pointer; border-radius: 5px;">
                🖨️ PRINT
            </button>
        </div>
        
        <!-- Header -->
        <div class="header">
            <h1>📊 KITCHEN SUMMARY</h1>
            <div class="header-info">
                <div>
                    <strong>ORDER</strong>
                    <?php echo esc_html($order->order_number); ?>
                </div>
                <div>
                    <strong>CUSTOMER</strong>
                    <?php echo esc_html($order->customer_name); ?>
                </div>
                <div>
                    <strong>FULFILLMENT</strong>
                    <?php echo date('l, M j', strtotime($order->order_date)) . ' @ ' . date('g:i A', strtotime($order->order_time)); ?>
                </div>
            </div>
        </div>
        
        <!-- Totals -->
        <div class="totals-box">
            <div>
                <div class="number"><?php echo count($items); ?></div>
                <div class="label">TOTAL ITEMS</div>
            </div>
            <div>
                <div class="number"><?php echo count($type_breakdown); ?></div>
                <div class="label">ITEM TYPES</div>
            </div>
            <div>
                <div class="number" style="color: #ff6b00;"><?php echo count($dietary_items); ?></div>
                <div class="label">DIETARY RESTRICTIONS</div>
            </div>
            <div>
                <div class="number">$<?php echo number_format($order->subtotal, 0); ?></div>
                <div class="label">SUBTOTAL</div>
            </div>
        </div>
        
        <!-- Item Breakdown -->
        <div class="section">
            <h2>Item Breakdown</h2>
            <table>
                <thead>
                    <tr>
                        <th>Item Type</th>
                        <th style="text-align: center; width: 80px;">Quantity</th>
                        <th style="text-align: center; width: 120px;">With Dietary</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($type_breakdown as $type => $data): ?>
                    <tr>
                        <td><strong><?php echo esc_html($type); ?></strong></td>
                        <td style="text-align: center; font-weight: bold;"><?php echo $data['total']; ?></td>
                        <td style="text-align: center; <?php echo $data['with_dietary'] > 0 ? 'color: #ff6b00; font-weight: bold;' : 'color: #ccc;'; ?>">
                            <?php echo $data['with_dietary'] > 0 ? $data['with_dietary'] : '—'; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Dietary Restrictions Detail -->
        <?php if (count($dietary_items) > 0): ?>
        <div class="section">
            <h2>⚠️ Dietary Restrictions Detail</h2>
            <?php foreach ($dietary_items as $item): ?>
            <div class="dietary-list">
                <strong><?php echo esc_html($item->label_name ?: $item->item_name); ?></strong>
                — <?php echo esc_html($item->item_name); ?>
                <br>
                <span style="color: #ff6b00;">→ <?php echo esc_html($item->dietary); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <div style="margin-top: 30px; padding-top: 15px; border-top: 2px solid #000; text-align: center; font-size: 9pt; color: #666;">
            Printed: <?php echo date('Y-m-d g:i A'); ?>
        </div>
    </body>
    </html>
    <?php
}

/**
 * Render individual tickets - One per item for label stations
 */
function caterme_print_individual_tickets( $order, $items ) {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Individual Tickets - Order <?php echo esc_html($order->order_number); ?></title>
        <style>
            @page { 
                size: 4in 2in;
                margin: 0;
            }
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: Arial, sans-serif;
                font-size: 10pt;
            }
            .ticket {
                width: 4in;
                height: 2in;
                padding: 0.15in;
                border: 2px solid #000;
                page-break-after: always;
                position: relative;
                background: #fff;
            }
            .ticket-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding-bottom: 8px;
                border-bottom: 2px solid #000;
                margin-bottom: 8px;
            }
            .order-num {
                font-size: 11pt;
                font-weight: bold;
            }
            .item-num {
                font-size: 9pt;
                color: #666;
            }
            .label-name {
                font-size: 16pt;
                font-weight: bold;
                margin-bottom: 5px;
                color: #000;
            }
            .item-name {
                font-size: 12pt;
                font-weight: bold;
                margin-bottom: 4px;
            }
            .selections {
                font-size: 8pt;
                color: #444;
                line-height: 1.3;
                margin-bottom: 4px;
            }
            .dietary {
                background: #ff6b00;
                color: #fff;
                padding: 4px 8px;
                font-size: 9pt;
                font-weight: bold;
                display: inline-block;
                margin-top: 4px;
            }
            .ticket-footer {
                position: absolute;
                bottom: 0.15in;
                left: 0.15in;
                right: 0.15in;
                padding-top: 6px;
                border-top: 1px solid #ddd;
                font-size: 7pt;
                color: #888;
                display: flex;
                justify-content: space-between;
            }
            @media print {
                body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
                .no-print { display: none; }
            }
        </style>
    </head>
    <body>
        <!-- Print Button -->
        <div class="no-print" style="position: fixed; top: 20px; right: 20px; z-index: 1000; background: #fff; padding: 10px; border: 2px solid #000;">
            <button onclick="window.print()" style="padding: 12px 24px; font-size: 14pt; background: #000; color: #fff; border: none; cursor: pointer;">
                🖨️ PRINT ALL TICKETS
            </button>
            <div style="margin-top: 8px; font-size: 10pt;">
                <?php echo count($items); ?> tickets will print
            </div>
        </div>
        
        <?php 
        $counter = 0;
        foreach ($items as $item): 
            $counter++;
        ?>
        <div class="ticket">
            <div class="ticket-header">
                <span class="order-num">Order #<?php echo esc_html($order->order_number); ?></span>
                <span class="item-num"><?php echo $counter; ?> of <?php echo count($items); ?></span>
            </div>
            
            <?php if (!empty($item->label_name)): ?>
            <div class="label-name">→ <?php echo esc_html($item->label_name); ?></div>
            <?php endif; ?>
            
            <div class="item-name"><?php echo esc_html($item->item_name); ?></div>
            
            <?php if ($item->selections): ?>
            <div class="selections">
                <?php
                $raw_sels = json_decode($item->selections, true) ?: array();
                if (isset($raw_sels['text']) && !empty($raw_sels['text'])) {
                    echo esc_html($raw_sels['text']);
                } else {
                    $sel_parts = array();
                    foreach ($raw_sels as $key => $val) {
                        if ($key === 'dietary') continue;
                        if ($val === false || $val === 0 || $val === '') continue;
                        if (is_array($val)) { foreach($val as $v) $sel_parts[] = $v; continue; }
                        if ($val === true) { $sel_parts[] = ucfirst(str_replace('_',' ',$key)); continue; }
                        $sel_parts[] = (string)$val;
                    }
                    echo esc_html(implode(' • ', $sel_parts));
                }
                ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($item->dietary)): ?>
            <div class="dietary">⚠️ <?php echo esc_html($item->dietary); ?></div>
            <?php endif; ?>
            
            <div class="ticket-footer">
                <span><?php echo date('M j @ g:i A', strtotime($order->order_time)); ?></span>
                <span><?php echo esc_html(ucfirst($order->fulfillment)); ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </body>
    </html>
    <?php
}
