<?php
/**
 * CaterMe — Telemetry
 *
 * Batches events and forwards them to your aggregation endpoint.
 * This is how you see cross-site analytics for all beta testers
 * from a single dashboard (e.g. Google Sheets or a custom endpoint).
 *
 * Privacy: no PII is sent — only anonymized event types, feature usage,
 * error messages, and the site_id (a random UUID, not the domain).
 *
 * Endpoints supported:
 *   - Google Sheets via Apps Script (built-in, free)
 *   - Custom webhook (any URL, POST JSON)
 *
 * Data is batched and sent every 6 hours via WP-Cron to avoid
 * slowing down user-facing requests.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─────────────────────────────────────────────────────────────────────────────
// CONFIGURATION
// ─────────────────────────────────────────────────────────────────────────────

define( 'CATERME_TELEMETRY_BATCH_SIZE', 100 );   // max events per batch send
define( 'CATERME_TELEMETRY_CRON_HOOK', 'caterme_telemetry_send' );

// ─────────────────────────────────────────────────────────────────────────────
// ENQUEUE (called by caterme_track_event — transient buffer)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Add an event to the outbound telemetry buffer.
 * Buffer is flushed by cron every 6 hours, or when it hits batch size.
 */
function caterme_telemetry_enqueue( $event_type, $meta, $session_id ) {
    // Only send telemetry if an endpoint is configured
    if ( ! caterme_telemetry_enabled() ) return;

    $buffer = get_option( 'caterme_telemetry_buffer', array() );

    $buffer[] = array(
        'event'      => $event_type,
        'session_id' => $session_id,
        'meta'       => $meta,
        'ts'         => time(),
    );

    // Flush immediately if buffer is large enough
    if ( count( $buffer ) >= CATERME_TELEMETRY_BATCH_SIZE ) {
        update_option( 'caterme_telemetry_buffer', array() );
        caterme_telemetry_dispatch( $buffer );
        return;
    }

    update_option( 'caterme_telemetry_buffer', $buffer, false );
}

// ─────────────────────────────────────────────────────────────────────────────
// CRON SETUP
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'plugins_loaded', function() {
    if ( ! wp_next_scheduled( CATERME_TELEMETRY_CRON_HOOK ) ) {
        wp_schedule_event( time(), 'caterme_6hours', CATERME_TELEMETRY_CRON_HOOK );
    }
} );

add_filter( 'cron_schedules', function( $schedules ) {
    $schedules['caterme_6hours'] = array(
        'interval' => 6 * HOUR_IN_SECONDS,
        'display'  => 'Every 6 Hours (CaterMe)',
    );
    return $schedules;
} );

add_action( CATERME_TELEMETRY_CRON_HOOK, 'caterme_telemetry_flush' );

function caterme_telemetry_flush() {
    if ( ! caterme_telemetry_enabled() ) return;

    $buffer = get_option( 'caterme_telemetry_buffer', array() );
    if ( empty( $buffer ) ) return;

    update_option( 'caterme_telemetry_buffer', array() );
    caterme_telemetry_dispatch( $buffer );
}

// ─────────────────────────────────────────────────────────────────────────────
// DISPATCH
// ─────────────────────────────────────────────────────────────────────────────

function caterme_telemetry_enabled() {
    $settings = caterme_get_settings();
    return ! empty( $settings['telemetry_endpoint'] );
}

/**
 * Send a batch of events to the configured endpoint.
 */
function caterme_telemetry_dispatch( array $events ) {
    $settings = caterme_get_settings();
    $endpoint = $settings['telemetry_endpoint'] ?? '';
    if ( empty( $endpoint ) ) return;

    $payload = array(
        'site_id'     => caterme_get_site_id(),
        'plan'        => caterme_get_plan(),
        'cm_version'  => CATERME_VERSION,
        'wp_version'  => get_bloginfo( 'version' ),
        'site_url'    => md5( get_site_url() ), // hashed — not plain URL
        'php_version' => PHP_VERSION,
        'sent_at'     => date( 'c' ),
        'events'      => $events,
        'summary'     => caterme_telemetry_summary( $events ),
    );

    $response = wp_remote_post( $endpoint, array(
        'headers'    => array( 'Content-Type' => 'application/json' ),
        'body'       => wp_json_encode( $payload ),
        'timeout'    => 15,
        'user-agent' => 'CaterMe/' . CATERME_VERSION . '; WordPress/' . get_bloginfo('version'),
    ) );

    // Log dispatch result
    $success = ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200;
    update_option( 'caterme_telemetry_last_sent', array(
        'time'    => date( 'Y-m-d H:i:s' ),
        'count'   => count( $events ),
        'success' => $success,
        'error'   => is_wp_error( $response ) ? $response->get_error_message() : null,
    ), false );

    if ( ! $success ) {
        // Re-queue events that failed (up to 200 max to prevent unbounded growth)
        $existing = get_option( 'caterme_telemetry_buffer', array() );
        $requeued  = array_slice( array_merge( $events, $existing ), 0, 200 );
        update_option( 'caterme_telemetry_buffer', $requeued, false );
    }
}

/**
 * Build a summary object for the batch (useful for quick Sheets aggregation).
 */
function caterme_telemetry_summary( array $events ) {
    $counts = array();
    foreach ( $events as $ev ) {
        $counts[ $ev['event'] ] = ( $counts[ $ev['event'] ] ?? 0 ) + 1;
    }
    return array(
        'event_counts'  => $counts,
        'total_events'  => count( $events ),
        'unique_sessions' => count( array_unique( array_column( $events, 'session_id' ) ) ),
        'orders_in_batch' => $counts['order_submitted'] ?? 0,
        'errors_in_batch' => $counts['error'] ?? 0,
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// TELEMETRY SETTINGS (rendered inside the Integrations tab)
// ─────────────────────────────────────────────────────────────────────────────

function caterme_render_telemetry_settings( $s ) {
    $last = get_option( 'caterme_telemetry_last_sent', null );

    // ── Handle test alert ────────────────────────────────────────────────────
    if ( isset( $_POST['caterme_test_alert'], $_POST['_caterme_alert_nonce'] )
        && wp_verify_nonce( $_POST['_caterme_alert_nonce'], 'caterme_test_alert' ) ) {
        // Use the email from the settings (already saved) or admin fallback
        $test_recipient = sanitize_email( $s['error_alert_email'] ?? '' ) ?: get_option( 'admin_email' );
        add_filter( 'caterme_error_alert_recipient', function() use ($test_recipient) { return $test_recipient; } );
        caterme_send_error_alert(
            'Test error alert from CaterMe settings — if you see this, alerts are working!',
            array(
                'triggered_by' => 'manual test from Settings → Integrations',
                'version'      => CATERME_VERSION,
                'plan'         => caterme_get_plan(),
            ),
            'test'
        );
        echo '<div class="notice notice-success is-dismissible"><p>✅ Test alert sent to <strong>' . esc_html( $test_recipient ) . '</strong>. Check your inbox (and spam folder).</p></div>';
    }
    $buf_count = count( get_option( 'caterme_telemetry_buffer', array() ) );
    $next_cron = wp_next_scheduled( CATERME_TELEMETRY_CRON_HOOK );
    ?>
    <!-- ── Error Alert Email Card ──────────────────────────────────────────── -->
    <div class="cm-card" style="border-color:#dc2626;background:#fef2f2;margin-bottom:24px;">
        <div class="cm-card-head">
            <h2 style="color:#7f1d1d;">🚨 Instant Error Alert Email</h2>
            <p>Get an email the moment a PHP, JS, API, or DB error occurs in CaterMe. Alerts include the error message, file, line number, and a direct link to the error log. A 5-minute cooldown prevents flooding for repeated identical errors.</p>
        </div>
        <div class="cm-field">
            <label>
                <strong>Alert Recipient Email</strong>
                <em>Defaults to your WordPress admin email if left blank.</em>
            </label>
            <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:6px;">
                <input type="email" name="caterme_settings[error_alert_email]"
                    value="<?php echo esc_attr( $s['error_alert_email'] ?? '' ); ?>"
                    placeholder="<?php echo esc_attr( get_option('admin_email') ); ?>"
                    style="flex:1;min-width:260px;max-width:400px;border:1.5px solid #fca5a5;border-radius:6px;padding:9px 12px;font-size:14px;" />
                <form method="post" style="display:inline;">
                    <?php wp_nonce_field('caterme_test_alert','_caterme_alert_nonce'); ?>
                    <button type="submit" name="caterme_test_alert" class="button" style="border-color:#dc2626;color:#dc2626;font-weight:600;">
                        📧 Send Test Alert
                    </button>
                </form>
            </div>
            <p style="font-size:12px;color:#b91c1c;margin-top:8px;">
                ⚡ Alerts fire immediately — no cron delay. 5-min cooldown per unique error prevents inbox floods.<br>
                <strong>Note:</strong> The plugin developer (catermepro@gmail.com) always receives error alerts from all sites to enable fast support. This field adds a second recipient for your own records.
            </p>
        </div>
    </div>

    <!-- ── Telemetry Card ────────────────────────────────────────────────── -->
    <div class="cm-card" style="border-color:#7c3aed;background:#fdf4ff;">
        <div class="cm-card-head">
            <h2 style="color:#581c87;">📡 Beta Telemetry Endpoint</h2>
            <p>Forward anonymized usage events and errors from all beta tester sites to your aggregation endpoint. No PII — only event types, feature usage, and error messages.</p>
        </div>

        <!-- Apps Script code -->
        <details class="cm-details" style="border-color:#c4b5fd;margin-bottom:16px;">
            <summary style="background:#f3e8ff;color:#581c87;">📋 Google Sheets Apps Script</summary>
            <div class="cm-details-body">
                <p style="margin-bottom:10px;">Deploy this as a Web App and paste the URL below. Each batch becomes a row in your sheet with event counts, errors, and plan info per site.</p>
                <div style="position:relative;">
                    <pre id="telemetry-script" class="cm-code-block">function doPost(e) {
  try {
    var payload = JSON.parse(e.postData.contents);
    var ss = SpreadsheetApp.getActiveSpreadsheet();

    // ── Events sheet ─────────────────────────────────────────────
    var evSheet = ss.getSheetByName('Events') || ss.insertSheet('Events');
    if (evSheet.getLastRow() === 0) {
      evSheet.appendRow(['Site ID','Plan','CM Ver','Sent At','Total Events',
        'Unique Sessions','Orders','Errors','Event Counts (JSON)']);
      evSheet.getRange(1,1,1,9).setFontWeight('bold').setBackground('#1a1208').setFontColor('#f5e6c8');
      evSheet.setFrozenRows(1);
    }
    var s = payload.summary || {};
    evSheet.appendRow([
      payload.site_id, payload.plan, payload.cm_version,
      new Date(payload.sent_at),
      s.total_events || 0, s.unique_sessions || 0,
      s.orders_in_batch || 0, s.errors_in_batch || 0,
      JSON.stringify(s.event_counts || {})
    ]);

    // ── Errors sheet ─────────────────────────────────────────────
    var errSheet = ss.getSheetByName('Errors') || ss.insertSheet('Errors');
    if (errSheet.getLastRow() === 0) {
      errSheet.appendRow(['Site ID','Plan','Time','Type','Message','Context']);
      errSheet.getRange(1,1,1,6).setFontWeight('bold').setBackground('#7f1d1d').setFontColor('#fff');
      errSheet.setFrozenRows(1);
    }
    (payload.events || []).forEach(function(ev) {
      if (ev.event !== 'error') return;
      errSheet.appendRow([
        payload.site_id, payload.plan,
        new Date(ev.ts * 1000),
        ev.meta.error_type || 'unknown',
        ev.meta.message || '',
        JSON.stringify(ev.meta)
      ]);
    });

    // ── Sites summary sheet ───────────────────────────────────────
    var sitesSheet = ss.getSheetByName('Sites') || ss.insertSheet('Sites');
    if (sitesSheet.getLastRow() === 0) {
      sitesSheet.appendRow(['Site ID','Plan','CM Ver','PHP Ver','WP Ver','Last Seen']);
      sitesSheet.getRange(1,1,1,6).setFontWeight('bold').setBackground('#1a1208').setFontColor('#f5e6c8');
      sitesSheet.setFrozenRows(1);
    }
    // Upsert site row
    var data = sitesSheet.getDataRange().getValues();
    var found = false;
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === payload.site_id) {
        sitesSheet.getRange(i+1,2,1,5).setValues([[
          payload.plan, payload.cm_version, payload.php_version,
          payload.wp_version, new Date(payload.sent_at)
        ]]);
        found = true; break;
      }
    }
    if (!found) {
      sitesSheet.appendRow([payload.site_id, payload.plan, payload.cm_version,
        payload.php_version, payload.wp_version, new Date(payload.sent_at)]);
    }

    return ContentService.createTextOutput(JSON.stringify({success:true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({success:false,error:err.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}</pre>
                    <button type="button" onclick="copyTelemetryScript()" class="cm-copy-btn">Copy</button>
                </div>
            </div>
        </details>

        <div class="cm-field">
            <label><strong>Telemetry Endpoint URL</strong><em>Paste your deployed Apps Script Web App URL, or any JSON webhook endpoint.</em></label>
            <input type="url" name="caterme_settings[telemetry_endpoint]"
                value="<?php echo esc_attr( $s['telemetry_endpoint'] ?? '' ); ?>"
                placeholder="https://script.google.com/macros/s/YOUR_ID/exec"
                class="regular-text"
                style="width:100%;max-width:580px;border-color:#c4b5fd;margin-top:6px;" />
            <?php if ( ! empty( $s['telemetry_endpoint'] ) ): ?>
            <p style="color:#581c87;font-size:12px;margin-top:6px;">✅ Endpoint configured.</p>
            <?php endif; ?>
        </div>

        <!-- Status row -->
        <div style="margin-top:16px;display:flex;gap:20px;flex-wrap:wrap;font-size:13px;">
            <div style="background:#f3e8ff;border:1px solid #c4b5fd;border-radius:8px;padding:10px 14px;">
                <div style="font-weight:700;color:#581c87;">Buffer</div>
                <div style="color:#555;margin-top:3px;"><?php echo $buf_count; ?> event<?php echo $buf_count!==1?'s':''; ?> queued</div>
            </div>
            <div style="background:#f3e8ff;border:1px solid #c4b5fd;border-radius:8px;padding:10px 14px;">
                <div style="font-weight:700;color:#581c87;">Next Send</div>
                <div style="color:#555;margin-top:3px;"><?php echo $next_cron ? human_time_diff($next_cron) . ' from now' : 'Not scheduled'; ?></div>
            </div>
            <?php if ( $last ): ?>
            <div style="background:<?php echo $last['success'] ? '#f0fdf4' : '#fef2f2'; ?>;border:1px solid <?php echo $last['success'] ? '#86efac' : '#fca5a5'; ?>;border-radius:8px;padding:10px 14px;">
                <div style="font-weight:700;color:<?php echo $last['success'] ? '#14532d' : '#7f1d1d'; ?>;">Last Send</div>
                <div style="color:#555;margin-top:3px;">
                    <?php echo $last['success'] ? '✅' : '❌'; ?>
                    <?php echo esc_html($last['time']); ?>
                    (<?php echo $last['count']; ?> events)
                    <?php if ( ! $last['success'] && $last['error'] ): ?>
                    <span style="color:#dc2626;display:block;font-size:11px;"><?php echo esc_html($last['error']); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Manual flush button -->
        <?php if ( ! empty( $s['telemetry_endpoint'] ) && $buf_count > 0 ): ?>
        <div style="margin-top:14px;">
            <a href="<?php echo wp_nonce_url( admin_url('admin.php?page=caterme-settings&tab=integrations&caterme_action=flush_telemetry'), 'caterme_flush_telemetry' ); ?>" class="button">
                📤 Flush Buffer Now (<?php echo $buf_count; ?> events)
            </a>
        </div>
        <?php endif; ?>
    </div>

    <script>
    window.copyTelemetryScript = function() {
        var el = document.getElementById('telemetry-script');
        if (!el) return;
        navigator.clipboard.writeText(el.textContent).then(function() {
            var btns = document.querySelectorAll('.cm-copy-btn');
            btns.forEach(function(b){ if(b.onclick && b.onclick.toString().indexOf('Telemetry')>-1){ b.textContent='✓ Copied!'; setTimeout(function(){b.textContent='Copy';},2000); } });
        });
    };
    </script>
    <?php
}

// Handle manual flush action
add_action( 'admin_init', function() {
    if ( ( $_GET['caterme_action'] ?? '' ) !== 'flush_telemetry' ) return;
    if ( ! current_user_can( 'manage_options' ) ) return;
    if ( ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'caterme_flush_telemetry' ) ) return;

    caterme_telemetry_flush();
    wp_redirect( admin_url( 'admin.php?page=caterme-settings&tab=integrations&telemetry_flushed=1' ) );
    exit;
} );
