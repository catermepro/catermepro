<?php
/**
 * CaterMe — WooCommerce Cart API
 *
 * REST endpoints for adding/updating/removing WC cart items with modifier metadata.
 * Used by frontend React app to build WC cart instead of session storage.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── REST: Add item to WC cart ────────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/cart/add', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $request ) {
            if ( ! class_exists( 'WooCommerce' ) ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'WooCommerce not active.' ), 500 );
            }

            $body = $request->get_json_params();
            
            $product_id  = absint( $body['product_id'] ?? 0 );
            $quantity    = max( 1, absint( $body['quantity'] ?? 1 ) );
            $selections  = $body['selections'] ?? array();
            $label_name  = sanitize_text_field( $body['label_name'] ?? '' );
            $dietary     = sanitize_text_field( $body['dietary'] ?? '' );

            if ( ! $product_id ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'No product ID provided.' ), 400 );
            }

            // Calculate price with modifiers
            $product = wc_get_product( $product_id );
            if ( ! $product ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'Product not found.' ), 404 );
            }

            $base_price = floatval( $product->get_price() );
            $price = caterme_calculate_item_price( $product_id, $selections, $base_price );

            // Add to cart with custom price and meta
            $cart_item_data = array(
                'caterme_selections' => $selections,
                'caterme_label_name' => $label_name,
                'caterme_dietary'    => $dietary,
                'caterme_price'      => $price,
            );

            $cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, 0, array(), $cart_item_data );

            if ( ! $cart_item_key ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'Failed to add to cart.' ), 500 );
            }

            return new WP_REST_Response( array(
                'success'       => true,
                'cart_item_key' => $cart_item_key,
                'cart_count'    => WC()->cart->get_cart_contents_count(),
                'cart_total'    => WC()->cart->get_cart_contents_total(),
            ), 200 );
        },
    ));
});

// ─── REST: Update cart item quantity ──────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/cart/update', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $request ) {
            if ( ! class_exists( 'WooCommerce' ) ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'WooCommerce not active.' ), 500 );
            }

            $body = $request->get_json_params();
            
            $cart_item_key = sanitize_text_field( $body['cart_item_key'] ?? '' );
            $quantity      = max( 0, absint( $body['quantity'] ?? 1 ) );

            if ( ! $cart_item_key ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'No cart item key provided.' ), 400 );
            }

            WC()->cart->set_quantity( $cart_item_key, $quantity );

            return new WP_REST_Response( array(
                'success'    => true,
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_contents_total(),
            ), 200 );
        },
    ));
});

// ─── REST: Remove cart item ───────────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/cart/remove', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $request ) {
            if ( ! class_exists( 'WooCommerce' ) ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'WooCommerce not active.' ), 500 );
            }

            $body = $request->get_json_params();
            
            $cart_item_key = sanitize_text_field( $body['cart_item_key'] ?? '' );

            if ( ! $cart_item_key ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'No cart item key provided.' ), 400 );
            }

            WC()->cart->remove_cart_item( $cart_item_key );

            return new WP_REST_Response( array(
                'success'    => true,
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_contents_total(),
            ), 200 );
        },
    ));
});

// ─── REST: Get cart contents ──────────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/cart/get', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $request ) {
            if ( ! class_exists( 'WooCommerce' ) ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'WooCommerce not active.' ), 500 );
            }

            $cart_items = array();
            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                $product = $cart_item['data'];
                
                $cart_items[] = array(
                    'cart_item_key' => $cart_item_key,
                    'product_id'    => $cart_item['product_id'],
                    'name'          => $product->get_name(),
                    'quantity'      => $cart_item['quantity'],
                    'price'         => $cart_item['caterme_price'] ?? $product->get_price(),
                    'line_total'    => $cart_item['line_total'],
                    'selections'    => $cart_item['caterme_selections'] ?? array(),
                    'label_name'    => $cart_item['caterme_label_name'] ?? '',
                    'dietary'       => $cart_item['caterme_dietary'] ?? '',
                );
            }

            return new WP_REST_Response( array(
                'success'    => true,
                'items'      => $cart_items,
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_contents_total(),
            ), 200 );
        },
    ));
});

// ─── Apply custom price to cart items ─────────────────────────────────────────

add_action( 'woocommerce_before_calculate_totals', function( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;

    foreach ( $cart->get_cart() as $cart_item ) {
        if ( isset( $cart_item['caterme_price'] ) ) {
            $cart_item['data']->set_price( $cart_item['caterme_price'] );
        }
    }
});

// ─── Calculate item price with modifiers ──────────────────────────────────────

function caterme_calculate_item_price( $product_id, $selections, $base_price ) {
    $price = $base_price;
    
    // Get product modifiers
    $modifiers = get_post_meta( $product_id, '_caterme_modifiers', true );
    if ( ! is_array( $modifiers ) ) {
        $modifiers = array();
    }

    foreach ( $modifiers as $mod ) {
        $type = $mod['type'] ?? '';
        $key  = $mod['key'] ?? '';
        
        if ( ! isset( $selections[ $key ] ) ) continue;
        
        // Number type: multiply base price by quantity
        if ( $type === 'number' ) {
            $qty = floatval( $selections[ $key ] );
            if ( $qty > 0 ) {
                $price = $base_price * $qty;
            }
        }
        
        // Toggle type: add modifier price if enabled
        if ( $type === 'toggle' && $selections[ $key ] === true ) {
            $price += floatval( $mod['price'] ?? 0 );
        }
        
        // Select type: check for inline upcharges in choice labels
        if ( $type === 'select' ) {
            $vals = is_array( $selections[ $key ] ) ? $selections[ $key ] : array( $selections[ $key ] );
            foreach ( $vals as $val ) {
                if ( preg_match( '/\+\$([0-9.]+)/', $val, $matches ) ) {
                    $price += floatval( $matches[1] );
                }
            }
        }
    }

    return round( $price, 2 );
}

// ─── Display modifier data on cart item name ──────────────────────────────────

add_filter( 'woocommerce_cart_item_name', function( $product_name, $cart_item, $cart_item_key ) {
    $label_name = $cart_item['caterme_label_name'] ?? '';
    $selections = $cart_item['caterme_selections'] ?? array();
    $dietary    = $cart_item['caterme_dietary'] ?? '';

    if ( $label_name ) {
        $product_name .= '<div style="font-size:12px;color:#c8832a;font-weight:700;margin-top:3px;">🏷️ ' . esc_html( $label_name ) . '</div>';
    }

    if ( ! empty( $selections ) ) {
        $sel_parts = array();
        foreach ( $selections as $key => $val ) {
            if ( $key === 'dietary' ) continue;
            if ( $val === false || $val === 0 || $val === '' ) continue;
            if ( is_array( $val ) ) {
                foreach ( $val as $v ) $sel_parts[] = esc_html( $v );
                continue;
            }
            if ( $val === true ) {
                $sel_parts[] = esc_html( ucfirst( str_replace( '_', ' ', $key ) ) );
                continue;
            }
            $sel_parts[] = esc_html( (string) $val );
        }
        if ( ! empty( $sel_parts ) ) {
            $product_name .= '<div style="font-size:12px;color:#888;margin-top:3px;">' . implode( ' · ', $sel_parts ) . '</div>';
        }
    }

    if ( $dietary ) {
        $product_name .= '<div style="font-size:11px;color:#c8832a;margin-top:2px;">' . esc_html( $dietary ) . '</div>';
    }

    return $product_name;
}, 10, 3 );
