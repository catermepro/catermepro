<?php
/**
 * Order Items Sorting Feature
 * Allows sorting items within an order by various criteria
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Get items for an order with optional sorting
 */
function caterme_get_order_items_sorted( $order_id, $sort_by = '' ) {
    global $wpdb;
    $items_table = $wpdb->prefix . 'caterme_order_items';
    
    // Get the sort preference (from URL param, session, or default)
    if ( empty($sort_by) ) {
        $sort_by = $_GET['sort_items'] ?? $_SESSION['caterme_items_sort'] ?? 'original';
    }
    
    // Store sort preference in session
    $_SESSION['caterme_items_sort'] = $sort_by;
    
    // Base query
    $query = $wpdb->prepare( "SELECT * FROM {$items_table} WHERE order_id=%d", $order_id );
    
    // Apply sorting
    switch ( $sort_by ) {
        case 'type':
            // Sort by item type (sandwiches, salads, etc.)
            // Group similar items together
            $query .= " ORDER BY 
                CASE 
                    WHEN item_name LIKE '%sandwich%' OR item_name LIKE '%box lunch%' THEN 1
                    WHEN item_name LIKE '%salad%' THEN 2
                    WHEN item_name LIKE '%wrap%' THEN 3
                    WHEN item_name LIKE '%platter%' THEN 4
                    WHEN item_name LIKE '%side%' THEN 5
                    WHEN item_name LIKE '%dessert%' THEN 6
                    WHEN item_name LIKE '%beverage%' OR item_name LIKE '%drink%' THEN 7
                    ELSE 8
                END,
                item_name ASC";
            break;
            
        case 'type_dietary':
            // Sort by type, then dietary restrictions first within each type
            $query .= " ORDER BY 
                CASE 
                    WHEN item_name LIKE '%sandwich%' OR item_name LIKE '%box lunch%' THEN 1
                    WHEN item_name LIKE '%salad%' THEN 2
                    WHEN item_name LIKE '%wrap%' THEN 3
                    WHEN item_name LIKE '%platter%' THEN 4
                    WHEN item_name LIKE '%side%' THEN 5
                    WHEN item_name LIKE '%dessert%' THEN 6
                    WHEN item_name LIKE '%beverage%' OR item_name LIKE '%drink%' THEN 7
                    ELSE 8
                END,
                CASE WHEN dietary != '' THEN 0 ELSE 1 END,
                item_name ASC";
            break;
            
        case 'dietary':
            // Sort with dietary restrictions first
            $query .= " ORDER BY 
                CASE WHEN dietary != '' THEN 0 ELSE 1 END,
                dietary ASC,
                item_name ASC";
            break;
            
        case 'label_name':
            // Sort alphabetically by label name (person/company name)
            $query .= " ORDER BY 
                CASE WHEN label_name = '' THEN 1 ELSE 0 END,
                label_name ASC,
                item_name ASC";
            break;
            
        case 'item_name':
            // Sort alphabetically by item name
            $query .= " ORDER BY item_name ASC, label_name ASC";
            break;
            
        case 'original':
        default:
            // Original order (by ID)
            $query .= " ORDER BY id ASC";
            break;
    }
    
    return $wpdb->get_results( $query );
}

/**
 * Render the sort controls for order items
 */
function caterme_render_items_sort_controls( $order_id, $current_sort = '' ) {
    if ( empty($current_sort) ) {
        $current_sort = $_GET['sort_items'] ?? $_SESSION['caterme_items_sort'] ?? 'original';
    }
    
    $base_url = admin_url( 'admin.php?page=caterme-orders&order_id=' . $order_id );
    
    $sort_options = array(
        'original'      => array( 'label' => '🔢 Original Order', 'desc' => 'Order as received' ),
        'type'          => array( 'label' => '🍽️ By Type', 'desc' => 'Group similar items together' ),
        'type_dietary'  => array( 'label' => '🍽️⚠️ Type + Dietary', 'desc' => 'By type, restrictions first' ),
        'dietary'       => array( 'label' => '⚠️ Dietary First', 'desc' => 'Items with restrictions first' ),
        'label_name'    => array( 'label' => '🏷️ By Label Name', 'desc' => 'Alphabetical by person/company' ),
        'item_name'     => array( 'label' => '📝 By Item Name', 'desc' => 'Alphabetical by product' ),
    );
    
    ?>
    <div class="caterme-sort-controls" style="margin: 0 0 15px 0; padding: 12px 18px; background: #f9f9f9; border: 1px solid #e0d0b8; border-radius: 8px;">
        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
            <strong style="font-size: 13px; color: #666; white-space: nowrap;">
                <span style="margin-right: 4px;">⬇️</span>Sort Items:
            </strong>
            
            <div style="display: flex; gap: 6px; flex-wrap: wrap; flex: 1;">
                <?php foreach ( $sort_options as $key => $option ): ?>
                    <a href="<?php echo esc_url( add_query_arg( 'sort_items', $key, $base_url ) ); ?>" 
                       class="button <?php echo $current_sort === $key ? 'button-primary' : ''; ?>"
                       title="<?php echo esc_attr( $option['desc'] ); ?>"
                       style="font-size: 12px; padding: 4px 10px; height: auto; line-height: 1.4;">
                        <?php echo esc_html( $option['label'] ); ?>
                    </a>
                <?php endforeach; ?>
            </div>
            
            <?php if ( $current_sort !== 'original' ): ?>
                <a href="<?php echo esc_url( remove_query_arg( 'sort_items', $base_url ) ); ?>" 
                   class="button"
                   style="font-size: 11px; padding: 4px 8px; height: auto; color: #999;">
                    ↺ Reset
                </a>
            <?php endif; ?>
        </div>
        
        <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #e5e5e5; font-size: 11px; color: #888;">
            <strong>Current:</strong> <?php echo esc_html( $sort_options[$current_sort]['desc'] ); ?>
            <?php
            // Count items with dietary restrictions
            global $wpdb;
            $items_table = $wpdb->prefix . 'caterme_order_items';
            $dietary_count = $wpdb->get_var( $wpdb->prepare( 
                "SELECT COUNT(*) FROM {$items_table} WHERE order_id=%d AND dietary != ''", 
                $order_id 
            ) );
            $total_count = $wpdb->get_var( $wpdb->prepare( 
                "SELECT COUNT(*) FROM {$items_table} WHERE order_id=%d", 
                $order_id 
            ) );
            
            if ( $dietary_count > 0 ) {
                echo ' • <strong style="color: #c8832a;">' . (int)$dietary_count . ' of ' . (int)$total_count . '</strong> items have dietary restrictions';
            }
            ?>
        </div>
    </div>
    
    <style>
        .caterme-sort-controls .button {
            transition: all 0.2s ease;
        }
        .caterme-sort-controls .button:hover:not(.button-primary) {
            background: #fff;
            border-color: #c8832a;
        }
        .caterme-sort-controls .button-primary {
            background: #c8832a;
            border-color: #a07020;
            box-shadow: 0 1px 3px rgba(200, 131, 42, 0.3);
        }
        .caterme-sort-controls .button-primary:hover {
            background: #a07020;
        }
    </style>
    <?php
}

/**
 * Add visual grouping headers when sorting by type
 */
function caterme_get_item_type_label( $item_name ) {
    $item_lower = strtolower( $item_name );
    
    if ( strpos($item_lower, 'sandwich') !== false || strpos($item_lower, 'box lunch') !== false ) {
        return 'Sandwiches & Box Lunches';
    } elseif ( strpos($item_lower, 'salad') !== false ) {
        return 'Salads';
    } elseif ( strpos($item_lower, 'wrap') !== false ) {
        return 'Wraps';
    } elseif ( strpos($item_lower, 'platter') !== false ) {
        return 'Platters';
    } elseif ( strpos($item_lower, 'side') !== false ) {
        return 'Sides';
    } elseif ( strpos($item_lower, 'dessert') !== false ) {
        return 'Desserts';
    } elseif ( strpos($item_lower, 'beverage') !== false || strpos($item_lower, 'drink') !== false ) {
        return 'Beverages';
    } else {
        return 'Other Items';
    }
}

/**
 * Render items table with optional section headers
 */
function caterme_render_items_with_grouping( $items, $sort_by = '' ) {
    if ( empty($items) ) {
        echo '<tr><td colspan="4" style="text-align:center;padding:30px;color:#999;">No items in this order</td></tr>';
        return;
    }
    
    $show_grouping = in_array( $sort_by, array( 'type', 'type_dietary' ) );
    $current_group = null;
    $group_count = 0;
    
    foreach ( $items as $item ) {
        // Show group header if sorting by type
        if ( $show_grouping ) {
            $item_group = caterme_get_item_type_label( $item->item_name );
            
            if ( $current_group !== $item_group ) {
                if ( $current_group !== null ) {
                    // Close previous group
                    echo '<tr style="background:#faf7f2;"><td colspan="4" style="text-align:right;font-size:11px;color:#888;padding:4px 14px;border-top:1px solid #e5e5e5;">
                        ' . (int)$group_count . ' items</td></tr>';
                }
                
                // Start new group
                $current_group = $item_group;
                $group_count = 0;
                
                echo '<tr style="background:#1a1208;color:#f5e6c8;">
                    <td colspan="4" style="padding:8px 14px;font-weight:700;font-size:13px;letter-spacing:0.5px;">
                        ' . esc_html( $item_group ) . '
                    </td>
                </tr>';
            }
            $group_count++;
        }
        
        // Render item row
        ?>
        <tr <?php echo !empty($item->dietary) ? 'style="background:#fffaf0;"' : ''; ?>>
            <td>
                <strong><?php echo esc_html($item->item_name); ?></strong>
                <?php if ( !empty($item->label_name) ): ?>
                    <div style="font-size:12px;color:#c8832a;font-weight:700;margin-top:3px;">🏷️ <?php echo esc_html($item->label_name); ?></div>
                <?php endif; ?>
                <?php if ($item->selections): ?>
                    <div style="font-size:12px;color:#888;margin-top:3px;line-height:1.5;">
                        <?php
                        $raw_sels = json_decode($item->selections, true) ?: array();
                        $sel_parts = array();
                        foreach ($raw_sels as $key => $val) {
                            if ($key === 'dietary') continue;
                            if ($val === false || $val === 0 || $val === '') continue;
                            if (is_array($val)) { foreach($val as $v) $sel_parts[] = esc_html($v); continue; }
                            if ($val === true) { $sel_parts[] = esc_html(ucfirst(str_replace('_',' ',$key))); continue; }
                            $sel_parts[] = esc_html((string)$val);
                        }
                        echo implode(' · ', $sel_parts);
                        ?>
                    </div>
                <?php endif; ?>
                <?php if ($item->dietary): ?>
                    <div style="font-size:11px;color:#c8832a;margin-top:2px;font-weight:600;">
                        ⚠️ <?php echo esc_html($item->dietary); ?>
                    </div>
                <?php endif; ?>
            </td>
            <td style="text-align:center;"><?php echo (int)$item->qty; ?></td>
            <td style="text-align:right;">$<?php echo number_format($item->unit_price,2); ?></td>
            <td style="text-align:right;font-weight:700;">$<?php echo number_format($item->line_total,2); ?></td>
        </tr>
        <?php
    }
    
    // Close final group
    if ( $show_grouping && $current_group !== null ) {
        echo '<tr style="background:#faf7f2;"><td colspan="4" style="text-align:right;font-size:11px;color:#888;padding:4px 14px;border-top:1px solid #e5e5e5;">
            ' . (int)$group_count . ' items</td></tr>';
    }
}
