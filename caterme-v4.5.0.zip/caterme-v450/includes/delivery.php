<?php
/**
 * CaterMe — Delivery Fee & Lead Time
 *
 * Provides:
 *  • caterme_geocode_address()    — geocodes an address → {lat, lng} (Google or Nominatim)
 *  • caterme_haversine()          — straight-line distance in miles between two lat/lng points
 *  • caterme_calc_delivery_fee()  — applies tiered fee table, returns float or null
 *  • REST GET caterme/v1/delivery-fee  — public endpoint for real-time fee preview in app.js
 *  • wp_ajax caterme_geocode_store     — admin-only AJAX to geocode store address → save lat/lng
 */

if ( ! defined( 'ABSPATH' ) ) exit;


// ─── Geocoding ────────────────────────────────────────────────────────────────

/**
 * Geocode a free-form address string.
 * Uses Google Geocoding API if a key is configured, otherwise falls back to
 * OpenStreetMap Nominatim (free, no key required).
 *
 * @param  string $address
 * @return array|null  ['lat' => float, 'lng' => float] or null on failure
 */
function caterme_geocode_address( $address ) {
    if ( empty(trim($address)) ) return null;

    $s   = caterme_get_settings();
    $key = trim( $s['gmaps_key'] ?? '' );

    // ── Google Geocoding API ──────────────────────────────────────────────────
    if ( $key ) {
        $url = 'https://maps.googleapis.com/maps/api/geocode/json?' . http_build_query( array(
            'address' => $address,
            'key'     => $key,
        ) );
        $resp = wp_remote_get( $url, array( 'timeout' => 8 ) );
        if ( ! is_wp_error($resp) ) {
            $data = json_decode( wp_remote_retrieve_body($resp), true );
            if ( ( $data['status'] ?? '' ) === 'OK' && ! empty( $data['results'][0]['geometry']['location'] ) ) {
                $loc = $data['results'][0]['geometry']['location'];
                return array( 'lat' => (float) $loc['lat'], 'lng' => (float) $loc['lng'] );
            }
        }
    }

    // ── OpenStreetMap Nominatim (fallback) ───────────────────────────────────
    $url = 'https://nominatim.openstreetmap.org/search?' . http_build_query( array(
        'q'      => $address,
        'format' => 'json',
        'limit'  => 1,
    ) );
    $resp = wp_remote_get( $url, array(
        'timeout' => 8,
        'headers' => array( 'User-Agent' => 'CaterMe WordPress Plugin/4.2 (https://wordpress.org)' ),
    ) );
    if ( ! is_wp_error($resp) ) {
        $data = json_decode( wp_remote_retrieve_body($resp), true );
        if ( ! empty( $data[0]['lat'] ) ) {
            return array( 'lat' => (float) $data[0]['lat'], 'lng' => (float) $data[0]['lon'] );
        }
    }

    return null;
}


// ─── Haversine distance ───────────────────────────────────────────────────────

/**
 * Calculate straight-line distance in miles between two lat/lng coordinates.
 */
function caterme_haversine( $lat1, $lng1, $lat2, $lng2 ) {
    $R    = 3958.8; // Earth radius in miles
    $dLat = deg2rad( $lat2 - $lat1 );
    $dLng = deg2rad( $lng2 - $lng1 );
    $a    = sin($dLat/2) * sin($dLat/2)
          + cos(deg2rad($lat1)) * cos(deg2rad($lat2))
          * sin($dLng/2) * sin($dLng/2);
    return $R * 2 * atan2( sqrt($a), sqrt(1 - $a) );
}


// ─── Delivery fee calculator ──────────────────────────────────────────────────

/**
 * Given a delivery address, calculate the applicable tier fee.
 *
 * Returns:
 *   array  ['fee' => float, 'miles' => float]  on success
 *   null                                        if store location not configured
 *   false                                       if geocoding the customer address failed
 */
function caterme_calc_delivery_fee( $delivery_address ) {
    $s = caterme_get_settings();

    $store_lat = floatval( $s['store_lat'] ?? 0 );
    $store_lng = floatval( $s['store_lng'] ?? 0 );
    if ( ! $store_lat || ! $store_lng ) return null; // not configured

    $coords = caterme_geocode_address( $delivery_address );
    if ( ! $coords ) return false; // geocoding failed

    $miles = caterme_haversine( $store_lat, $store_lng, $coords['lat'], $coords['lng'] );

    // Load tiers, sort descending by over_miles so highest threshold wins
    $tiers = json_decode( $s['delivery_tiers'] ?? '[]', true );
    if ( ! is_array($tiers) || empty($tiers) ) {
        return array( 'fee' => 0.0, 'miles' => round($miles, 2) );
    }

    usort( $tiers, function($a, $b) {
        return floatval($b['over_miles']) <=> floatval($a['over_miles']);
    });

    foreach ( $tiers as $tier ) {
        if ( $miles >= floatval($tier['over_miles']) ) {
            return array(
                'fee'   => round( floatval($tier['fee']), 2 ),
                'miles' => round( $miles, 2 ),
            );
        }
    }

    return array( 'fee' => 0.0, 'miles' => round($miles, 2) );
}


// ─── REST: delivery-fee estimate ─────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route( 'caterme/v1', '/delivery-fee', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function( WP_REST_Request $request ) {
            $address = sanitize_text_field( $request->get_param('address') ?? '' );
            if ( ! $address ) {
                return new WP_REST_Response( array( 'fee' => null, 'error' => 'No address provided.' ), 200 );
            }
            $result = caterme_calc_delivery_fee( $address );
            if ( $result === null ) {
                return new WP_REST_Response( array( 'fee' => null, 'error' => 'Store location not configured.' ), 200 );
            }
            if ( $result === false ) {
                return new WP_REST_Response( array( 'fee' => null, 'error' => 'Could not locate that address. Please check and try again.' ), 200 );
            }
            return new WP_REST_Response( array(
                'fee'   => $result['fee'],
                'miles' => $result['miles'],
                'error' => null,
            ), 200 );
        },
    ));
});


// ─── Admin AJAX: geocode store address ───────────────────────────────────────

add_action( 'wp_ajax_caterme_geocode_store', function() {
    check_ajax_referer( 'caterme_geocode_store', 'nonce' );
    if ( ! current_user_can('manage_options') ) wp_send_json_error( 'Unauthorized', 403 );

    $address = sanitize_text_field( $_POST['address'] ?? '' );
    if ( ! $address ) {
        wp_send_json_error( array( 'message' => 'No address provided.' ) );
    }

    $coords = caterme_geocode_address( $address );
    if ( ! $coords ) {
        wp_send_json_error( array( 'message' => 'Could not geocode that address. Try a more specific address or enter coordinates manually.' ) );
    }

    // Save into settings
    $settings = get_option( 'caterme_settings', array() );
    $settings['store_lat'] = (string) $coords['lat'];
    $settings['store_lng'] = (string) $coords['lng'];
    update_option( 'caterme_settings', $settings );

    wp_send_json_success( array(
        'lat'     => $coords['lat'],
        'lng'     => $coords['lng'],
        'message' => 'Location saved: ' . round($coords['lat'], 5) . ', ' . round($coords['lng'], 5),
    ));
});
