<?php
/**
 * CaterMe — WooCommerce Integration
 *
 * Flow:
 *  1. Customer submits catering form → REST endpoint creates a WC order (status: on-hold)
 *  2. REST returns the WC checkout payment URL → JS redirects customer there
 *  3. Customer enters card → gateway authorizes (holds) the amount, order stays on-hold
 *  4. Admin reviews order in CaterMe panel
 *  5. Admin sets status to "confirmed" → plugin captures the pre-auth charge
 *  6. Admin sets status to "cancelled" → plugin voids / refunds the hold
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Check WooCommerce is active ──────────────────────────────────────────────
function caterme_wc_active() {
    return class_exists('WooCommerce');
}

// ─── DB: add WC columns if missing ────────────────────────────────────────────
function caterme_wc_upgrade_db() {
    global $wpdb;
    $table       = $wpdb->prefix . 'caterme_orders';
    $items_table = $wpdb->prefix . 'caterme_order_items';

    // Don't attempt ALTER if tables don't exist yet
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) return;
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$items_table}'" ) !== $items_table ) return;

    $cols = $wpdb->get_col("SHOW COLUMNS FROM {$table}", 0);
    if ( ! in_array('wc_order_id', (array)$cols) ) {
        $wpdb->query("ALTER TABLE {$table} ADD COLUMN wc_order_id BIGINT UNSIGNED DEFAULT NULL AFTER id");
    }
    if ( ! in_array('payment_status', (array)$cols) ) {
        $wpdb->query("ALTER TABLE {$table} ADD COLUMN payment_status VARCHAR(40) DEFAULT 'none' AFTER wc_order_id");
    }

    $item_cols = $wpdb->get_col("SHOW COLUMNS FROM {$items_table}", 0);
    if ( ! in_array('label_name', (array)$item_cols) ) {
        $wpdb->query("ALTER TABLE {$items_table} ADD COLUMN label_name VARCHAR(100) DEFAULT '' AFTER dietary");
    }
}
add_action( 'plugins_loaded', 'caterme_wc_upgrade_db', 20 );

// ─── Create WC order from catering order data ─────────────────────────────────
/**
 * @param  int    $catering_order_id  Row ID in wp_caterme_orders
 * @param  array  $data               Sanitized payload from REST
 * @param  array  $items              Sanitized items
 * @return int|WP_Error               WC order ID or error
 */
function caterme_create_wc_order( $catering_order_id, $data, $items ) {
    if ( ! caterme_wc_active() ) {
        return new WP_Error('no_wc', 'WooCommerce is not active.');
    }

    $settings   = caterme_get_settings();
    $tax_enabled = ( $settings['wc_tax_enabled'] ?? '1' ) === '1';

    $order = wc_create_order();
    if ( is_wp_error($order) ) return $order;

    // ── Set customer info FIRST — WC needs billing address to compute tax ─────
    $first = '';
    $last  = '';
    $name  = $data['customer_name'] ?? '';
    if ( $name ) {
        $parts = explode(' ', $name, 2);
        $first = $parts[0];
        $last  = $parts[1] ?? '';
    }

    $billing = array(
        'first_name' => $first,
        'last_name'  => $last,
        'email'      => $data['customer_email'] ?? '',
        'phone'      => $data['customer_phone'] ?? '',
    );
    $order->set_billing_address( $billing );
    if ( ($data['fulfillment'] ?? '') === 'delivery' ) {
        $order->set_shipping_address( $billing );
    }

    // ── Add a single fee line for the catering order total ────────────────────
    $order_number = $data['order_number'] ?? ('CAT-' . $catering_order_id);
    $subtotal     = floatval( $data['subtotal'] ?? 0 );

    // Build description from item list
    $item_lines = array();
    foreach ( $items as $item ) {
        $qty  = absint( $item['qty'] ?? 1 );
        $name = sanitize_text_field( $item['name'] ?? 'Item' );
        $item_lines[] = $qty . 'x ' . $name;
    }

    $fee = new WC_Order_Item_Fee();
    $fee->set_name( 'Catering Order ' . $order_number . ': ' . implode(', ', $item_lines) );
    $fee->set_amount( $subtotal );
    $fee->set_tax_status( $tax_enabled ? 'taxable' : 'none' );
    $fee->set_total( $subtotal );
    $order->add_item( $fee );

    // ── Add shipping note if delivery ─────────────────────────────────────────
    $fulfillment = $data['fulfillment'] ?? 'pickup';
    $note_parts  = array( 'Catering Order Ref: ' . $order_number );
    if ( $data['orderDate'] ?? '' ) {
        $note_parts[] = ($fulfillment === 'delivery' ? 'Delivery' : 'Pick Up') . ': ' . $data['orderDate'] . ($data['orderTime'] ? ' at ' . $data['orderTime'] : '');
    }
    if ( $data['notes'] ?? '' ) {
        $note_parts[] = 'Note: ' . $data['notes'];
    }
    $order->add_order_note( implode(' | ', $note_parts) );

    // ── Set order metadata ─────────────────────────────────────────────────────
    $order->update_meta_data( '_caterme_order_id', $catering_order_id );
    $order->update_meta_data( '_caterme_order_number', $order_number );

    // ── Totals & status ────────────────────────────────────────────────────────
    // calculate_totals() applies WC tax rates based on billing address
    $order->calculate_totals( $tax_enabled );
    $order->set_status( 'pending', 'Awaiting catering pre-authorization.' );
    $order->save();

    return $order->get_id();
}

// ─── Get the WC payment URL for an order ─────────────────────────────────────
function caterme_get_wc_payment_url( $wc_order_id, $return_url = '' ) {
    $wc_order = wc_get_order( $wc_order_id );
    if ( ! $wc_order ) return '';

    $pay_url = $wc_order->get_checkout_payment_url();

    if ( $return_url ) {
        // Append catering return URL so we can show a confirmation page
        $pay_url = add_query_arg( 'caterme_return', urlencode($return_url), $pay_url );
    }

    return $pay_url;
}

// ─── Capture payment (pre-auth → charge) ─────────────────────────────────────
function caterme_capture_wc_payment( $wc_order_id ) {
    if ( ! caterme_wc_active() ) return false;

    $wc_order = wc_get_order( $wc_order_id );
    if ( ! $wc_order ) return false;

    $gateway_id = $wc_order->get_payment_method();

    // ── Stripe (woocommerce-gateway-stripe) ───────────────────────────────────
    if ( strpos($gateway_id, 'stripe') !== false ) {
        return caterme_capture_stripe( $wc_order );
    }

    // ── Authorize.net (woocommerce-gateway-authorize-net-cim) ─────────────────
    if ( strpos($gateway_id, 'authorize') !== false || $gateway_id === 'authorize_net_cim_credit_card' ) {
        return caterme_capture_authnet( $wc_order );
    }

    // ── Generic fallback: move WC order to processing ─────────────────────────
    // Many gateways capture on `on-hold → processing` transition
    $wc_order->update_status( 'processing', 'Captured by CaterMe on order confirmation.' );
    return true;
}

// ── Stripe capture ────────────────────────────────────────────────────────────
function caterme_capture_stripe( WC_Order $wc_order ) {
    $intent_id = $wc_order->get_meta('_stripe_intent_id')
              ?: $wc_order->get_meta('_stripe_charge_id')
              ?: $wc_order->get_meta('_payment_intent_id');

    if ( ! $intent_id ) {
        // Fall back to transitioning status — Stripe plugin may handle it
        $wc_order->update_status('processing', 'CaterMe: capture triggered via status change.');
        return true;
    }

    // Use WC Stripe's built-in capture if available
    if ( class_exists('WC_Stripe_Payment_Tokens') || class_exists('WC_Gateway_Stripe') ) {
        $gateways = WC()->payment_gateways()->payment_gateways();
        $stripe   = $gateways['stripe'] ?? $gateways['stripe_cc'] ?? null;

        if ( $stripe && method_exists($stripe, 'capture_payment') ) {
            $stripe->capture_payment( $wc_order->get_id() );
            $wc_order->update_status('processing', 'CaterMe: Stripe payment captured.');
            return true;
        }
    }

    // Direct Stripe API call (if WP HTTP is available and secret key stored)
    $secret_key = get_option('woocommerce_stripe_settings')['secret_key'] ?? '';
    if ( $secret_key && substr($intent_id, 0, 2) === 'pi' ) {
        $response = wp_remote_post(
            "https://api.stripe.com/v1/payment_intents/{$intent_id}/capture",
            array(
                'headers' => array( 'Authorization' => 'Bearer ' . $secret_key ),
                'timeout' => 20,
            )
        );
        if ( ! is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 ) {
            $wc_order->update_status('processing', 'CaterMe: Stripe PaymentIntent captured via API.');
            return true;
        }
        $body = json_decode( wp_remote_retrieve_body($response), true );
        $wc_order->add_order_note( 'Stripe capture error: ' . ($body['error']['message'] ?? 'unknown') );
        return false;
    }

    $wc_order->update_status('processing', 'CaterMe: capture requested (Stripe).');
    return true;
}

// ── Authorize.net capture ─────────────────────────────────────────────────────
function caterme_capture_authnet( WC_Order $wc_order ) {
    // SkyVerge / WooCommerce Authorize.net gateway stores transaction ID in order meta
    $trans_id = $wc_order->get_transaction_id();

    if ( ! $trans_id ) {
        $wc_order->update_status('processing', 'CaterMe: capture triggered.');
        return true;
    }

    // Try using the gateway's own capture method if loaded
    $gateways = WC()->payment_gateways()->payment_gateways();
    foreach ( $gateways as $gw ) {
        if ( strpos($gw->id, 'authorize') !== false && method_exists($gw, 'capture_charge') ) {
            $gw->capture_charge( $wc_order );
            $wc_order->update_status('processing', 'CaterMe: Auth.net payment captured.');
            return true;
        }
    }

    // Fallback: status change (gateway may hook into this)
    $wc_order->update_status('processing', 'CaterMe: capture triggered via status change.');
    return true;
}

// ─── Void / Refund payment ────────────────────────────────────────────────────
function caterme_void_wc_payment( $wc_order_id ) {
    if ( ! caterme_wc_active() ) return false;

    $wc_order = wc_get_order( $wc_order_id );
    if ( ! $wc_order ) return false;

    $status = $wc_order->get_status();

    // If already captured (processing/completed), issue a refund
    if ( in_array($status, array('processing', 'completed')) ) {
        $refund = wc_create_refund( array(
            'order_id' => $wc_order_id,
            'amount'   => $wc_order->get_total(),
            'reason'   => 'Catering order cancelled.',
        ));
        if ( ! is_wp_error($refund) ) {
            $wc_order->add_order_note('CaterMe: refund issued on cancellation.');
            return true;
        }
    }

    // If still on-hold/pending (un-captured auth), cancel the order
    $wc_order->update_status('cancelled', 'CaterMe: order cancelled — hold voided.');
    return true;
}

// ─── Hook: sync WC payment status back to catering order ─────────────────────
// When the WC order payment status changes, update our catering order record.

add_action( 'woocommerce_order_status_changed', function( $order_id, $old_status, $new_status ) {
    global $wpdb;

    $wc_order    = wc_get_order( $order_id );
    $catering_id = (int) $wc_order->get_meta('_caterme_order_id');
    if ( ! $catering_id ) return;

    $table = $wpdb->prefix . 'caterme_orders';

    $payment_map = array(
        'pending'    => 'pending',
        'on-hold'    => 'authorized',
        'processing' => 'captured',
        'completed'  => 'captured',
        'refunded'   => 'refunded',
        'cancelled'  => 'voided',
        'failed'     => 'failed',
    );

    $new_payment_status = $payment_map[ $new_status ] ?? $new_status;

    // Also sync the calculated tax amount from WC
    $tax = round( floatval( $wc_order->get_total_tax() ), 2 );

    $wpdb->update( $table,
        array(
            'payment_status' => $new_payment_status,
            'tax'            => $tax,
        ),
        array( 'id' => $catering_id )
    );
}, 10, 3 );

// ─── Admin: Render payment status badge ──────────────────────────────────────
function caterme_payment_badge( $status ) {
    $colors = array(
        'none'       => array('#787c82','#fff','No Payment'),
        'pending'    => array('#d63638','#fff','Awaiting Payment'),
        'authorized' => array('#8c5e00','#fff','Pre-Authorized 🔒'),
        'captured'   => array('#00a32a','#fff','Captured ✅'),
        'refunded'   => array('#2271b1','#fff','Refunded'),
        'voided'     => array('#787c82','#fff','Voided'),
        'failed'     => array('#d63638','#fff','Failed ❌'),
    );
    $c = $colors[$status] ?? array('#ccc','#333',$status);
    return '<span style="background:'.$c[0].';color:'.$c[1].';border-radius:4px;padding:2px 8px;font-size:11px;white-space:nowrap;">'.$c[2].'</span>';
}

// ─── Admin: Payment action buttons ────────────────────────────────────────────
function caterme_payment_actions_html( $order, $wc_order_id ) {
    if ( ! $wc_order_id ) return '<em style="color:#888;font-size:12px;">WooCommerce not configured.</em>';

    $wc_order = wc_get_order( $wc_order_id );
    if ( ! $wc_order ) return '<em style="color:#888;font-size:12px;">WC order not found.</em>';

    $wc_status      = $wc_order->get_status();
    $payment_status = $order->payment_status ?? 'none';
    $admin_url      = admin_url('admin.php?page=caterme-orders&view='.$order->id);

    $html  = '<div style="display:flex;flex-direction:column;gap:8px;">';

    $html .= '<div style="font-size:12px;color:#666;">WC Order: <a href="'.admin_url('post.php?post='.$wc_order_id.'&action=edit').'" target="_blank">#'.$wc_order_id.'</a></div>';
    $html .= '<div style="font-size:12px;color:#666;">WC Status: <strong>'.ucfirst($wc_status).'</strong></div>';
    $tax_total = floatval( $wc_order->get_total_tax() );
    if ( $tax_total > 0 ) {
        $html .= '<div style="font-size:12px;color:#666;">Tax: <strong>$'.number_format($tax_total,2).'</strong></div>';
    }
    $html .= '<div style="font-size:12px;color:#666;">WC Total: <strong>$'.number_format($wc_order->get_total(),2).'</strong></div>';

    if ( $payment_status === 'authorized' ) {
        $html .= '<form method="post" style="margin:0;">'.wp_nonce_field('caterme_payment_action','_wpnonce',true,false).'<input type="hidden" name="order_id" value="'.$order->id.'"><button name="caterme_capture_payment" type="submit" class="button button-primary" style="background:#00a32a;border-color:#00a32a;">💳 Capture Payment</button></form>';
        $html .= '<form method="post" style="margin:0;" onsubmit="return confirm(\'Void the pre-authorization?\')">'.wp_nonce_field('caterme_payment_action','_wpnonce',true,false).'<input type="hidden" name="order_id" value="'.$order->id.'"><button name="caterme_void_payment" type="submit" class="button" style="color:#d63638;border-color:#d63638;">🚫 Void Hold</button></form>';
    } elseif ( $payment_status === 'captured' ) {
        $html .= '<form method="post" style="margin:0;" onsubmit="return confirm(\'Issue a full refund?\')">'.wp_nonce_field('caterme_payment_action','_wpnonce',true,false).'<input type="hidden" name="order_id" value="'.$order->id.'"><button name="caterme_refund_payment" type="submit" class="button" style="color:#2271b1;border-color:#2271b1;">↩️ Refund</button></form>';
    } elseif ( $payment_status === 'pending' || $payment_status === 'none' ) {
        $pay_url = $wc_order->get_checkout_payment_url();
        $html .= '<a href="'.esc_url($pay_url).'" target="_blank" class="button" style="font-size:11.5px;">🔗 Payment Link</a>';
        $html .= '<small style="color:#888;font-size:11px;">Share this link with customer to collect payment.</small>';
    }

    $html .= '</div>';
    return $html;
}
