<?php
/**
 * Plugin Name: CaterMe
 * Description: Catering order management built on WooCommerce. Pulls products from your WC catalog, adds catering-specific fields (modifiers, unit, sub-filter tag, no-label flag), handles fulfillment scheduling, Avery 5163 labels, invoices, tipping, and admin order management. Requires WooCommerce. Shortcode: [CaterMe_Menu]
 * Version: 4.0.0
 * Author: CaterMe
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CATERME_VERSION',     '4.5.0' );
define( 'CATERME_DB_VERSION',  '11' );

// ── License Server ────────────────────────────────────────────────────────────
// Paste your deployed Google Apps Script Web App URL here.
// Generate keys from your Google Sheet, not from inside the plugin.
define( 'CATERME_LICENSE_SERVER_URL', 'https://script.google.com/macros/s/REPLACE_WITH_YOUR_DEPLOYMENT_ID/exec' );

// ── Self-reference for deactivation hook ─────────────────────────────────────
define( 'CATERME_PLUGIN_FILE', __FILE__ );

require_once plugin_dir_path(__FILE__) . 'includes/woocommerce.php';
require_once plugin_dir_path(__FILE__) . 'includes/notifications.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc-product-meta.php';
require_once plugin_dir_path(__FILE__) . 'includes/modifier-templates.php';
require_once plugin_dir_path(__FILE__) . 'includes/sample-data.php';
require_once plugin_dir_path(__FILE__) . 'includes/delivery.php';
require_once plugin_dir_path(__FILE__) . 'includes/blackout-dates.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc-checkout-integration.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc-cart-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/ezcater-import.php';
require_once plugin_dir_path(__FILE__) . 'includes/order-items-sorting.php';
require_once plugin_dir_path(__FILE__) . 'includes/kitchen-tickets.php';

// ── Freemium, Analytics & Telemetry (load early — analytics sets up error handler)
require_once plugin_dir_path(__FILE__) . 'includes/analytics.php';
require_once plugin_dir_path(__FILE__) . 'includes/telemetry.php';
require_once plugin_dir_path(__FILE__) . 'includes/freemium.php';

// ─────────────────────────────────────────────────────────────────────────────
// ACTIVATION / DATABASE SETUP
// ─────────────────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'caterme_activate' );

function caterme_activate() {
    caterme_create_tables();
    update_option( 'caterme_db_version', CATERME_DB_VERSION );
}

function caterme_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $orders  = $wpdb->prefix . 'caterme_orders';
    $items   = $wpdb->prefix . 'caterme_order_items';

    // Analytics & error tracking tables
    caterme_create_analytics_tables();

    // Use direct queries — dbDelta is unreliable on managed hosting environments
    $wpdb->query( "CREATE TABLE IF NOT EXISTS `{$orders}` (
        `id`               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `wc_order_id`      BIGINT UNSIGNED DEFAULT NULL,
        `payment_status`   VARCHAR(40)     NOT NULL DEFAULT 'none',
        `order_number`     VARCHAR(20)     NOT NULL DEFAULT '',
        `status`           VARCHAR(30)     NOT NULL DEFAULT 'new',
        `fulfillment`      VARCHAR(20)     NOT NULL DEFAULT 'pickup',
        `order_date`       DATE            DEFAULT NULL,
        `order_time`       TIME            DEFAULT NULL,
        `subtotal`         DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        `delivery_fee`     DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        `tax`              DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        `tip`              DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        `customer_name`    VARCHAR(120)    NOT NULL DEFAULT '',
        `customer_phone`   VARCHAR(30)     NOT NULL DEFAULT '',
        `customer_email`   VARCHAR(120)    NOT NULL DEFAULT '',
        `delivery_address` VARCHAR(500)    NOT NULL DEFAULT '',
        `notes`            TEXT,
        `created_at`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `status` (`status`),
        KEY `order_date` (`order_date`)
    ) {$charset}" );

    // Add columns to existing tables that predate v4.1.0 / v4.2.1
    $cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$orders}`" );
    if ( ! in_array('tip', $cols) ) {
        $wpdb->query( "ALTER TABLE `{$orders}` ADD `tip` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `subtotal`" );
    }
    if ( ! in_array('delivery_fee', $cols) ) {
        $wpdb->query( "ALTER TABLE `{$orders}` ADD `delivery_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `subtotal`" );
    }
    if ( ! in_array('tax', $cols) ) {
        $wpdb->query( "ALTER TABLE `{$orders}` ADD `tax` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `delivery_fee`" );
    }
    if ( ! in_array('delivery_address', $cols) ) {
        $wpdb->query( "ALTER TABLE `{$orders}` ADD `delivery_address` VARCHAR(500) NOT NULL DEFAULT '' AFTER `customer_email`" );
    }

    $wpdb->query( "CREATE TABLE IF NOT EXISTS `{$items}` (
        `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `order_id`    BIGINT UNSIGNED NOT NULL,
        `item_name`   VARCHAR(200)    NOT NULL DEFAULT '',
        `qty`         SMALLINT        NOT NULL DEFAULT 1,
        `unit_price`  DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        `line_total`  DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        `selections`  LONGTEXT,
        `dietary`     VARCHAR(500)    NOT NULL DEFAULT '',
        `label_name`  VARCHAR(100)    NOT NULL DEFAULT '',
        PRIMARY KEY (`id`),
        KEY `order_id` (`order_id`)
    ) {$charset}" );
}

// Create/migrate tables when version mismatches OR when tables are physically missing.
add_action( 'plugins_loaded', function() {
    global $wpdb;

    $orders_table = $wpdb->prefix . 'caterme_orders';
    $tables_exist = $wpdb->get_var( "SHOW TABLES LIKE '{$orders_table}'" ) === $orders_table;

    if ( $tables_exist && get_option('caterme_db_version') === CATERME_DB_VERSION ) return;

    // Rename old boones_ tables if they exist and new caterme_ ones don't yet
    $old_orders = $wpdb->prefix . 'boones_orders';
    $new_orders = $wpdb->prefix . 'caterme_orders';
    $old_items  = $wpdb->prefix . 'boones_order_items';
    $new_items  = $wpdb->prefix . 'caterme_order_items';
    $existing   = $wpdb->get_col( "SHOW TABLES" );
    if ( in_array( $old_orders, $existing ) && ! in_array( $new_orders, $existing ) ) {
        $wpdb->query( "RENAME TABLE `{$old_orders}` TO `{$new_orders}`" );
    }
    if ( in_array( $old_items, $existing ) && ! in_array( $new_items, $existing ) ) {
        $wpdb->query( "RENAME TABLE `{$old_items}` TO `{$new_items}`" );
    }

    caterme_create_tables();
    update_option( 'caterme_db_version', CATERME_DB_VERSION );
    delete_option( 'boones_db_version' );
}, 5 );

// ─────────────────────────────────────────────────────────────────────────────
// SETTINGS
// ─────────────────────────────────────────────────────────────────────────────

function caterme_defaults() {
    return array(
        'style_mode'       => 'custom',
        'color_primary'    => '#1a1208',
        'color_accent'     => '#c8832a',
        'color_bg'         => '#faf7f2',
        'color_card'       => '#ffffff',
        'color_text'       => '#2a1f0e',
        'color_text_muted' => '#7a6040',
        'color_border'     => '#e8dcc8',
        'font_heading'     => 'Georgia, serif',
        'font_body'        => 'Georgia, serif',
        'border_radius'    => '12',
        'show_header'      => '1',
        'sheets_webhook'   => '',
        'store_name'       => 'My Catering Co.',
        'store_address'    => '123 Main Street, Your City, ST',
        'store_phone'      => '(555) 000-0000',
        'store_email'      => 'catering@yourdomain.com',
        'wc_enabled'       => '1',
        'wc_tax_enabled'   => '1',        // apply WC tax rates to catering orders
        'test_mode'        => '0',
        'wc_preauth_note'  => 'Your card will be pre-authorized but not charged until your order is confirmed.',
        'notify_emails'    => '',   // comma-separated list of recipient addresses
        'notify_on_new'    => '1',  // send on new order
        'notify_on_paid'   => '1',  // send when payment pre-authorized (WC on-hold)
        'notify_on_confirmed' => '1', // send when admin confirms
        'notify_subject'   => 'New Catering Order: {order_number}',
        // ── Label & Email Formatting ──────────────────────────────────────────
        'logo_url'            => '',
        'label_orientation'   => 'portrait',
        'label_font'          => 'Arial, Helvetica, sans-serif',
        'label_font_size'     => '11',
        'label_font_weight'   => 'bold',
        'label_color_primary' => '#1a1208',
        'label_color_accent'  => '#c8832a',
        'label_logo_height'   => '28',   // px max-height of logo on printed label
        'email_font'          => 'Georgia, serif',
        'email_color_header'  => '#1a1208',
        'email_color_accent'  => '#c8832a',
        'email_color_text'    => '#1a1208',
        'email_font_size'     => '14',
        'email_logo_height'   => '56',   // px max-height of logo in email header
        // ── Logo Alignment ────────────────────────────────────────────────────
        'label_logo_align'    => 'left',     // left | center | right
        'email_logo_align'    => 'center',   // left | center | right
        // ── Tipping ───────────────────────────────────────────────────────────
        'tip_enabled'         => '1',        // 1 | 0
        'tip_presets'         => '15,20,25', // comma-separated percentages
        // ── Menu Display ──────────────────────────────────────────────────────
        'menu_columns'        => '2',        // 1 | 2 | 3 | 4
        // ── Dietary Restrictions ──────────────────────────────────────────────────
        // Dietary tags are now managed as a Modifier Template — see Modifier Templates page
        // ── Lead Time & Delivery ──────────────────────────────────────────────────
        'lead_time_hours'  => '24',      // minimum hours before order date/time
        'delivery_tiers'   => '[]',      // JSON: [{over_miles:0,fee:0},{over_miles:5,fee:15}...]
        'store_lat'        => '',        // latitude for delivery distance calc
        'store_lng'        => '',        // longitude for delivery distance calc
        'gmaps_key'        => '',        // optional Google Maps API key for geocoding
        // ── Availability / Blackout Dates ─────────────────────────────────────────
        'pickup_closed_days'     => '',  // comma-separated: monday,tuesday,...
        'pickup_blocked_dates'   => '',  // comma-separated: 2026-12-25,2026-01-01,...
        'delivery_closed_days'   => '',
        'delivery_blocked_dates' => '',
        // ── Telemetry & Error Alerts ─────────────────────────────────────────────
        'telemetry_endpoint'    => '',
        'error_alert_email'     => '',
    );
}

function caterme_get_settings() {
    // Migrate from old option key on first run
    $old = get_option('boones_catering_settings');
    if ( $old && ! get_option('caterme_settings') ) {
        update_option('caterme_settings', $old);
        delete_option('boones_catering_settings');
    }
    $settings = wp_parse_args( get_option( 'caterme_settings', array() ), caterme_defaults() );
    // Coerce all values to strings — prevents strpos/ltrim deprecations on PHP 8.1+
    foreach ( $settings as $k => $v ) {
        if ( $v === null ) $settings[$k] = '';
    }
    return $settings;
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN MENU
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'admin_menu', function() {
    add_menu_page(
        "CaterMe",
        "CaterMe",
        'manage_options',
        'caterme-orders',
        'caterme_orders_page',
        'dashicons-clipboard',
        30
    );
    add_submenu_page(
        'caterme-orders',
        'All Orders',
        'All Orders',
        'manage_options',
        'caterme-orders',
        'caterme_orders_page'
    );
    // WC products are the menu — link directly into WC product list
    add_submenu_page(
        'caterme-orders',
        'Products (Menu)',
        '🍽️ Products (Menu)',
        'manage_options',
        'edit.php?post_type=product',
        null
    );
    add_submenu_page(
        'caterme-orders',
        'Modifier Templates',
        '🔧 Modifier Templates',
        'manage_options',
        'caterme-modifiers',
        'caterme_modifiers_page'
    );
    add_submenu_page(
        'caterme-orders',
        'Settings',
        'Settings',
        'manage_options',
        'caterme-settings',
        'caterme_settings_page'
    );
});

// Hidden admin pages for create-order and email actions
add_action( 'admin_menu', function() {
    add_submenu_page( '', 'Create Order', 'Create Order', 'manage_options', 'caterme-create-order', 'caterme_create_order_page' );
});

// ─────────────────────────────────────────────────────────────────────────────
// PRINT INTERCEPT — fire before WP outputs admin chrome so we get a clean page
// ─────────────────────────────────────────────────────────────────────────────
add_action( 'admin_init', function() {
    if ( ( $_GET['page'] ?? '' ) !== 'caterme-print' ) return;

    // ── Feature gate: labels require beta or pro; invoices are free for all ────
    $print_type = $_GET['type'] ?? '';
    if ( $print_type === 'labels' && ! caterme_has_feature( 'label_printing' ) ) {
        ?><!DOCTYPE html><html><head><title>Feature Locked</title>
        <style>body{font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f9f7f4;}
        .box{max-width:480px;text-align:center;padding:40px;background:#fff;border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,.08);}
        h2{color:#1a1208;margin-bottom:8px;}p{color:#555;line-height:1.5;}
        a{display:inline-block;margin-top:20px;background:#c8522a;color:#fff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;}</style>
        </head><body><div class="box">
        <div style="font-size:48px;margin-bottom:16px;">🔒</div>
        <h2>Label Printing is a Beta/Pro Feature</h2>
        <p>Upgrade your plan to unlock label printing, kitchen tickets, menu photos, and more.</p>
        <a href="<?php echo esc_url( admin_url('admin.php?page=caterme-settings&tab=plan') ); ?>">View Plans →</a>
        </div></body></html><?php
        exit;
    }
    if ( ! current_user_can('manage_options') ) wp_die('Unauthorized.');

    $order_id = absint( $_GET['order_id'] ?? 0 );
    $type     = sanitize_text_field( $_GET['type'] ?? 'invoice' );
    $nonce    = sanitize_text_field( $_GET['_wpnonce'] ?? '' );

    if ( ! $order_id || ! wp_verify_nonce($nonce, 'caterme_print_'.$order_id) ) {
        wp_die('Invalid request.');
    }

    global $wpdb;
    $orders_table = $wpdb->prefix . 'caterme_orders';
    $items_table  = $wpdb->prefix . 'caterme_order_items';
    $order = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$orders_table} WHERE id=%d", $order_id) );
    $items = $wpdb->get_results( $wpdb->prepare("SELECT * FROM {$items_table} WHERE order_id=%d ORDER BY id ASC", $order_id) );
    $s     = caterme_get_settings();

    if ( ! $order ) wp_die('Order not found.');

    if ( $type === 'labels' ) {
        caterme_track_event( 'label_printed', array( 'order_number' => $order->order_number ) );
        caterme_print_labels( $order, $items, $s );
    } else {
        caterme_track_event( 'invoice_printed', array( 'order_number' => $order->order_number ) );
        caterme_print_invoice( $order, $items, $s );
    }
    exit;
}, 1 );

// ─────────────────────────────────────────────────────────────────────────────
// ORDERS LIST PAGE
// ─────────────────────────────────────────────────────────────────────────────

function caterme_orders_page() {
    global $wpdb;
    $orders_table = $wpdb->prefix . 'caterme_orders';
    $items_table  = $wpdb->prefix . 'caterme_order_items';

    // Safety: create tables if missing
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$orders_table}'" ) !== $orders_table ) {
        caterme_create_tables();
        update_option( 'caterme_db_version', CATERME_DB_VERSION );
    }

    // Handle status update
    if ( isset($_POST['caterme_update_status'], $_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'caterme_status') ) {
        $order_id   = absint( $_POST['order_id'] ?? 0 );
        $new_status = sanitize_text_field( $_POST['new_status'] ?? 'new' );
        $allowed_statuses = array('new','confirmed','preparing','ready','completed','cancelled');
        if ( $order_id && in_array($new_status, $allowed_statuses) ) {
            $wpdb->update( $orders_table, array('status'=>$new_status), array('id'=>$order_id) );

            // Auto-capture on confirmation, auto-void on cancellation
            if ( caterme_wc_active() ) {
                $row = $wpdb->get_row( $wpdb->prepare("SELECT wc_order_id, payment_status FROM {$orders_table} WHERE id=%d", $order_id) );
                if ( $row && $row->wc_order_id ) {
                    if ( $new_status === 'confirmed' && $row->payment_status === 'authorized' ) {
                        $result = caterme_capture_wc_payment( $row->wc_order_id );
                        if ( $result ) {
                            $wpdb->update( $orders_table, array('payment_status'=>'captured'), array('id'=>$order_id) );
                            caterme_notify_order_confirmed( $order_id );
                            echo '<div class="notice notice-success is-dismissible"><p>Order confirmed and payment captured. Notification emails sent.</p></div>';
                        } else {
                            echo '<div class="notice notice-warning is-dismissible"><p>Order confirmed but payment capture may need manual review in WooCommerce.</p></div>';
                        }
                    } elseif ( $new_status === 'cancelled' && in_array($row->payment_status, array('authorized','captured')) ) {
                        caterme_void_wc_payment( $row->wc_order_id );
                        $wpdb->update( $orders_table, array('payment_status'=>in_array($row->payment_status,array('captured')) ? 'refunded' : 'voided'), array('id'=>$order_id) );
                        echo '<div class="notice notice-info is-dismissible"><p>Order cancelled and payment voided/refunded.</p></div>';
                    } else {
                        echo '<div class="notice notice-success is-dismissible"><p>Order status updated.</p></div>';
                    }
                } else {
                    echo '<div class="notice notice-success is-dismissible"><p>Order status updated.</p></div>';
                }
            } else {
                echo '<div class="notice notice-success is-dismissible"><p>Order status updated.</p></div>';
            }
        }
    }

    // Handle manual capture
    if ( isset($_POST['caterme_capture_payment'], $_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'caterme_payment_action') ) {
        $order_id = absint( $_POST['order_id'] ?? 0 );
        $row = $wpdb->get_row( $wpdb->prepare("SELECT wc_order_id FROM {$orders_table} WHERE id=%d", $order_id) );
        if ( $row && $row->wc_order_id && caterme_capture_wc_payment($row->wc_order_id) ) {
            $wpdb->update( $orders_table, array('payment_status'=>'captured','status'=>'confirmed'), array('id'=>$order_id) );
            echo '<div class="notice notice-success is-dismissible"><p>Payment captured successfully.</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Capture failed — check WooCommerce for details.</p></div>';
        }
    }

    // Handle manual void
    if ( isset($_POST['caterme_void_payment'], $_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'caterme_payment_action') ) {
        $order_id = absint( $_POST['order_id'] ?? 0 );
        $row = $wpdb->get_row( $wpdb->prepare("SELECT wc_order_id FROM {$orders_table} WHERE id=%d", $order_id) );
        if ( $row && $row->wc_order_id && caterme_void_wc_payment($row->wc_order_id) ) {
            $wpdb->update( $orders_table, array('payment_status'=>'voided'), array('id'=>$order_id) );
            echo '<div class="notice notice-success is-dismissible"><p>Payment hold voided.</p></div>';
        }
    }

    // Handle manual refund
    if ( isset($_POST['caterme_refund_payment'], $_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'caterme_payment_action') ) {
        $order_id = absint( $_POST['order_id'] ?? 0 );
        $row = $wpdb->get_row( $wpdb->prepare("SELECT wc_order_id FROM {$orders_table} WHERE id=%d", $order_id) );
        if ( $row && $row->wc_order_id ) {
            caterme_void_wc_payment( $row->wc_order_id ); // handles refund for captured payments
            $wpdb->update( $orders_table, array('payment_status'=>'refunded'), array('id'=>$order_id) );
            echo '<div class="notice notice-success is-dismissible"><p>Refund issued.</p></div>';
        }
    }

    // Handle delete
    if ( isset($_POST['caterme_delete_order'], $_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'caterme_delete') ) {
        $order_id = absint( $_POST['order_id'] ?? 0 );
        if ( $order_id ) {
            $wpdb->delete( $items_table,  array('order_id' => $order_id) );
            $wpdb->delete( $orders_table, array('id'       => $order_id) );
            echo '<div class="notice notice-success is-dismissible"><p>Order deleted.</p></div>';
        }
    }

    // View single order
    $view_id = absint( $_GET['view'] ?? 0 );
    if ( $view_id ) {
        // Initialize session for sort preferences
        if ( ! session_id() ) {
            session_start();
        }
        
        $order = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$orders_table} WHERE id=%d", $view_id) );
        
        // Use the new sorting function
        $sort_by = $_GET['sort_items'] ?? $_SESSION['caterme_items_sort'] ?? 'original';
        $items = caterme_get_order_items_sorted( $view_id, $sort_by );
        
        if ( $order ) {
            caterme_render_order_detail( $order, $items, $sort_by );
            return;
        }
    }

    // List all orders
    $status_filter = sanitize_text_field( $_GET['status'] ?? '' );
    $search = sanitize_text_field( $_GET['s'] ?? '' );
    $per_page = 20;
    $page = max(1, absint($_GET['paged'] ?? 1));
    $offset = ($page - 1) * $per_page;

    $where = '1=1';
    $params = array();
    if ( $status_filter ) { $where .= ' AND status=%s'; $params[] = $status_filter; }
    if ( $search ) { $where .= ' AND (order_number LIKE %s OR customer_name LIKE %s OR customer_email LIKE %s)'; $params[] = '%'.$search.'%'; $params[] = '%'.$search.'%'; $params[] = '%'.$search.'%'; }

    $sql = "SELECT * FROM {$orders_table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";
    $params[] = $per_page; $params[] = $offset;
    $orders = $params ? $wpdb->get_results( $wpdb->prepare($sql, $params) ) : $wpdb->get_results("SELECT * FROM {$orders_table} ORDER BY created_at DESC LIMIT {$per_page} OFFSET {$offset}");
    $total = $wpdb->get_var("SELECT COUNT(*) FROM {$orders_table} WHERE {$where}" . ($params && count($params)>2 ? '' : ''));

    $statuses = array('new'=>'🆕 New','confirmed'=>'✅ Confirmed','preparing'=>'👨‍🍳 Preparing','ready'=>'📦 Ready','completed'=>'✔️ Completed','cancelled'=>'❌ Cancelled');
    $status_colors = array('new'=>'#2271b1','confirmed'=>'#00a32a','preparing'=>'#d63638','ready'=>'#8c5e00','completed'=>'#787c82','cancelled'=>'#787c82');
    $s = caterme_get_settings();

    ?>
    <div class="wrap">
        <h1 style="display:flex;align-items:center;gap:10px;">🥡 CaterMe — Catering Orders
            <?php if ( caterme_has_feature('manual_order_create') ): ?>
            <a href="<?php echo admin_url('admin.php?page=caterme-create-order'); ?>" class="page-title-action" style="background:#c8832a;color:#fff;border-color:#c8832a;">+ New Order</a>
            <?php else: ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=caterme-settings&tab=plan')); ?>" class="page-title-action" style="background:#999;color:#fff;border-color:#999;" title="Manual order creation — Beta/Pro only">+ New Order 🔒</a>
            <?php endif; ?>
            <a href="<?php echo admin_url('admin.php?page=caterme-settings'); ?>" class="page-title-action">Settings</a>
        </h1>

        <?php if ( ! empty($_GET['created']) ): ?>
        <div class="notice notice-success is-dismissible"><p>✅ Order created successfully.</p></div>
        <?php endif; ?>

        <?php if ( ($s['test_mode'] ?? '0') === '1' ): ?>
        <div style="background:#fffbeb;border:2px solid #d97706;border-radius:8px;padding:12px 18px;margin-bottom:18px;display:flex;align-items:center;gap:12px;">
            <span style="font-size:22px;">🧪</span>
            <div>
                <strong style="color:#92400e;font-size:14px;">Test Mode is ON</strong>
                <p style="margin:2px 0 0;color:#92400e;font-size:13px;">Credit card processing is disabled. Orders submitted through the form will <strong>not</strong> trigger any WooCommerce payment flow. <a href="<?php echo admin_url('admin.php?page=caterme-settings'); ?>">Turn off Test Mode →</a></p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Filters -->
        <form method="get" style="display:flex;gap:10px;align-items:center;margin-bottom:16px;flex-wrap:wrap;">
            <input type="hidden" name="page" value="caterme-orders" />
            <input type="text" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search orders..." class="regular-text" />
            <select name="status">
                <option value="">All Statuses</option>
                <?php foreach ($statuses as $k=>$v): ?>
                <option value="<?php echo $k; ?>" <?php selected($status_filter,$k); ?>><?php echo esc_html($v); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="submit" value="Filter" class="button" />
        </form>

        <?php if (empty($orders)): ?>
            <div style="background:#fff;border:1px solid #e0d0b8;border-radius:8px;padding:40px;text-align:center;color:#888;">
                <div style="font-size:40px;margin-bottom:12px;">📋</div>
                <p>No orders found. Orders will appear here after customers submit the catering form.</p>
            </div>
        <?php else: ?>
        <table class="wp-list-table widefat fixed striped" style="border-radius:8px;overflow:hidden;">
            <thead>
                <tr>
                    <th style="width:90px;">Order #</th>
                    <th style="width:80px;">Status</th>
                    <th style="width:110px;">Payment</th>
                    <th>Customer</th>
                    <th style="width:90px;">Type</th>
                    <th style="width:110px;">Date/Time</th>
                    <th style="width:80px;">Total</th>
                    <th style="width:80px;">Created</th>
                    <th style="width:200px;">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $o): ?>
                <?php
                $color = $status_colors[$o->status] ?? '#787c82';
                $lbl   = $statuses[$o->status] ?? $o->status;
                $dt    = $o->order_date ? date('M j', strtotime($o->order_date)) . ($o->order_time ? ' '.date('g:ia', strtotime($o->order_time)) : '') : '—';
                ?>
                <tr>
                    <td><strong><a href="?page=caterme-orders&view=<?php echo $o->id; ?>"><?php echo esc_html($o->order_number); ?></a></strong></td>
                    <td><span style="background:<?php echo $color; ?>;color:#fff;border-radius:4px;padding:2px 7px;font-size:11px;white-space:nowrap;"><?php echo esc_html($lbl); ?></span></td>
                    <td><?php echo caterme_payment_badge( $o->payment_status ?? 'none' ); ?></td>
                    <td>
                        <?php echo esc_html($o->customer_name ?: '—'); ?>
                        <?php if($o->customer_email): ?><br><small style="color:#888;"><?php echo esc_html($o->customer_email); ?></small><?php endif; ?>
                    </td>
                    <td><?php echo $o->fulfillment === 'delivery' ? '🚗 Delivery' : '🏪 Pick Up'; ?></td>
                    <td><?php echo esc_html($dt); ?></td>
                    <td><strong>$<?php echo number_format($o->subtotal,2); ?></strong></td>
                    <td><?php echo date('M j', strtotime($o->created_at)); ?></td>
                    <td style="white-space:nowrap;">
                        <a href="?page=caterme-orders&view=<?php echo $o->id; ?>" class="button button-small">View</a>
                        <a href="<?php echo admin_url('admin.php?page=caterme-print&order_id='.$o->id.'&type=invoice&_wpnonce='.wp_create_nonce('caterme_print_'.$o->id)); ?>" class="button button-small" target="_blank" title="Print Invoice">🧾</a>
                        <?php if ( caterme_has_feature('label_printing') ): ?>
                        <a href="<?php echo admin_url('admin.php?page=caterme-print&order_id='.$o->id.'&type=labels&_wpnonce='.wp_create_nonce('caterme_print_'.$o->id)); ?>" class="button button-small" target="_blank" title="Print Labels">🏷️</a>
                        <?php else: ?><span class="button button-small" title="Label printing — Beta/Pro only" style="opacity:.4;cursor:not-allowed;">🏷️🔒</span><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}

// ─────────────────────────────────────────────────────────────────────────────
// ORDER DETAIL PAGE
// ─────────────────────────────────────────────────────────────────────────────

function caterme_render_order_detail( $order, $items, $sort_by = 'original' ) {
    global $wpdb;
    $settings = caterme_get_settings();
    $statuses = array('new'=>'New','confirmed'=>'Confirmed','preparing'=>'Preparing','ready'=>'Ready','completed'=>'Completed','cancelled'=>'Cancelled');
    $back_url = admin_url('admin.php?page=caterme-orders');
    $notice   = '';

    // Handle order field edit
    if ( isset($_POST['caterme_edit_order'], $_POST['_caterme_edit_nonce'], $_POST['order_id']) ) {
        $edit_order_id = absint( $_POST['order_id'] );
        if ( wp_verify_nonce($_POST['_caterme_edit_nonce'], 'caterme_edit_order_'.$edit_order_id) ) {
            $orders_table = $wpdb->prefix . 'caterme_orders';
            $items_table  = $wpdb->prefix . 'caterme_order_items';
            $updates = array();
            // Editable fields
            if ( isset($_POST['edit_customer_name']) )
                $updates['customer_name']  = sanitize_text_field( $_POST['edit_customer_name'] );
            if ( isset($_POST['edit_customer_phone']) )
                $updates['customer_phone'] = sanitize_text_field( $_POST['edit_customer_phone'] );
            if ( isset($_POST['edit_customer_email']) )
                $updates['customer_email'] = sanitize_email( $_POST['edit_customer_email'] );
            if ( isset($_POST['edit_fulfillment']) && in_array($_POST['edit_fulfillment'],array('pickup','delivery')) )
                $updates['fulfillment'] = $_POST['edit_fulfillment'];
            if ( isset($_POST['edit_order_date']) )
                $updates['order_date'] = sanitize_text_field( $_POST['edit_order_date'] ) ?: null;
            if ( isset($_POST['edit_order_time']) )
                $updates['order_time'] = sanitize_text_field( $_POST['edit_order_time'] ) ?: null;
            if ( isset($_POST['edit_notes']) )
                $updates['notes'] = sanitize_textarea_field( $_POST['edit_notes'] );
            if ( isset($_POST['edit_subtotal']) )
                $updates['subtotal'] = floatval( $_POST['edit_subtotal'] );
            if ( isset($_POST['edit_delivery_fee']) )
                $updates['delivery_fee'] = max( 0, floatval( $_POST['edit_delivery_fee'] ) );
            if ( isset($_POST['edit_tip']) )
                $updates['tip'] = floatval( $_POST['edit_tip'] );
            if ( ! empty($updates) ) {
                $wpdb->update( $orders_table, $updates, array('id' => $edit_order_id) );
            }
            // Handle item edits (qty, price, label_name, dietary, notes per item)
            if ( isset($_POST['item_qty']) && is_array($_POST['item_qty']) ) {
                foreach ( $_POST['item_qty'] as $item_id => $qty ) {
                    $item_id = absint($item_id);
                    $qty     = max(1, absint($qty));
                    $price   = floatval( $_POST['item_price'][$item_id] ?? 0 );
                    $lname   = sanitize_text_field( $_POST['item_label'][$item_id] ?? '' );
                    $diet    = sanitize_text_field( $_POST['item_dietary'][$item_id] ?? '' );
                    $wpdb->update( $items_table, array(
                        'qty'        => $qty,
                        'unit_price' => $price,
                        'line_total' => $price * $qty,
                        'label_name' => $lname,
                        'dietary'    => $diet,
                    ), array('id' => $item_id, 'order_id' => $edit_order_id) );
                }
            }
            // Handle item deletions
            if ( isset($_POST['delete_item']) && is_array($_POST['delete_item']) ) {
                foreach ( array_keys($_POST['delete_item']) as $del_id ) {
                    $wpdb->delete( $items_table, array('id' => absint($del_id), 'order_id' => $edit_order_id) );
                }
            }
            // Re-fetch order and items after edits
            $orders_table2 = $wpdb->prefix . 'caterme_orders';
            $order = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$orders_table2} WHERE id=%d", $edit_order_id) );
            $items = caterme_get_order_items_sorted( $edit_order_id, $sort_by );
            $notice = '<div class="notice notice-success is-dismissible"><p>✅ Order updated successfully.</p></div>';
        }
    }

    // Handle email actions
    if ( isset($_POST['caterme_email_action'], $_POST['_caterme_email_nonce'], $_POST['order_id']) ) {
        $action   = sanitize_text_field( $_POST['caterme_email_action'] );
        $order_id = absint( $_POST['order_id'] );
        if ( $action === 'quote' && wp_verify_nonce($_POST['_caterme_email_nonce'], 'caterme_send_quote_'.$order_id) ) {
            if ( ! caterme_has_feature('quote_email') ) {
                $result = '<div class="notice notice-error is-dismissible"><p>❌ Sending quote emails requires a Beta or Pro plan. <a href="' . admin_url('admin.php?page=caterme-settings&tab=plan') . '">Upgrade →</a></p></div>';
            } else {
            $result = caterme_send_quote_email( $order, $items, $settings );
            $notice = $result ? '<div class="notice notice-success is-dismissible"><p>✅ Quote sent to ' . esc_html($order->customer_email) . '</p></div>'
                              : '<div class="notice notice-error is-dismissible"><p>❌ Failed to send quote. Check your email settings.</p></div>';
        }
        if ( $action === 'payment_link' && wp_verify_nonce($_POST['_caterme_email_nonce'], 'caterme_send_payment_'.$order_id) ) {
            if ( ! caterme_has_feature('payment_link') ) {
                $result = '<div class="notice notice-error is-dismissible"><p>❌ Sending payment links requires a Beta or Pro plan. <a href="' . admin_url('admin.php?page=caterme-settings&tab=plan') . '">Upgrade →</a></p></div>';
            } else {
            $result = caterme_send_payment_link_email( $order, $items, $settings, $wpdb );
            $notice = $result === true ? '<div class="notice notice-success is-dismissible"><p>✅ Payment link sent to ' . esc_html($order->customer_email) . '</p></div>'
                                       : '<div class="notice notice-error is-dismissible"><p>❌ ' . esc_html($result) . '</p></div>';
            // Re-fetch order in case wc_order_id was updated
            $orders_table = $wpdb->prefix . 'caterme_orders';
            $order = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$orders_table} WHERE id=%d", $order->id) );
        }
    }
    ?>
    <div class="wrap">
        <?php echo $notice; ?>
        <h1>
            <a href="<?php echo $back_url; ?>" style="text-decoration:none;color:#888;font-size:14px;font-weight:400;">← All Orders</a><br>
            Order <?php echo esc_html($order->order_number); ?>
            <span style="font-size:13px;font-weight:400;color:#888;margin-left:12px;">placed <?php echo date('F j, Y g:i a', strtotime($order->created_at)); ?></span>
        </h1>

        <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;max-width:1000px;">

            <!-- Items Table -->
            <div>
                <?php 
                // Render sort controls
                caterme_render_items_sort_controls( $order->id, $sort_by );
                ?>
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#1a1208;color:#f5e6c8;padding:14px 18px;font-weight:700;font-size:14px;">Order Items</div>
                    <table class="wp-list-table widefat" style="border:none;">
                        <thead>
                            <tr style="background:#faf7f2;">
                                <th>Item</th>
                                <th style="width:40px;text-align:center;">Qty</th>
                                <th style="width:80px;text-align:right;">Unit $</th>
                                <th style="width:80px;text-align:right;">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php caterme_render_items_with_grouping( $items, $sort_by ); ?>
                        </tbody>
                        <tfoot>
                            <tr style="background:#faf7f2;">
                                <td colspan="3" style="text-align:right;font-weight:600;font-size:13px;padding:8px 14px;">Subtotal:</td>
                                <td style="text-align:right;font-weight:700;font-size:14px;">$<?php echo number_format($order->subtotal,2); ?></td>
                            </tr>
                            <?php if ( $order->fulfillment === 'delivery' && floatval($order->delivery_fee??0) >= 0 ): ?>
                            <tr style="background:#faf7f2;">
                                <td colspan="3" style="text-align:right;font-weight:600;font-size:13px;padding:4px 14px;">Delivery Fee:</td>
                                <td style="text-align:right;font-weight:700;font-size:14px;"><?php echo floatval($order->delivery_fee??0) > 0 ? '$'.number_format($order->delivery_fee,2) : '<span style="color:#888;">$0.00</span>'; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ( floatval($order->tax??0) > 0 ): ?>
                            <tr style="background:#faf7f2;">
                                <td colspan="3" style="text-align:right;font-weight:600;font-size:13px;padding:4px 14px;">Tax:</td>
                                <td style="text-align:right;font-weight:700;font-size:14px;">$<?php echo number_format(floatval($order->tax),2); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ( !empty($order->tip) && floatval($order->tip) > 0 ): ?>
                            <tr style="background:#faf7f2;">
                                <td colspan="3" style="text-align:right;font-weight:600;font-size:13px;padding:4px 14px;">Tip:</td>
                                <td style="text-align:right;font-weight:700;font-size:14px;">$<?php echo number_format($order->tip,2); ?></td>
                            </tr>
                            <tr style="background:#f0ebe0;">
                                <td colspan="3" style="text-align:right;font-weight:700;font-size:15px;padding:8px 14px;border-top:1px solid #ddd0b8;">Order Total:</td>
                                <td style="text-align:right;font-weight:900;font-size:16px;color:#c8832a;border-top:1px solid #ddd0b8;">$<?php echo number_format($order->subtotal + floatval($order->delivery_fee??0) + floatval($order->tax??0) + floatval($order->tip),2); ?></td>
                            </tr>
                            <?php else: ?>
                            <tr style="background:#faf7f2;">
                                <td colspan="3" style="text-align:right;font-weight:700;font-size:15px;padding:8px 14px;">Order Total:</td>
                                <td style="text-align:right;font-weight:900;font-size:16px;color:#c8832a;">$<?php echo number_format($order->subtotal + floatval($order->delivery_fee??0) + floatval($order->tax??0),2); ?><?php echo (floatval($order->tax??0) == 0 && !$order->wc_order_id) ? '+' : ''; ?></td>
                            </tr>
                            <?php endif; ?>
                        </tfoot>
                    </table>
                    <?php if ($order->notes): ?>
                        <div style="padding:14px 18px;border-top:1px solid #f0e8d8;background:#fffdf8;">
                            <strong style="font-size:12px;text-transform:uppercase;letter-spacing:1px;color:#a07848;">Notes</strong>
                            <p style="margin:5px 0 0;font-size:13px;color:#444;line-height:1.6;"><?php echo nl2br(esc_html($order->notes)); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sidebar -->
            <div style="display:flex;flex-direction:column;gap:14px;">

                <!-- Status -->
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Order Status</div>
                    <div style="padding:14px 16px;">
                        <?php if ( caterme_wc_active() && ($order->payment_status??'none') === 'authorized' ): ?>
                        <div style="background:#fff7ed;border:1px solid #f6d28a;border-radius:6px;padding:9px 12px;font-size:12px;color:#8c5e00;margin-bottom:10px;">
                            💳 Card pre-authorized. Setting to <strong>Confirmed</strong> will automatically capture payment.
                        </div>
                        <?php endif; ?>
                        <form method="post">
                            <?php wp_nonce_field('caterme_status'); ?>
                            <input type="hidden" name="order_id" value="<?php echo $order->id; ?>" />
                            <select name="new_status" style="width:100%;margin-bottom:8px;padding:7px;">
                                <?php foreach ($statuses as $k=>$v): ?>
                                <option value="<?php echo $k; ?>" <?php selected($order->status,$k); ?>><?php echo esc_html($v); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="caterme_update_status" class="button button-primary" style="width:100%;">Update Status</button>
                        </form>
                    </div>
                </div>

                <!-- Payment -->
                <?php if ( caterme_wc_active() ): ?>
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">
                        💳 Payment
                        <span style="float:right;margin-top:1px;"><?php echo caterme_payment_badge( $order->payment_status ?? 'none' ); ?></span>
                    </div>
                    <div style="padding:14px 16px;">
                        <?php echo caterme_payment_actions_html( $order, $order->wc_order_id ?? null ); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Fulfillment -->
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Fulfillment</div>
                    <div style="padding:14px 16px;font-size:13px;line-height:1.8;">
                        <div><?php echo $order->fulfillment === 'delivery' ? '🚗 <strong>Delivery</strong>' : '🏪 <strong>Pick Up</strong>'; ?></div>
                        <?php if ($order->order_date): ?>
                        <div>📅 <?php echo date('l, F j, Y', strtotime($order->order_date)); ?></div>
                        <?php endif; ?>
                        <?php if ($order->order_time): ?>
                        <div>⏰ <?php echo date('g:i a', strtotime($order->order_time)); ?></div>
                        <?php endif; ?>
                        <?php if ( $order->fulfillment === 'delivery' && !empty($order->delivery_address) ): ?>
                        <div style="margin-top:4px;font-size:12px;color:#888;line-height:1.5;">📍 <?php echo esc_html($order->delivery_address); ?></div>
                        <?php endif; ?>
                        <?php if ( $order->fulfillment === 'delivery' ): ?>
                        <div style="margin-top:4px;font-size:12px;font-weight:600;">🚗 Delivery Fee: $<?php echo number_format(floatval($order->delivery_fee??0),2); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Customer -->
                <?php if ($order->customer_name || $order->customer_email || $order->customer_phone): ?>
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Customer</div>
                    <div style="padding:14px 16px;font-size:13px;line-height:1.8;">
                        <?php if($order->customer_name): ?><div>👤 <?php echo esc_html($order->customer_name); ?></div><?php endif; ?>
                        <?php if($order->customer_phone): ?><div>📞 <?php echo esc_html($order->customer_phone); ?></div><?php endif; ?>
                        <?php if($order->customer_email): ?><div>✉️ <?php echo esc_html($order->customer_email); ?></div><?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Email Actions -->
                <?php if ( $order->customer_email ): ?>
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">📧 Email Customer</div>
                    <div style="padding:14px 16px;display:flex;flex-direction:column;gap:8px;">
                        <?php
                        $quote_nonce   = wp_create_nonce('caterme_send_quote_'.$order->id);
                        $payment_nonce = wp_create_nonce('caterme_send_payment_'.$order->id);
                        ?>
                        <form method="post">
                            <?php if ( ! caterme_has_feature('quote_email') ): ?>
                            <p style="color:#999;font-size:12px;margin:0;">📨 Quote Email — <a href="<?php echo esc_url(admin_url('admin.php?page=caterme-settings&tab=plan')); ?>">Beta/Pro only 🔒</a></p>
                            <?php else: ?>
                            <?php wp_nonce_field('caterme_send_quote_'.$order->id, '_caterme_email_nonce'); ?>
                            <input type="hidden" name="caterme_email_action" value="quote" />
                            <input type="hidden" name="order_id" value="<?php echo $order->id; ?>" />
                            <button type="submit" class="button" style="width:100%;text-align:center;">
                                📋 Send Quote to <?php echo esc_html($order->customer_email); ?>
                            </button>
                        </form>
                        <?php if ( caterme_wc_active() && ($settings['wc_enabled']??'1') === '1' && ($settings['test_mode']??'0') !== '1' ): ?>
                        <form method="post">
                            <?php endif; // quote_email feature ?>
                            <?php if ( caterme_has_feature('payment_link') ): ?>
                            <?php wp_nonce_field('caterme_send_payment_'.$order->id, '_caterme_email_nonce'); ?>
                            <input type="hidden" name="caterme_email_action" value="payment_link" />
                            <?php endif; // payment_link feature ?>
                            <input type="hidden" name="order_id" value="<?php echo $order->id; ?>" />
                            <button type="submit" class="button button-primary" style="width:100%;text-align:center;">
                                💳 Send Payment Link
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Print Actions -->
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Print</div>
                    <div style="padding:14px 16px;display:flex;flex-direction:column;gap:8px;">
                        <a href="<?php echo admin_url('admin.php?page=caterme-print&order_id='.$order->id.'&type=invoice&_wpnonce='.wp_create_nonce('caterme_print_'.$order->id)); ?>" target="_blank" class="button" style="text-align:center;">🧾 Print Invoice</a>
                        <?php if ( caterme_has_feature('label_printing') ): ?>
                        <a href="<?php echo admin_url('admin.php?page=caterme-print&order_id='.$order->id.'&type=labels&_wpnonce='.wp_create_nonce('caterme_print_'.$order->id)); ?>" target="_blank" class="button" style="text-align:center;">🏷️ Print Item Labels</a>
                        <?php else: ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=caterme-settings&tab=plan')); ?>" class="button" style="text-align:center;opacity:.6;" title="Upgrade to Beta/Pro">🏷️ Labels 🔒</a>
                        <?php endif; ?>
                        
                        <div style="border-top: 1px solid #e0d0b8; margin: 8px 0; padding-top: 8px;">
                            <div style="font-size: 11px; color: #888; margin-bottom: 6px; font-weight: 600;">KITCHEN TICKETS:</div>
                            <?php if ( caterme_has_feature('kitchen_tickets') ): ?>
                            <a href="<?php echo admin_url('admin.php?page=caterme-kitchen-tickets&order_id='.$order->id.'&format=prep_sheet&sort='.($sort_by ?? 'type_dietary')); ?>" target="_blank" class="button" style="text-align:center;font-size:12px;">👨‍🍳 Prep Sheet</a>
                            <a href="<?php echo admin_url('admin.php?page=caterme-kitchen-tickets&order_id='.$order->id.'&format=summary&sort='.($sort_by ?? 'type_dietary')); ?>" target="_blank" class="button" style="text-align:center;font-size:12px;margin-top:4px;">📊 Summary</a>
                            <a href="<?php echo admin_url('admin.php?page=caterme-kitchen-tickets&order_id='.$order->id.'&format=individual&sort='.($sort_by ?? 'type_dietary')); ?>" target="_blank" class="button" style="text-align:center;font-size:12px;margin-top:4px;">🎫 Individual Tickets</a>
                            <?php else: ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=caterme-settings&tab=plan')); ?>" class="button" style="text-align:center;font-size:12px;opacity:.6;">👨‍🍳 Kitchen Tickets 🔒</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Edit Order Panel -->
                <?php
                $can_edit = in_array($order->status, array('new','confirmed'));
                if ( $can_edit ):
                    $edit_nonce = wp_create_nonce('caterme_edit_order_'.$order->id);
                ?>
                <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                    <div style="background:#4a3010;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;display:flex;justify-content:space-between;align-items:center;">
                        ✏️ Edit Order
                        <button type="button" onclick="this.closest('[data-editpanel]').querySelector('[data-editbody]').classList.toggle('cm-hidden')" style="background:none;border:none;color:#f5e6c8;cursor:pointer;font-size:12px;font-weight:400;opacity:0.8;">▼ Expand</button>
                    </div>
                    <div data-editpanel="1">
                        <div data-editbody="1" class="cm-hidden" style="padding:14px 16px;">
                            <form method="post">
                                <?php wp_nonce_field('caterme_edit_order_'.$order->id, '_caterme_edit_nonce'); ?>
                                <input type="hidden" name="order_id" value="<?php echo $order->id; ?>" />
                                <input type="hidden" name="caterme_edit_order" value="1" />

                                <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;margin:0 0 10px;">Customer Info</p>
                                <input type="text" name="edit_customer_name" value="<?php echo esc_attr($order->customer_name); ?>" placeholder="Name" style="width:100%;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;margin-bottom:6px;box-sizing:border-box;" />
                                <input type="tel" name="edit_customer_phone" value="<?php echo esc_attr($order->customer_phone); ?>" placeholder="Phone" style="width:100%;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;margin-bottom:6px;box-sizing:border-box;" />
                                <input type="email" name="edit_customer_email" value="<?php echo esc_attr($order->customer_email); ?>" placeholder="Email" style="width:100%;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;margin-bottom:12px;box-sizing:border-box;" />

                                <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;margin:0 0 10px;">Fulfillment</p>
                                <div style="display:flex;gap:8px;margin-bottom:6px;">
                                    <label style="flex:1;text-align:center;border:1px solid <?php echo $order->fulfillment==='pickup'?'#c8832a':'#ddd'; ?>;border-radius:6px;padding:6px;cursor:pointer;font-size:12px;<?php echo $order->fulfillment==='pickup'?'background:#fff7ed;color:#c8832a;font-weight:700;':''; ?>">
                                        <input type="radio" name="edit_fulfillment" value="pickup" <?php checked($order->fulfillment,'pickup'); ?> style="display:none;"> 🏪 Pick Up
                                    </label>
                                    <label style="flex:1;text-align:center;border:1px solid <?php echo $order->fulfillment==='delivery'?'#c8832a':'#ddd'; ?>;border-radius:6px;padding:6px;cursor:pointer;font-size:12px;<?php echo $order->fulfillment==='delivery'?'background:#fff7ed;color:#c8832a;font-weight:700;':''; ?>">
                                        <input type="radio" name="edit_fulfillment" value="delivery" <?php checked($order->fulfillment,'delivery'); ?> style="display:none;"> 🚗 Delivery
                                    </label>
                                </div>
                                <div style="display:flex;gap:6px;margin-bottom:12px;">
                                    <input type="date" name="edit_order_date" value="<?php echo esc_attr($order->order_date); ?>" style="flex:1;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;" />
                                    <input type="time" name="edit_order_time" value="<?php echo esc_attr(substr($order->order_time??'',0,5)); ?>" style="flex:1;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;" />
                                </div>

                                <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;margin:0 0 10px;">Totals</p>
                                <div style="display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap;">
                                    <label style="flex:1;font-size:12px;color:#666;min-width:80px;">Subtotal<br>
                                        <input type="number" name="edit_subtotal" value="<?php echo esc_attr(number_format($order->subtotal,2,'.','')); ?>" step="0.01" min="0" style="width:100%;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;margin-top:3px;" />
                                    </label>
                                    <?php if ( $order->fulfillment === 'delivery' ): ?>
                                    <label style="flex:1;font-size:12px;color:#666;min-width:80px;">Delivery Fee<br>
                                        <input type="number" name="edit_delivery_fee" value="<?php echo esc_attr(number_format(floatval($order->delivery_fee??0),2,'.','')); ?>" step="0.01" min="0" style="width:100%;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;margin-top:3px;" />
                                    </label>
                                    <?php endif; ?>
                                    <label style="flex:1;font-size:12px;color:#666;min-width:80px;">Tip<br>
                                        <input type="number" name="edit_tip" value="<?php echo esc_attr(number_format(floatval($order->tip??0),2,'.','')); ?>" step="0.01" min="0" style="width:100%;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;margin-top:3px;" />
                                    </label>
                                </div>

                                <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;margin:0 0 6px;">Line Items</p>
                                <?php foreach ( $items as $li ): ?>
                                <div style="background:#faf7f2;border:1px solid #e8dcc8;border-radius:6px;padding:8px 10px;margin-bottom:8px;">
                                    <div style="font-size:12px;font-weight:700;color:#1a1208;margin-bottom:5px;"><?php echo esc_html($li->item_name); ?></div>
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;font-size:11px;color:#666;">
                                        <label>Qty<br><input type="number" name="item_qty[<?php echo $li->id; ?>]" value="<?php echo (int)$li->qty; ?>" min="1" style="width:100%;border:1px solid #ddd;border-radius:4px;padding:4px 6px;font-size:12px;" /></label>
                                        <label>Unit $<br><input type="number" name="item_price[<?php echo $li->id; ?>]" value="<?php echo esc_attr(number_format($li->unit_price,2,'.','')); ?>" step="0.01" min="0" style="width:100%;border:1px solid #ddd;border-radius:4px;padding:4px 6px;font-size:12px;" /></label>
                                        <label>Label Name<br><input type="text" name="item_label[<?php echo $li->id; ?>]" value="<?php echo esc_attr($li->label_name); ?>" style="width:100%;border:1px solid #ddd;border-radius:4px;padding:4px 6px;font-size:12px;" /></label>
                                        <label>Dietary<br><input type="text" name="item_dietary[<?php echo $li->id; ?>]" value="<?php echo esc_attr($li->dietary); ?>" style="width:100%;border:1px solid #ddd;border-radius:4px;padding:4px 6px;font-size:12px;" /></label>
                                    </div>
                                    <label style="display:flex;align-items:center;gap:5px;margin-top:5px;font-size:11px;color:#c33;">
                                        <input type="checkbox" name="delete_item[<?php echo $li->id; ?>]" value="1"> Remove this item
                                    </label>
                                </div>
                                <?php endforeach; ?>

                                <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;margin:0 0 6px;">Notes</p>
                                <textarea name="edit_notes" rows="3" style="width:100%;border:1px solid #ddd;border-radius:6px;padding:6px 9px;font-size:13px;resize:none;box-sizing:border-box;margin-bottom:10px;"><?php echo esc_textarea($order->notes??''); ?></textarea>

                                <button type="submit" class="button button-primary" style="width:100%;">💾 Save Changes</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Delete -->
                <form method="post" onsubmit="return confirm('Delete this order permanently?');">
                    <?php wp_nonce_field('caterme_delete'); ?>
                    <input type="hidden" name="order_id" value="<?php echo $order->id; ?>" />
                    <button type="submit" name="caterme_delete_order" class="button" style="color:#cc0000;border-color:#cc0000;width:100%;">🗑️ Delete Order</button>
                </form>
            </div>
        </div>
    </div>
    <?php
}

// ─────────────────────────────────────────────────────────────────────────────
// EMAIL HELPERS — Quote & Payment Link
// ─────────────────────────────────────────────────────────────────────────────

function caterme_send_quote_email( $order, $items, $s ) {
    if ( empty($order->customer_email) ) return false;
    $store_name = $s['store_name'] ?? 'My Catering Co.';
    $subject    = "Your Catering Quote — Order {$order->order_number}";
    $body       = caterme_quote_email_html( $order, $items, $s, null );
    $headers    = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $store_name . ' <' . ($s['store_email'] ?? '') . '>',
    );
    return wp_mail( $order->customer_email, $subject, $body, $headers );
}

function caterme_send_payment_link_email( $order, $items, $s, $wpdb ) {
    if ( empty($order->customer_email) ) return 'No customer email on file.';
    if ( ! caterme_wc_active() )         return 'WooCommerce is not active.';

    $orders_table = $wpdb->prefix . 'caterme_orders';

    // Create or retrieve WC order
    $wc_order_id = $order->wc_order_id ?? null;
    if ( ! $wc_order_id ) {
        $wc_data = array(
            'order_number'   => $order->order_number,
            'fulfillment'    => $order->fulfillment,
            'orderDate'      => $order->order_date,
            'orderTime'      => $order->order_time,
            'subtotal'       => $order->subtotal,
            'customer_name'  => $order->customer_name,
            'customer_phone' => $order->customer_phone,
            'customer_email' => $order->customer_email,
            'notes'          => $order->notes,
        );
        $wc_order_id = caterme_create_wc_order( $order->id, $wc_data, array_map( function($i) {
            return array(
                'name'       => $i->item_name,
                'qty'        => $i->qty,
                'price'      => $i->unit_price,
                'selections' => json_decode($i->selections, true) ?: array(),
            );
        }, $items ) );
        if ( is_wp_error($wc_order_id) ) return $wc_order_id->get_error_message();
        $wpdb->update( $orders_table,
            array( 'wc_order_id' => $wc_order_id, 'payment_status' => 'pending' ),
            array( 'id' => $order->id )
        );
    }

    $return_url  = home_url('/');
    $payment_url = caterme_get_wc_payment_url( $wc_order_id, $return_url );
    if ( ! $payment_url ) return 'Could not generate payment URL. Check WooCommerce settings.';

    $store_name = $s['store_name'] ?? 'My Catering Co.';
    $subject    = "Complete Your Payment — Order {$order->order_number}";
    $body       = caterme_quote_email_html( $order, $items, $s, $payment_url );
    $headers    = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $store_name . ' <' . ($s['store_email'] ?? '') . '>',
    );
    $sent = wp_mail( $order->customer_email, $subject, $body, $headers );
    return $sent ? true : 'wp_mail() returned false. Check your mail configuration.';
}

function caterme_quote_email_html( $order, $items, $s, $payment_url = null ) {
    $store_name        = esc_html( $s['store_name']           ?? 'My Catering Co.' );
    $store_email       = esc_html( $s['store_email']          ?? '' );
    $store_phone       = esc_html( $s['store_phone']          ?? '' );
    $logo_url          = $s['logo_url']                       ?? '';
    $email_logo_height = (int)($s['email_logo_height']        ?? 56);
    $email_logo_align  = $s['email_logo_align']               ?? 'center';
    $email_font        = $s['email_font']                     ?? 'Georgia, serif';
    $email_size        = (int)($s['email_font_size']          ?? 14);
    $hdr_color         = $s['email_color_header']             ?? '#1a1208';
    $acc_color         = $s['email_color_accent']             ?? '#c8832a';
    $txt_color         = $s['email_color_text']               ?? '#1a1208';
    $dt = '';
    if ( $order->order_date ) $dt .= date('l, F j, Y', strtotime($order->order_date));
    if ( $order->order_time ) $dt .= ' at ' . date('g:i a', strtotime($order->order_time));
    $fulfillment_label = $order->fulfillment === 'delivery' ? '🚗 Delivery' : '🏪 Pick Up';

    $rows = '';
    foreach ( $items as $item ) {
        // Parse selections properly — skip false toggles, dietary key, nested arrays
        $raw_sels = json_decode($item->selections, true) ?: array();
        $sel_parts = array();
        foreach ( $raw_sels as $key => $val ) {
            if ( $key === 'dietary' )                             continue;
            if ( $val === false || $val === 0 || $val === '' )   continue;
            if ( is_array($val) )                                 continue;
            if ( $val === true ) { $sel_parts[] = ucfirst(str_replace('_',' ',$key)); continue; }
            $sel_parts[] = (string)$val;
        }
        $sel_str = implode(', ', $sel_parts);

        $rows .= '<tr>
            <td style="padding:10px 14px;border-bottom:1px solid #f0e8d8;vertical-align:top;">
                <strong>' . esc_html($item->item_name) . '</strong>'
                . ( $item->label_name ? '<br><span style="font-size:12px;color:' . esc_attr($acc_color) . ';">🏷️ ' . esc_html($item->label_name) . '</span>' : '' )
                . ( $sel_str ? '<br><span style="font-size:12px;color:#666;">' . esc_html($sel_str) . '</span>' : '' )
                . ( $item->dietary ? '<br><span style="font-size:11px;font-weight:700;color:' . esc_attr($acc_color) . ';">⚠️ ' . esc_html($item->dietary) . '</span>' : '' )
            . '</td>
            <td style="padding:10px 14px;border-bottom:1px solid #f0e8d8;text-align:center;vertical-align:top;">' . (int)$item->qty . '</td>
            <td style="padding:10px 14px;border-bottom:1px solid #f0e8d8;text-align:right;vertical-align:top;">$' . number_format($item->line_total, 2) . '</td>
        </tr>';
    }

    $notes_block = $order->notes
        ? '<div style="background:#fffdf8;border:1px solid #f0e8d8;border-radius:8px;padding:14px 18px;margin-top:16px;">
               <strong style="font-size:12px;text-transform:uppercase;letter-spacing:1px;color:#a07848;">Order Notes</strong>
               <p style="margin:6px 0 0;font-size:13px;color:#444;line-height:1.6;">' . nl2br(esc_html($order->notes)) . '</p>
           </div>'
        : '';

    // Logo block for email header — alignment controlled by settings
    $logo_max_w    = min(280, $email_logo_height * 5);
    $align_css     = array('left'=>'left','center'=>'center','right'=>'right')[$email_logo_align] ?? 'center';
    $logo_block    = $logo_url
        ? '<div style="margin-bottom:10px;text-align:' . $align_css . ';"><img src="' . esc_url($logo_url) . '" alt="' . $store_name . '" style="max-height:' . $email_logo_height . 'px;max-width:' . $logo_max_w . 'px;height:auto;width:auto;display:inline-block;object-fit:contain;" /></div>'
        : '<h1 style="color:#f5e6c8;font-size:26px;font-weight:900;letter-spacing:2px;text-transform:uppercase;margin:0 0 6px;font-family:' . esc_attr($email_font) . ';text-align:' . $align_css . ';">' . $store_name . '</h1>';

    return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="font-family:' . esc_attr($email_font) . ';color:' . esc_attr($txt_color) . ';background:#f5f0e8;margin:0;padding:30px 0;">
<div style="max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">

  <!-- Header -->
  <div style="background:' . esc_attr($hdr_color) . ';padding:22px 30px;text-align:' . $align_css . ';">
    ' . $logo_block . '
    <p style="color:#b8996a;font-size:11px;letter-spacing:2px;text-transform:uppercase;margin:0;">' . ($payment_url ? 'Payment Request' : 'Catering Quote') . '</p>
  </div>

  <!-- Body -->
  <div style="padding:28px 30px;font-family:' . esc_attr($email_font) . ';color:' . esc_attr($txt_color) . ';">
    <p style="font-size:' . $email_size . 'px;margin-top:0;">Hi ' . esc_html($order->customer_name ?: 'there') . ',</p>
    <p style="font-size:' . ($email_size - 1) . 'px;color:#555;margin-bottom:20px;">' . ($payment_url ? 'Your catering order is confirmed. Please complete your payment using the button below.' : 'Here is your catering quote. Please review the details below.') . '</p>

    <div style="background:#faf7f2;border:1px solid #e8dcc8;border-radius:8px;padding:14px 18px;margin-bottom:20px;font-size:' . ($email_size - 1) . 'px;line-height:1.8;">
      <div><strong>Order #:</strong> ' . esc_html($order->order_number) . '</div>
      ' . ($dt ? '<div><strong>Date/Time:</strong> ' . esc_html($dt) . '</div>' : '') . '
      <div><strong>Fulfillment:</strong> ' . $fulfillment_label . '</div>
    </div>

    <table style="width:100%;border-collapse:collapse;border:1px solid #e8dcc8;border-radius:8px;overflow:hidden;">
      <thead>
        <tr style="background:' . esc_attr($hdr_color) . ';color:#f5e6c8;">
          <th style="padding:10px 14px;text-align:left;font-size:13px;font-family:' . esc_attr($email_font) . ';">Item &amp; Selections</th>
          <th style="padding:10px 14px;text-align:center;font-size:13px;">Qty</th>
          <th style="padding:10px 14px;text-align:right;font-size:13px;">Amount</th>
        </tr>
      </thead>
      <tbody>' . $rows . '</tbody>
      <tfoot>
        <tr style="background:#faf7f2;">
          <td colspan="2" style="padding:12px 14px;text-align:right;font-weight:700;font-size:15px;">Subtotal:</td>
          <td style="padding:12px 14px;text-align:right;font-weight:900;font-size:16px;color:' . esc_attr($acc_color) . ';">$' . number_format($order->subtotal,2) . '+</td>
        </tr>
      </tfoot>
    </table>
    <p style="font-size:12px;color:#888;margin-top:6px;">+ Tax calculated at checkout.</p>

    ' . $notes_block . '

    ' . ( $payment_url
      ? '<div style="text-align:center;margin:30px 0;">
             <a href="' . esc_url($payment_url) . '" style="background:' . esc_attr($acc_color) . ';color:#fff;text-decoration:none;padding:14px 32px;border-radius:8px;font-size:16px;font-weight:700;display:inline-block;font-family:' . esc_attr($email_font) . ';">
                 💳 Complete Payment
             </a>
             <p style="font-size:12px;color:#888;margin-top:10px;">This link will take you to our secure checkout page.</p>
         </div>'
      : '<p style="color:#555;font-size:' . ($email_size - 1) . 'px;margin-top:16px;">We\'ll be in touch to confirm your order and arrange payment.</p>' )
    . '
  </div>

  <!-- Footer -->
  <div style="background:#faf7f2;border-top:1px solid #e8dcc8;padding:16px 30px;text-align:center;font-size:12px;color:#a07848;font-family:' . esc_attr($email_font) . ';">
    ' . $store_name . ($store_phone ? ' &middot; ' . esc_html($s['store_phone']) : '') . ($store_email ? ' &middot; ' . esc_html($s['store_email']) : '') . '
  </div>

</div>
</body></html>';
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN CREATE ORDER PAGE
// ─────────────────────────────────────────────────────────────────────────────

function caterme_create_order_page() {
    if ( ! caterme_has_feature( 'manual_order_create' ) ) {
        echo '<div class="wrap"><div style="max-width:520px;margin:60px auto;text-align:center;background:#fff;border-radius:16px;padding:40px;box-shadow:0 4px 24px rgba(0,0,0,.08);">';
        echo '<div style="font-size:48px;margin-bottom:16px;">🔒</div>';
        echo '<h2 style="color:#1a1208;">Manual Order Creation is a Beta/Pro Feature</h2>';
        echo '<p style="color:#555;line-height:1.5;">Upgrade your plan to create orders from the admin, send quotes, and generate WooCommerce payment links.</p>';
        echo '<a href="' . esc_url(admin_url('admin.php?page=caterme-settings&tab=plan')) . '" style="display:inline-block;margin-top:16px;background:#c8522a;color:#fff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;">View Plans →</a>';
        echo '</div></div>';
        return;
    }
    global $wpdb;
    $orders_table = $wpdb->prefix . 'caterme_orders';
    $items_table  = $wpdb->prefix . 'caterme_order_items';
    $settings     = caterme_get_settings();
    $menu         = caterme_get_wc_menu();
    $notice       = '';

    // Handle form submission
    if ( isset($_POST['caterme_admin_create'], $_POST['_wpnonce'])
        && wp_verify_nonce($_POST['_wpnonce'], 'caterme_admin_create_order') ) {

        $order_date = sanitize_text_field( $_POST['order_date'] ?? '' );
        $order_time = sanitize_text_field( $_POST['order_time'] ?? '' );
        $subtotal   = 0.0;

        // Build items from POST
        $posted_items = array();
        $item_names   = $_POST['item_name']  ?? array();
        $item_qtys    = $_POST['item_qty']   ?? array();
        $item_prices  = $_POST['item_price'] ?? array();
        $item_sels    = $_POST['item_sel']   ?? array();
        foreach ( $item_names as $i => $name ) {
            $name = sanitize_text_field($name);
            if ( ! $name ) continue;
            $qty        = max(1, absint($item_qtys[$i] ?? 1));
            $price      = floatval($item_prices[$i] ?? 0);
            $line_total = $price * $qty;
            $subtotal  += $line_total;
            $posted_items[] = array(
                'item_name'  => $name,
                'qty'        => $qty,
                'unit_price' => $price,
                'line_total' => $line_total,
                'selections' => wp_json_encode( array_filter( array_map('sanitize_text_field', (array)($item_sels[$i] ?? array())) ) ),
                'dietary'    => '',
                'label_name' => '',
            );
        }

        if ( empty($posted_items) ) {
            $notice = '<div class="notice notice-error"><p>Please add at least one item.</p></div>';
        } else {
            // Generate order number
            $today    = date('Ymd');
            $count    = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$orders_table} WHERE DATE(created_at)=CURDATE()") + 1;
            $order_number = 'CAT-' . $today . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);

            $wpdb->insert( $orders_table, array(
                'order_number'   => $order_number,
                'status'         => sanitize_text_field( $_POST['status'] ?? 'new' ),
                'fulfillment'    => sanitize_text_field( $_POST['fulfillment'] ?? 'pickup' ),
                'order_date'     => $order_date ?: null,
                'order_time'     => $order_time ? $order_time . ':00' : null,
                'subtotal'       => $subtotal,
                'customer_name'  => sanitize_text_field( $_POST['customer_name']  ?? '' ),
                'customer_phone' => sanitize_text_field( $_POST['customer_phone'] ?? '' ),
                'customer_email' => sanitize_email(      $_POST['customer_email'] ?? '' ),
                'notes'          => sanitize_textarea_field( $_POST['notes'] ?? '' ),
                'created_at'     => current_time('mysql'),
            ));
            $order_id = $wpdb->insert_id;

            foreach ( $posted_items as $item ) {
                $wpdb->insert( $items_table, array_merge( array('order_id' => $order_id), $item ) );
            }

            $action = sanitize_text_field( $_POST['after_save'] ?? 'view' );
            if ( $action === 'quote' ) {
                $order = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$orders_table} WHERE id=%d", $order_id) );
                $items = $wpdb->get_results( $wpdb->prepare("SELECT * FROM {$items_table} WHERE order_id=%d", $order_id) );
                caterme_send_quote_email( $order, $items, $settings );
            } elseif ( $action === 'payment' && caterme_wc_active() ) {
                $order = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$orders_table} WHERE id=%d", $order_id) );
                $items = $wpdb->get_results( $wpdb->prepare("SELECT * FROM {$items_table} WHERE order_id=%d", $order_id) );
                caterme_send_payment_link_email( $order, $items, $settings, $wpdb );
            }

            // Redirect to order detail
            wp_redirect( admin_url('admin.php?page=caterme-orders&view=' . $order_id . '&created=1') );
            exit;
        }
    }

    // Build flat item list from menu for the JS picker
    // Menu is stored as: {categories:[{name,icon,items:[...]},...]}
    $all_items = array();
    foreach ( ($menu['categories'] ?? array()) as $cat ) {
        $cat_name = $cat['name'] ?? '';
        foreach ( ($cat['items'] ?? array()) as $item ) {
            $all_items[] = array(
                'name'     => $item['name'],
                'price'    => $item['price'],
                'category' => $cat_name,
            );
        }
    }
    $items_json = wp_json_encode($all_items);

    ?>
    <div class="wrap">
        <h1><a href="<?php echo admin_url('admin.php?page=caterme-orders'); ?>" style="text-decoration:none;color:#888;font-size:14px;font-weight:400;">← All Orders</a><br>
        ✏️ Create New Order</h1>
        <?php echo $notice; ?>

        <form method="post" id="caterme-create-form" style="max-width:900px;">
            <?php wp_nonce_field('caterme_admin_create_order'); ?>

            <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">

                <!-- Left: Items -->
                <div>
                    <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;margin-bottom:16px;">
                        <div style="background:#1a1208;color:#f5e6c8;padding:14px 18px;font-weight:700;font-size:14px;display:flex;justify-content:space-between;align-items:center;">
                            <span>Order Items</span>
                        </div>
                        <div style="padding:16px 18px;">
                            <!-- Quick Add from Menu -->
                            <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;">
                                <select id="caterme-menu-picker" style="flex:1;padding:8px;border:1.5px solid #ddd;border-radius:6px;min-width:200px;">
                                    <option value="">— Add item from menu —</option>
                                    <?php foreach ( ($menu['categories'] ?? array()) as $cat ): ?>
                                    <optgroup label="<?php echo esc_attr($cat['name']??''); ?>">
                                        <?php foreach ( ($cat['items'] ?? array()) as $item ): ?>
                                        <option value="<?php echo esc_attr(wp_json_encode(array('name'=>$item['name'],'price'=>$item['price']))); ?>">
                                            <?php echo esc_html($item['name']); ?> — $<?php echo number_format($item['price'],2); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                    <?php endforeach; ?>
                                </select>
                                <button type="button" onclick="catermeAddFromMenu()" class="button">+ Add</button>
                                <button type="button" onclick="catermeAddBlankRow()" class="button">+ Custom</button>
                            </div>

                            <!-- Item Rows -->
                            <table id="caterme-items-table" style="width:100%;border-collapse:collapse;font-size:13px;">
                                <thead>
                                    <tr style="background:#faf7f2;text-align:left;">
                                        <th style="padding:8px 10px;">Item Name</th>
                                        <th style="padding:8px 10px;width:60px;">Qty</th>
                                        <th style="padding:8px 10px;width:80px;">Unit $</th>
                                        <th style="padding:8px 10px;width:80px;">Total</th>
                                        <th style="padding:8px 10px;width:36px;"></th>
                                    </tr>
                                </thead>
                                <tbody id="caterme-items-body"></tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" style="padding:10px;text-align:right;font-weight:700;">Subtotal:</td>
                                        <td style="padding:10px;font-weight:900;color:#c8832a;" id="caterme-subtotal">$0.00</td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <!-- Notes -->
                    <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                        <div style="background:#1a1208;color:#f5e6c8;padding:12px 18px;font-weight:700;font-size:13px;">Notes</div>
                        <div style="padding:14px 18px;">
                            <textarea name="notes" rows="4" placeholder="Special requests, allergies, instructions..." style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:8px 10px;font-size:13px;box-sizing:border-box;"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Right: Customer & Options -->
                <div style="display:flex;flex-direction:column;gap:14px;">

                    <!-- Customer -->
                    <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                        <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Customer</div>
                        <div style="padding:14px 16px;display:flex;flex-direction:column;gap:10px;">
                            <div><label style="display:block;font-size:12px;font-weight:700;margin-bottom:3px;">Name</label>
                            <input type="text" name="customer_name" style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;" /></div>
                            <div><label style="display:block;font-size:12px;font-weight:700;margin-bottom:3px;">Email</label>
                            <input type="email" name="customer_email" style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;" /></div>
                            <div><label style="display:block;font-size:12px;font-weight:700;margin-bottom:3px;">Phone</label>
                            <input type="tel" name="customer_phone" style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;" /></div>
                        </div>
                    </div>

                    <!-- Fulfillment -->
                    <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                        <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Fulfillment</div>
                        <div style="padding:14px 16px;display:flex;flex-direction:column;gap:10px;">
                            <div><label style="display:block;font-size:12px;font-weight:700;margin-bottom:3px;">Type</label>
                            <select name="fulfillment" style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;">
                                <option value="pickup">🏪 Pick Up</option>
                                <option value="delivery">🚗 Delivery</option>
                            </select></div>
                            <div><label style="display:block;font-size:12px;font-weight:700;margin-bottom:3px;">Date</label>
                            <input type="date" name="order_date" style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;" /></div>
                            <div><label style="display:block;font-size:12px;font-weight:700;margin-bottom:3px;">Time</label>
                            <input type="time" name="order_time" style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;" /></div>
                        </div>
                    </div>

                    <!-- Status -->
                    <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                        <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Status</div>
                        <div style="padding:14px 16px;">
                            <select name="status" style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;">
                                <option value="new">🆕 New</option>
                                <option value="confirmed">✅ Confirmed</option>
                                <option value="preparing">👨‍🍳 Preparing</option>
                            </select>
                        </div>
                    </div>

                    <!-- Save Actions -->
                    <div style="background:#fff;border:1px solid #e0d0b8;border-radius:10px;overflow:hidden;">
                        <div style="background:#1a1208;color:#f5e6c8;padding:12px 16px;font-weight:700;font-size:13px;">Save & Send</div>
                        <div style="padding:14px 16px;display:flex;flex-direction:column;gap:8px;">
                            <button type="submit" name="caterme_admin_create" value="1" onclick="document.getElementById('after_save').value='view'" class="button button-primary" style="width:100%;padding:10px;font-size:14px;">
                                💾 Save Order
                            </button>
                            <button type="submit" name="caterme_admin_create" value="1" onclick="document.getElementById('after_save').value='quote'" class="button" style="width:100%;padding:10px;">
                                📋 Save & Email Quote
                            </button>
                            <?php if ( caterme_wc_active() && ($settings['wc_enabled']??'1') === '1' && ($settings['test_mode']??'0') !== '1' ): ?>
                            <button type="submit" name="caterme_admin_create" value="1" onclick="document.getElementById('after_save').value='payment'" class="button button-primary" style="width:100%;padding:10px;background:#c8832a;border-color:#c8832a;">
                                💳 Save & Send Payment Link
                            </button>
                            <?php endif; ?>
                            <input type="hidden" name="after_save" id="after_save" value="view" />
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>

    <script>
    var caterme_row_idx = 0;
    function catermeRowHtml(name, price) {
        var i = caterme_row_idx++;
        return '<tr id="caterme-row-'+i+'">' +
            '<td style="padding:6px 8px;"><input type="text" name="item_name[]" value="'+htmlEsc(name)+'" style="width:100%;border:1.5px solid #ddd;border-radius:5px;padding:5px 7px;font-size:13px;" oninput="catermeUpdateTotals()" /></td>' +
            '<td style="padding:6px 8px;"><input type="number" name="item_qty[]" value="1" min="1" style="width:56px;border:1.5px solid #ddd;border-radius:5px;padding:5px 6px;font-size:13px;" oninput="catermeUpdateTotals()" /></td>' +
            '<td style="padding:6px 8px;"><input type="number" name="item_price[]" value="'+price+'" step="0.01" min="0" style="width:72px;border:1.5px solid #ddd;border-radius:5px;padding:5px 6px;font-size:13px;" oninput="catermeUpdateTotals()" /></td>' +
            '<td style="padding:6px 8px;text-align:right;font-weight:700;" id="caterme-line-'+i+'">$'+parseFloat(price).toFixed(2)+'</td>' +
            '<td style="padding:6px 8px;text-align:center;"><button type="button" onclick="catermeRemoveRow('+i+')" style="background:none;border:none;cursor:pointer;color:#cc0000;font-size:16px;line-height:1;">×</button></td>' +
        '</tr>';
    }
    function htmlEsc(s){ var d=document.createElement('div'); d.appendChild(document.createTextNode(s||'')); return d.innerHTML; }
    function catermeAddFromMenu(){
        var sel = document.getElementById('caterme-menu-picker');
        var val = sel.value; if(!val) return;
        var obj = JSON.parse(val);
        document.getElementById('caterme-items-body').insertAdjacentHTML('beforeend', catermeRowHtml(obj.name, obj.price));
        sel.value = '';
        catermeUpdateTotals();
    }
    function catermeAddBlankRow(){
        document.getElementById('caterme-items-body').insertAdjacentHTML('beforeend', catermeRowHtml('', 0));
    }
    function catermeRemoveRow(i){
        var row = document.getElementById('caterme-row-'+i);
        if(row) row.remove();
        catermeUpdateTotals();
    }
    function catermeUpdateTotals(){
        var rows = document.querySelectorAll('#caterme-items-body tr');
        var total = 0;
        rows.forEach(function(row){
            var id = row.id.replace('caterme-row-','');
            var qty   = parseFloat(row.querySelector('[name="item_qty[]"]').value)||0;
            var price = parseFloat(row.querySelector('[name="item_price[]"]').value)||0;
            var line  = qty * price;
            total += line;
            var lineEl = document.getElementById('caterme-line-'+id);
            if(lineEl) lineEl.textContent = '$'+line.toFixed(2);
        });
        document.getElementById('caterme-subtotal').textContent = '$'+total.toFixed(2);
    }
    </script>
    <?php
}



add_action( 'admin_menu', function() {
    // Hidden page — registered for URL routing but admin_init intercepts before output
    add_submenu_page( '', 'Print', 'Print', 'manage_options', 'caterme-print', '__return_false' );
});

// ── Invoice ──────────────────────────────────────────────────────────────────

function caterme_print_invoice( $order, $items, $s ) {
    $store_name    = esc_html( $s['store_name'] ?? 'My Catering Co.' );
    $store_address = esc_html( $s['store_address'] ?? '123 Main Street, Your City, ST' );
    $store_phone   = esc_html( $s['store_phone']   ?? '(555) 000-0000' );
    $store_email   = esc_html( $s['store_email']   ?? 'catering@yourdomain.com' );
    $dt = ($order->order_date ? date('F j, Y', strtotime($order->order_date)) : '') . ($order->order_time ? ' at ' . date('g:i a', strtotime($order->order_time)) : '');
    $tip = floatval($order->tip ?? 0);
    $grand_total = floatval($order->subtotal) + $tip;
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Invoice — <?php echo esc_html($order->order_number); ?></title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: Georgia, serif; color: #1a1208; background: #f5f0e8; font-size: 13px; }
.print-bar { background:#1a1208; color:#f5e6c8; padding:12px 24px; display:flex; justify-content:space-between; align-items:center; font-family:Arial,sans-serif; position:sticky; top:0; z-index:100; gap:16px; }
.print-bar strong { font-size:14px; letter-spacing:.3px; }
.print-bar span { font-size:12px; color:#b8996a; }
.print-bar-btns { display:flex; gap:8px; align-items:center; }
.btn-print { background:#c8832a; color:#fff; border:none; padding:8px 22px; border-radius:6px; cursor:pointer; font-weight:700; font-size:14px; font-family:Arial,sans-serif; }
.btn-back  { background:transparent; color:#b8996a; border:1px solid rgba(200,131,42,.4); padding:7px 14px; border-radius:6px; cursor:pointer; font-size:13px; font-family:Arial,sans-serif; }
.btn-back:hover { color:#f5e6c8; border-color:#f5e6c8; }
.doc { max-width:820px; margin:28px auto 60px; background:#fff; border-radius:10px; box-shadow:0 4px 24px rgba(0,0,0,.10); overflow:hidden; }
.doc-inner { padding:40px 48px; }
.header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:32px; padding-bottom:22px; border-bottom: 3px solid #1a1208; }
.logo { font-size: 26px; font-weight: 900; letter-spacing: 3px; text-transform: uppercase; }
.logo small { display:block; font-size: 11px; font-weight: 400; letter-spacing: 2px; color: #c8832a; margin-top: 3px; }
.invoice-meta { text-align: right; }
.invoice-meta h2 { font-size: 22px; font-weight: 900; color: #c8832a; letter-spacing: 1px; }
.invoice-meta p { font-size: 12px; color: #666; margin-top: 3px; }
.store-info { font-size: 12px; color: #666; margin-top: 8px; line-height: 1.7; }
.section { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 28px; }
.box h3 { font-size: 10px; text-transform: uppercase; letter-spacing: 2px; color: #888; font-weight: 700; margin-bottom: 8px; border-bottom:1px solid #f0e8d8; padding-bottom:5px; }
.box p { font-size: 13px; line-height: 1.7; color: #1a1208; }
table { width: 100%; border-collapse: collapse; }
thead th { background: #1a1208; color: #f5e6c8; padding: 10px 12px; font-size: 11px; letter-spacing: 1px; text-transform: uppercase; }
thead th:last-child, thead th:nth-child(3), thead th:nth-child(2) { text-align: right; }
tbody td { padding: 10px 12px; border-bottom: 1px solid #f0e8d8; vertical-align: top; }
tbody td:last-child, tbody td:nth-child(3), tbody td:nth-child(2) { text-align: right; }
tbody tr:last-child td { border-bottom: none; }
.item-name { font-weight: 700; font-size: 13px; }
.item-sels { font-size: 11px; color: #888; margin-top: 3px; line-height: 1.5; }
.item-dietary { font-size: 11px; color: #c8832a; margin-top: 2px; }
.totals { border-top: 2px solid #1a1208; }
.totals td { padding: 8px 12px; font-size: 13px; }
.totals .grand-total td { font-size: 16px; font-weight: 900; color: #c8832a; background: #faf7f2; }
.notes-box { background: #faf7f2; border: 1px solid #e8dcc8; border-radius: 6px; padding: 14px; margin-top: 24px; }
.notes-box h3 { font-size: 10px; text-transform: uppercase; letter-spacing: 2px; color: #888; margin-bottom: 6px; }
.notes-box p { font-size: 12px; color: #444; line-height: 1.6; }
.thank-you { font-size: 18px; font-weight: 700; color: #1a1208; text-align: center; margin: 28px 0 10px; }
.footer { margin-top: 20px; padding-top: 16px; border-top: 1px solid #e8dcc8; text-align: center; font-size: 11px; color: #888; line-height: 1.8; }
@media print {
    body { background:#fff; }
    .print-bar { display: none !important; }
    .doc { margin:0; box-shadow:none; border-radius:0; }
    .doc-inner { padding:24px 32px; }
    @page { margin: 0.5in; size: letter; }
}
</style>
</head>
<body>

<div class="print-bar">
    <div>
        <strong>🧾 Invoice — <?php echo esc_html($order->order_number); ?></strong>
        <span style="margin-left:14px;"><?php echo esc_html($order->customer_name ?: 'No name'); ?></span>
    </div>
    <div class="print-bar-btns">
        <button class="btn-back" onclick="window.close()">✕ Close</button>
        <button class="btn-print" onclick="window.print()">🖨️ Print Invoice</button>
    </div>
</div>

<div class="doc">
<div class="doc-inner">

<div class="header">
    <div>
        <div class="logo"><?php echo $store_name; ?><small>Catering</small></div>
        <div class="store-info">
            <?php echo $store_address; ?><br>
            <?php echo $store_phone; ?> · <?php echo $store_email; ?>
        </div>
    </div>
    <div class="invoice-meta">
        <h2>INVOICE</h2>
        <p><?php echo esc_html($order->order_number); ?></p>
        <p>Issued <?php echo date('F j, Y'); ?></p>
    </div>
</div>

<div class="section">
    <div class="box">
        <h3>Fulfillment</h3>
        <p>
            <strong><?php echo $order->fulfillment === 'delivery' ? '🚗 Delivery' : '🏪 Pick Up'; ?></strong><br>
            <?php if($dt): ?><?php echo esc_html($dt); ?><?php endif; ?>
        </p>
    </div>
    <div class="box">
        <h3>Customer</h3>
        <p>
            <?php echo $order->customer_name  ? esc_html($order->customer_name).'<br>'  : ''; ?>
            <?php echo $order->customer_phone ? esc_html($order->customer_phone).'<br>' : ''; ?>
            <?php echo $order->customer_email ? esc_html($order->customer_email)        : ''; ?>
            <?php if (!$order->customer_name && !$order->customer_email && !$order->customer_phone): ?>—<?php endif; ?>
        </p>
    </div>
</div>

<table>
    <thead>
        <tr>
            <th style="text-align:left;width:50%;">Item</th>
            <th>Qty</th>
            <th>Unit Price</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($items as $item):
        $sels_raw = json_decode($item->selections, true) ?: array();
        $sel_parts = array();
        foreach ($sels_raw as $sk => $sv) {
            if ($sk === 'dietary') continue;
            if ($sv === false || $sv === 0 || $sv === '') continue;
            if (is_array($sv)) { foreach($sv as $svv) $sel_parts[] = (string)$svv; continue; }
            if ($sv === true) { $sel_parts[] = ucfirst(str_replace('_',' ',$sk)); continue; }
            $sel_parts[] = (string)$sv;
        }
    ?>
        <tr>
            <td>
                <div class="item-name"><?php echo esc_html($item->item_name); ?></div>
                <?php if ( !empty($item->label_name) ): ?><div style="font-size:11px;color:#c8832a;font-weight:700;margin-top:2px;">🏷️ <?php echo esc_html($item->label_name); ?></div><?php endif; ?>
                <?php if ($sel_parts): ?><div class="item-sels"><?php echo esc_html(implode(' · ', $sel_parts)); ?></div><?php endif; ?>
                <?php if ($item->dietary): ?><div class="item-dietary"><?php echo esc_html($item->dietary); ?></div><?php endif; ?>
            </td>
            <td><?php echo (int)$item->qty; ?></td>
            <td>$<?php echo number_format($item->unit_price, 2); ?></td>
            <td>$<?php echo number_format($item->line_total, 2); ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <tbody class="totals">
        <tr><td colspan="3" style="text-align:right;color:#888;">Subtotal</td><td>$<?php echo number_format($order->subtotal,2); ?></td></tr>
        <?php if ($tip > 0): ?><tr><td colspan="3" style="text-align:right;color:#888;">Tip</td><td>$<?php echo number_format($tip,2); ?></td></tr><?php endif; ?>
        <tr><td colspan="3" style="text-align:right;color:#888;">Tax &amp; Delivery Fee</td><td>TBD</td></tr>
        <tr class="grand-total"><td colspan="3" style="text-align:right;">Order Total</td><td>$<?php echo number_format($grand_total,2); ?>+</td></tr>
    </tbody>
</table>

<?php if ($order->notes): ?>
<div class="notes-box">
    <h3>Notes</h3>
    <p><?php echo nl2br(esc_html($order->notes)); ?></p>
</div>
<?php endif; ?>

<div class="thank-you">Thank you for choosing <?php echo $store_name; ?>!</div>
<div class="footer">
    <?php echo $store_name; ?> · <?php echo $store_address; ?><br>
    <?php echo $store_phone; ?> · <?php echo $store_email; ?><br>
    Prices do not include applicable taxes. Delivery fees are calculated separately.
</div>

</div><!-- /.doc-inner -->
</div><!-- /.doc -->

<script>
// Auto-open print dialog after a brief delay to allow fonts/images to load
// Uncomment the line below to auto-print on open:
// setTimeout(function(){ window.print(); }, 400);
</script>
</body>
</html>
<?php
}

// ── Avery 5163 Labels ─────────────────────────────────────────────────────────
// Avery 5163: 2 cols × 5 rows = 10 labels/sheet, each 4" × 2"
// Top margin: 0.5", Left margin: 0.156", H-gap: 0.188", V-gap: 0"

function caterme_print_labels( $order, $items, $s ) {
    global $wpdb;
    
    $store_name        = $s['store_name']           ?? 'My Catering Co.';
    $logo_url          = $s['logo_url']              ?? '';
    $label_logo_height = (int)($s['label_logo_height'] ?? 28);
    $label_logo_align  = $s['label_logo_align']      ?? 'left';
    $orientation       = $s['label_orientation']     ?? 'portrait';
    $label_font        = $s['label_font']            ?? 'Arial, Helvetica, sans-serif';
    $label_font_size   = (int)($s['label_font_size'] ?? 11);
    $label_font_weight = $s['label_font_weight']     ?? 'bold';
    $color_primary     = $s['label_color_primary']   ?? '#1a1208';
    $color_accent      = $s['label_color_accent']    ?? '#c8832a';

    $is_landscape    = ( $orientation === 'landscape' );
    $label_w         = $is_landscape ? '2in'          : '4in';
    $label_h         = $is_landscape ? '4in'          : '2in';
    $grid_cols       = $is_landscape ? 'repeat(5, 2in)' : '4in 4in';
    $col_gap         = $is_landscape ? '0'            : '0.188in';
    $page_w          = $is_landscape ? '11in'         : '8.5in';
    $page_min_h      = $is_landscape ? '8.5in'        : '11in';
    $page_pad_tb     = '0.5in';
    $page_pad_lr     = $is_landscape ? '0.5in'        : '0.156in';
    $page_size_css   = $is_landscape ? 'letter landscape' : 'letter';
    $labels_per_page = 10;

    $dt = '';
    if ( $order->order_date ) $dt .= date('M j, Y', strtotime($order->order_date));
    if ( $order->order_time ) $dt .= ' ' . date('g:i a', strtotime($order->order_time));

    // Helper: parse the selections JSON into a clean flat list of strings,
    // filtering out false toggles, empty values, the 'dietary' key, and arrays.
    $parse_sels = function( $raw_json ) {
        $decoded = json_decode($raw_json, true);
        if ( ! is_array($decoded) ) return array();
        $parts = array();
        foreach ( $decoded as $key => $val ) {
            if ( $key === 'dietary' )                   continue; // shown separately
            if ( $val === false || $val === 0 || $val === '' ) continue; // unchecked toggle
            if ( is_array($val) )                       continue; // nested array
            if ( $val === true )                        { $parts[] = ucfirst(str_replace('_',' ',$key)); continue; }
            $parts[] = (string)$val;
        }
        return $parts;
    };

    // Build a lookup of item name → no_print flag from WC product meta.
    // Querying post meta directly is faster and accurate regardless of category structure.
    $no_print_ids   = $wpdb->get_col(
        "SELECT p.post_title FROM {$wpdb->postmeta} pm
         JOIN {$wpdb->posts} p ON p.ID = pm.post_id
         WHERE pm.meta_key = '_caterme_no_print' AND pm.meta_value = '1'
           AND p.post_status = 'publish'"
    );
    $no_print_names = array();
    foreach ( $no_print_ids as $title ) {
        $no_print_names[ strtolower(trim($title)) ] = true;
    }

    // Expand items by qty — each unit gets its own label; skip no-print items
    $label_items = array();
    foreach ( $items as $item ) {
        if ( isset($no_print_names[ strtolower(trim($item->item_name)) ]) ) continue;
        for ( $i = 0; $i < max(1, (int)$item->qty); $i++ ) {
            $label_items[] = $item;
        }
    }
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Labels — <?php echo esc_html($order->order_number); ?></title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { background:#f0f0f0; font-family:<?php echo esc_attr($label_font); ?>; }

.print-bar {
    background:#1a1208; color:#f5e6c8; padding:12px 24px;
    display:flex; justify-content:space-between; align-items:center;
    font-family:Arial, sans-serif; position:sticky; top:0; z-index:100; gap:16px;
}
.print-bar strong { font-size:14px; letter-spacing:.3px; }
.print-bar span { font-size:12px; color:#b8996a; }
.print-bar-btns { display:flex; gap:8px; align-items:center; }
.btn-print { background:#c8832a; color:#fff; border:none; padding:8px 22px; border-radius:6px; cursor:pointer; font-weight:700; font-size:14px; font-family:Arial,sans-serif; }
.btn-back  { background:transparent; color:#b8996a; border:1px solid rgba(200,131,42,.4); padding:7px 14px; border-radius:6px; cursor:pointer; font-size:13px; font-family:Arial,sans-serif; }

.page {
    width:<?php echo $page_w; ?>;
    min-height:<?php echo $page_min_h; ?>;
    background:#fff;
    margin:20px auto;
    padding:<?php echo $page_pad_tb; ?> <?php echo $page_pad_lr; ?>;
}

.label-grid {
    display:grid;
    grid-template-columns:<?php echo $grid_cols; ?>;
    grid-auto-rows:<?php echo $label_h; ?>;
    column-gap:<?php echo $col_gap; ?>;
    row-gap:0;
}

.label {
    width:<?php echo $label_w; ?>;
    height:<?php echo $label_h; ?>;
    overflow:hidden;
    padding:0.1in 0.13in 0.09in;
    position:relative;
    border:1px dashed #ccc;
    display:flex;
    flex-direction:column;
    font-family:<?php echo esc_attr($label_font); ?>;
    gap:0;
}

/* ── Top bar: logo left, order# right ── */
.label-top {
    display:flex;
    justify-content:space-between;
    align-items:center;
    border-bottom:1.5px solid <?php echo esc_attr($color_primary); ?>;
    padding-bottom:3px;
    margin-bottom:4px;
    flex-shrink:0;
}
.label-branding {
    flex:1;
    display:flex;
    <?php if ($label_logo_align === 'center'): ?>
    justify-content:center;
    <?php elseif ($label_logo_align === 'right'): ?>
    justify-content:flex-end;
    <?php else: ?>
    justify-content:flex-start;
    <?php endif; ?>
    align-items:center;
    min-width:0;
}
.label-logo {
    max-height:<?php echo $label_logo_height; ?>px;
    max-width:<?php echo min(120, $label_logo_height * 4); ?>px;
    width:auto;
    object-fit:contain;
    display:block;
}
.label-store-text {
    font-size:8.5pt;
    font-weight:900;
    letter-spacing:0.8px;
    text-transform:uppercase;
    color:<?php echo esc_attr($color_primary); ?>;
    line-height:1;
}
.label-order-num {
    font-size:7pt;
    color:#999;
    text-align:right;
    white-space:nowrap;
    margin-left:6px;
    flex-shrink:0;
}

/* ── Body ── */
.label-body {
    flex:1;
    display:flex;
    flex-direction:column;
    justify-content:flex-start;
    overflow:hidden;
    min-height:0;
}

.label-person {
    font-size:<?php echo min(14, $label_font_size + 3); ?>pt;
    font-weight:900;
    color:<?php echo esc_attr($color_accent); ?>;
    line-height:1.15;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.label-item {
    font-size:<?php echo $label_font_size; ?>pt;
    font-weight:<?php echo esc_attr($label_font_weight); ?>;
    color:<?php echo esc_attr($color_primary); ?>;
    line-height:1.2;
    margin-top:1px;
}

.label-sels {
    font-size:7.5pt;
    color:#444;
    line-height:1.35;
    margin-top:2px;
    overflow:hidden;
    /* let text wrap fully — show all ingredients */
}

.label-dietary {
    font-size:7pt;
    color:<?php echo esc_attr($color_accent); ?>;
    font-weight:700;
    margin-top:2px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

/* ── Footer ── */
.label-footer {
    display:flex;
    justify-content:space-between;
    align-items:flex-end;
    border-top:1px solid #ddd;
    padding-top:3px;
    margin-top:3px;
    flex-shrink:0;
}
.label-footer-dt   { font-size:7.5pt; color:<?php echo esc_attr($color_primary); ?>; font-weight:700; }
.label-footer-type { font-size:7.5pt; color:#888; }
.label-num { position:absolute; bottom:3px; right:5px; font-size:6.5pt; color:#ccc; }

@media print {
    body { background:white; }
    .print-bar { display:none !important; }
    .page { margin:0; box-shadow:none; }
    .label { border:none; }
    @page { size:<?php echo $page_size_css; ?>; margin:0; }
}
</style>
</head>
<body>

<div class="print-bar">
    <div>
        <strong>🏷️ Labels — <?php echo esc_html($order->order_number); ?></strong>
        <span style="margin-left:14px;"><?php echo $is_landscape ? 'Landscape' : 'Avery 5163'; ?> · <?php echo count($label_items); ?> label<?php echo count($label_items)!==1?'s':''; ?></span>
    </div>
    <div class="print-bar-btns">
        <button class="btn-back" onclick="window.close()">✕ Close</button>
        <button class="btn-print" onclick="window.print()">🖨️ Print Labels</button>
    </div>
</div>

<?php
$pages = array_chunk($label_items, $labels_per_page);

foreach ($pages as $page_num => $page_labels):
    $padded = $page_labels;
    while ( count($padded) < $labels_per_page ) $padded[] = null;
?>
<div class="page">
    <div class="label-grid">
    <?php foreach ($padded as $idx => $item): ?>
        <div class="label">
        <?php if ($item):
            $sels      = $parse_sels($item->selections);
            $label_num = ($page_num * $labels_per_page) + $idx + 1;
            $total_labels = count($label_items);
        ?>
            <!-- Top bar: logo + order number -->
            <div class="label-top">
                <div class="label-branding">
                    <?php if ( $logo_url ): ?>
                        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($store_name); ?>" class="label-logo" />
                    <?php else: ?>
                        <div class="label-store-text"><?php echo esc_html($store_name); ?></div>
                    <?php endif; ?>
                </div>
                <div class="label-order-num" style="flex-shrink:0;margin-left:4px;"><?php echo esc_html($order->order_number); ?></div>
            </div>

            <!-- Body -->
            <div class="label-body">
                <?php if ( !empty($item->label_name) ): ?>
                    <div class="label-person"><?php echo esc_html($item->label_name); ?></div>
                <?php endif; ?>

                <div class="label-item" style="<?php echo empty($item->label_name) ? 'font-size:'.min(14,$label_font_size+2).'pt;' : ''; ?>">
                    <?php echo esc_html($item->item_name); ?>
                </div>

                <?php if ( $sels ): ?>
                    <div class="label-sels">
                        <?php
                        // Show each selection on its own line for clarity
                        foreach ( $sels as $i => $sel ) {
                            echo esc_html($sel);
                            if ( $i < count($sels) - 1 ) echo ' &middot; ';
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <?php if ( $item->dietary ): ?>
                    <div class="label-dietary">⚠️ <?php echo esc_html($item->dietary); ?></div>
                <?php endif; ?>
            </div>

            <!-- Footer -->
            <div class="label-footer">
                <div class="label-footer-dt"><?php echo esc_html($dt ?: 'Date TBD'); ?></div>
                <div class="label-footer-type"><?php echo $order->fulfillment === 'delivery' ? '🚗 Delivery' : '🏪 Pick Up'; ?></div>
            </div>

            <div class="label-num"><?php echo $label_num; ?>/<?php echo $total_labels; ?></div>
        <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>

</body>
</html>
<?php
}

// ─────────────────────────────────────────────────────────────────────────────
// REGISTER SETTINGS
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'admin_init', function() {
    register_setting( 'caterme_settings_group', 'caterme_settings', array(
        'sanitize_callback' => 'caterme_sanitize',
    ));
});

// Track when settings are saved
add_action( 'update_option_caterme_settings', function( $old, $new ) {
    caterme_track_event( 'settings_saved', array(
        'tab'          => sanitize_key( $_POST['cm_active_tab'] ?? 'unknown' ),
        'wc_enabled'   => $new['wc_enabled']  ?? '0',
        'test_mode'    => $new['test_mode']    ?? '0',
        'tip_enabled'  => $new['tip_enabled']  ?? '0',
        'sheets_set'   => ! empty( $new['sheets_webhook'] ),
        'telemetry_set'=> ! empty( $new['telemetry_endpoint'] ),
    ) );
}, 10, 2 );

function caterme_sanitize( $input ) {
    $defaults = caterme_defaults();
    $clean = array();
    $clean['style_mode']    = in_array( $input['style_mode'] ?? '', array('inherit','custom') ) ? $input['style_mode'] : 'custom';
    $clean['show_header']   = isset( $input['show_header'] ) ? '1' : '0';
    $clean['border_radius'] = min( 24, max( 0, absint( $input['border_radius'] ?? 12 ) ) );

    foreach ( array('color_primary','color_accent','color_bg','color_card','color_text','color_text_muted','color_border') as $k ) {
        $v = sanitize_hex_color( $input[$k] ?? $defaults[$k] );
        $clean[$k] = $v ?: $defaults[$k];
    }

    $allowed_fonts = array('Georgia, serif','Palatino Linotype, serif','Times New Roman, serif','Arial, sans-serif','Trebuchet MS, sans-serif','Verdana, sans-serif','Tahoma, sans-serif','Impact, sans-serif');
    foreach ( array('font_heading','font_body') as $k ) {
        $v = $input[$k] ?? $defaults[$k];
        $clean[$k] = in_array($v, $allowed_fonts) ? $v : $defaults[$k];
    }

    $clean['sheets_webhook']  = esc_url_raw( $input['sheets_webhook'] ?? '' );
    $clean['store_name']      = sanitize_text_field( $input['store_name']     ?? $defaults['store_name'] );
    $clean['store_address']   = sanitize_text_field( $input['store_address']  ?? $defaults['store_address'] );
    $clean['store_phone']     = sanitize_text_field( $input['store_phone']    ?? $defaults['store_phone'] );
    $clean['store_email']     = sanitize_email(      $input['store_email']    ?? $defaults['store_email'] );
    $clean['wc_enabled']         = isset( $input['wc_enabled'] ) ? '1' : '0';
    $clean['wc_tax_enabled']     = isset( $input['wc_tax_enabled'] ) ? '1' : '0';
    $clean['test_mode']          = isset( $input['test_mode'] )  ? '1' : '0';
    $clean['wc_preauth_note']    = sanitize_textarea_field( $input['wc_preauth_note'] ?? $defaults['wc_preauth_note'] );

    // Notification emails — validate each address individually
    $raw_emails = $input['notify_emails'] ?? '';
    $email_list = array_filter( array_map( 'trim', preg_split('/[\s,;]+/', $raw_emails) ) );
    $valid_emails = array();
    foreach ( $email_list as $e ) {
        $e = sanitize_email($e);
        if ( is_email($e) ) $valid_emails[] = $e;
    }
    $clean['notify_emails']      = implode(', ', $valid_emails);
    $clean['notify_on_new']      = isset( $input['notify_on_new'] )       ? '1' : '0';
    $clean['notify_on_paid']     = isset( $input['notify_on_paid'] )      ? '1' : '0';
    $clean['notify_on_confirmed']= isset( $input['notify_on_confirmed'] ) ? '1' : '0';
    $clean['notify_subject']     = sanitize_text_field( $input['notify_subject'] ?? $defaults['notify_subject'] );

    // Label & Email Formatting
    $clean['logo_url']          = esc_url_raw( $input['logo_url'] ?? '' );
    $clean['label_orientation'] = in_array( $input['label_orientation'] ?? '', array('portrait','landscape') ) ? $input['label_orientation'] : 'portrait';
    $allowed_label_fonts = array('Arial, Helvetica, sans-serif','Helvetica, Arial, sans-serif','Verdana, sans-serif','Tahoma, sans-serif','Georgia, serif','Times New Roman, serif');
    $clean['label_font']        = in_array( $input['label_font'] ?? '', $allowed_label_fonts ) ? $input['label_font'] : $defaults['label_font'];
    $clean['label_font_size']   = (string) min( 18, max( 7, absint( $input['label_font_size']  ?? 11 ) ) );
    $clean['label_font_weight'] = in_array( $input['label_font_weight'] ?? '', array('normal','bold') ) ? $input['label_font_weight'] : 'bold';
    foreach ( array('label_color_primary','label_color_accent','email_color_header','email_color_accent','email_color_text') as $k ) {
        $v = sanitize_hex_color( $input[$k] ?? $defaults[$k] );
        $clean[$k] = $v ?: $defaults[$k];
    }
    $allowed_email_fonts = array('Georgia, serif','Palatino Linotype, serif','Times New Roman, serif','Arial, sans-serif','Helvetica, Arial, sans-serif','Verdana, sans-serif','Tahoma, sans-serif');
    $clean['email_font']      = in_array( $input['email_font'] ?? '', $allowed_email_fonts ) ? $input['email_font'] : $defaults['email_font'];
    $clean['email_font_size'] = (string) min( 20, max( 10, absint( $input['email_font_size'] ?? 14 ) ) );
    $clean['label_logo_height'] = (string) min( 60, max( 16, absint( $input['label_logo_height'] ?? 28 ) ) );
    $clean['email_logo_height'] = (string) min( 120, max( 30, absint( $input['email_logo_height'] ?? 56 ) ) );
    $clean['label_logo_align']  = in_array($input['label_logo_align'] ?? '', array('left','center','right')) ? $input['label_logo_align'] : 'left';
    $clean['email_logo_align']  = in_array($input['email_logo_align'] ?? '', array('left','center','right')) ? $input['email_logo_align'] : 'center';
    $clean['tip_enabled']       = isset( $input['tip_enabled'] ) ? '1' : '0';
    // Validate tip presets: 1-5 integers between 1-99, comma-separated
    $raw_presets = preg_replace('/[^0-9,]/', '', $input['tip_presets'] ?? '15,20,25');
    $preset_vals = array_slice( array_filter( array_map('absint', explode(',', $raw_presets)), function($v){ return $v >= 1 && $v <= 99; }), 0, 5);
    $clean['tip_presets']       = implode(',', $preset_vals ?: array(15,20,25));
    $clean['menu_columns']      = (string) min( 4, max( 1, absint( $input['menu_columns'] ?? 2 ) ) );

    // Lead Time & Delivery
    $clean['lead_time_hours'] = (string) max( 0, absint( $input['lead_time_hours'] ?? 24 ) );
    // Delivery tiers — validate JSON array of {over_miles, fee} objects
    $raw_tiers = wp_unslash( $input['delivery_tiers'] ?? '[]' );
    $decoded_tiers = json_decode( $raw_tiers, true );
    $clean_tiers = array();
    if ( is_array($decoded_tiers) ) {
        foreach ( $decoded_tiers as $t ) {
            if ( isset($t['over_miles'], $t['fee']) ) {
                $clean_tiers[] = array(
                    'over_miles' => round( floatval($t['over_miles']), 2 ),
                    'fee'        => round( floatval($t['fee']), 2 ),
                );
            }
        }
    }
    $clean['delivery_tiers'] = wp_json_encode( $clean_tiers );
    $clean['store_lat']  = ( $input['store_lat'] ?? '' ) !== '' ? (string) round( floatval($input['store_lat']), 7 ) : '';
    $clean['store_lng']  = ( $input['store_lng'] ?? '' ) !== '' ? (string) round( floatval($input['store_lng']), 7 ) : '';
    $clean['gmaps_key']  = sanitize_text_field( $input['gmaps_key'] ?? '' );

    // Blackout dates — validate days of week and date formats
    $days_of_week = array('monday','tuesday','wednesday','thursday','friday','saturday','sunday');
    foreach ( array('pickup_closed_days', 'delivery_closed_days') as $k ) {
        $raw = isset($input[$k]) && is_array($input[$k]) ? $input[$k] : array();
        $valid = array_filter( array_map('strtolower', $raw), function($d) use ($days_of_week) {
            return in_array($d, $days_of_week);
        });
        $clean[$k] = implode( ',', $valid );
    }
    foreach ( array('pickup_blocked_dates', 'delivery_blocked_dates') as $k ) {
        $raw = array_filter( array_map( 'trim', explode(',', $input[$k] ?? '') ) );
        $valid = array_filter( $raw, function($d) { return preg_match('/^\d{4}-\d{2}-\d{2}$/', $d); } );
        $clean[$k] = implode( ',', $valid );
    }

    $clean['telemetry_endpoint'] = esc_url_raw( $input['telemetry_endpoint'] ?? '' );
    $clean['error_alert_email']  = sanitize_email( $input['error_alert_email'] ?? '' );

    return $clean;
}

// ─────────────────────────────────────────────────────────────────────────────
// SETTINGS PAGE
// ─────────────────────────────────────────────────────────────────────────────

function caterme_settings_page() {
    $s        = caterme_get_settings();
    $is_custom = ($s['style_mode'] === 'custom');
    $wc_on     = caterme_wc_active();
    $test_mode = ($s['test_mode'] ?? '0') === '1';
    $wc_enabled= ($s['wc_enabled'] ?? '1') === '1';
    $active_tab = sanitize_key( $_GET['tab'] ?? 'general' );
    $tabs = array(
        'general'      => array('icon'=>'🏪', 'label'=>'General'),
        'appearance'   => array('icon'=>'🎨', 'label'=>'Appearance'),
        'payments'     => array('icon'=>'💳', 'label'=>'Payments'),
        'notifications'=> array('icon'=>'📬', 'label'=>'Notifications'),
        'print'        => array('icon'=>'🖨️', 'label'=>'Print & Email'),
        'integrations' => array('icon'=>'🔗', 'label'=>'Integrations'),
        'availability' => array('icon'=>'📅', 'label'=>'Availability'),
        'tools'        => array('icon'=>'🔧', 'label'=>'Tools'),
        'plan'         => array('icon'=>'🔑', 'label'=>'Plan & License'),
    );
    ?>
    <div class="wrap cm-admin">
        <div class="cm-header">
            <div class="cm-header-title">
                <span class="cm-logo">🥡</span>
                <div>
                    <h1>CaterMe Settings</h1>
                    <p>v<?php echo CATERME_VERSION; ?> &nbsp;·&nbsp; Shortcode: <code>[CaterMe_Menu]</code></p>
                </div>
            </div>
        </div>

        <?php settings_errors('caterme_settings'); ?>

        <div class="cm-tab-wrap">
            <!-- Tab Nav -->
            <div class="cm-tabs" role="tablist">
                <?php foreach ($tabs as $slug => $tab): ?>
                <button type="button"
                    class="cm-tab<?php echo $slug === $active_tab ? ' cm-tab--active' : ''; ?>"
                    data-tab="<?php echo esc_attr($slug); ?>"
                    role="tab"
                    aria-selected="<?php echo $slug === $active_tab ? 'true' : 'false'; ?>">
                    <span class="cm-tab-ico"><?php echo $tab['icon']; ?></span>
                    <span class="cm-tab-lbl"><?php echo esc_html($tab['label']); ?></span>
                </button>
                <?php endforeach; ?>
            </div>

            <form method="post" action="options.php" class="cm-form">
                <?php settings_fields('caterme_settings_group'); ?>
                <!-- Track which tab was active on save -->
                <input type="hidden" name="cm_active_tab" id="cm_active_tab_field" value="<?php echo esc_attr($active_tab); ?>" />

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: GENERAL
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='general' ? ' cm-pane--active' : ''; ?>" data-pane="general">
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🏪 Store Information</h2>
                            <p>Displayed on printed labels, invoices, and customer emails.</p>
                        </div>
                        <div class="cm-2col">
                            <div class="cm-field">
                                <label for="cm_store_name"><strong>Store Name</strong></label>
                                <input id="cm_store_name" type="text" name="caterme_settings[store_name]" value="<?php echo esc_attr($s['store_name']); ?>" class="regular-text" />
                            </div>
                            <div class="cm-field">
                                <label for="cm_store_address"><strong>Store Address</strong></label>
                                <input id="cm_store_address" type="text" name="caterme_settings[store_address]" value="<?php echo esc_attr($s['store_address']); ?>" class="regular-text" />
                            </div>
                            <div class="cm-field">
                                <label for="cm_store_phone"><strong>Phone</strong></label>
                                <input id="cm_store_phone" type="text" name="caterme_settings[store_phone]" value="<?php echo esc_attr($s['store_phone']); ?>" class="regular-text" />
                            </div>
                            <div class="cm-field">
                                <label for="cm_store_email"><strong>Email</strong></label>
                                <input id="cm_store_email" type="email" name="caterme_settings[store_email]" value="<?php echo esc_attr($s['store_email']); ?>" class="regular-text" />
                            </div>
                        </div>
                    </div>

                    <div class="cm-card cm-card--info">
                        <div class="cm-card-head">
                            <h2>📌 Shortcode Reference</h2>
                        </div>
                        <div class="cm-info-row">
                            <div class="cm-info-item">
                                <code class="cm-code-big">[CaterMe_Menu]</code>
                                <p>Paste this shortcode on any page to display the catering order form.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Menu Display Options -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🗂️ Menu Display</h2>
                            <p>Control how menu items are laid out for customers.</p>
                        </div>
                        <div class="cm-field">
                            <label><strong>Menu Grid Columns</strong><em>Maximum number of columns on the item grid (auto-adjusts on mobile).</em></label>
                            <div style="display:flex;gap:8px;margin-top:8px;max-width:360px;">
                                <?php foreach (['1'=>'1 Col','2'=>'2 Cols','3'=>'3 Cols','4'=>'4 Cols'] as $val=>$lbl): ?>
                                <label class="cm-choice <?php echo ($s['menu_columns']??'2')===$val?'cm-choice--active':''; ?>" style="flex:1;text-align:center;">
                                    <input type="radio" name="caterme_settings[menu_columns]" value="<?php echo $val; ?>" <?php checked($s['menu_columns']??'2',$val); ?> />
                                    <?php echo $lbl; ?>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: APPEARANCE
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='appearance' ? ' cm-pane--active' : ''; ?>" data-pane="appearance">

                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🎨 Styling Mode</h2>
                            <p>Choose how the order form integrates with your site's design.</p>
                        </div>
                        <div class="cm-mode-row">
                            <label class="cm-mode-opt<?php echo !$is_custom ? ' cm-mode-opt--active' : ''; ?>">
                                <input type="radio" name="caterme_settings[style_mode]" value="inherit" <?php checked($s['style_mode'],'inherit'); ?> />
                                <span class="cm-mode-ico">🧩</span>
                                <span class="cm-mode-name">Inherit Theme</span>
                                <span class="cm-mode-desc">Uses your WordPress theme's fonts and colors automatically.</span>
                            </label>
                            <label class="cm-mode-opt<?php echo $is_custom ? ' cm-mode-opt--active' : ''; ?>">
                                <input type="radio" name="caterme_settings[style_mode]" value="custom" <?php checked($s['style_mode'],'custom'); ?> />
                                <span class="cm-mode-ico">🖌️</span>
                                <span class="cm-mode-name">Custom Styling</span>
                                <span class="cm-mode-desc">Define your own colors, fonts, and layout below.</span>
                            </label>
                        </div>
                    </div>

                    <div class="cm-card" id="cm-custom-block" style="<?php echo !$is_custom ? 'opacity:.45;pointer-events:none;' : ''; ?>">
                        <div class="cm-card-head">
                            <h2>🎨 Colors</h2>
                        </div>
                        <div class="cm-2col">
                            <?php foreach (array(
                                'color_primary'    => array('Header Background',  'Dark bar at the top of the form.'),
                                'color_accent'     => array('Accent — Buttons & Prices', 'Highlights buttons and prices.'),
                                'color_bg'         => array('Page Background',    'Overall form background.'),
                                'color_card'       => array('Card Background',    'Item card backgrounds.'),
                                'color_text'       => array('Body Text',          'Main text color.'),
                                'color_text_muted' => array('Muted Text',         'Descriptions and secondary text.'),
                                'color_border'     => array('Borders',            'Card outlines and dividers.'),
                            ) as $k => list($lbl, $info)): ?>
                            <div class="cm-field">
                                <label><strong><?php echo $lbl; ?></strong><em><?php echo $info; ?></em></label>
                                <div class="cm-clr-row">
                                    <input type="color" id="<?php echo $k; ?>" name="caterme_settings[<?php echo $k; ?>]" value="<?php echo esc_attr($s[$k]); ?>" />
                                    <input type="text" class="caterme-hex" data-for="<?php echo $k; ?>" value="<?php echo esc_attr($s[$k]); ?>" maxlength="7" />
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="cm-divider"></div>
                        <div class="cm-card-head"><h2>✏️ Typography</h2></div>
                        <div class="cm-2col">
                            <?php foreach (array('font_heading'=>'Heading Font','font_body'=>'Body Font') as $k=>$lbl):
                                $fonts = array('Georgia, serif'=>'Georgia','Palatino Linotype, serif'=>'Palatino','Times New Roman, serif'=>'Times New Roman','Arial, sans-serif'=>'Arial','Trebuchet MS, sans-serif'=>'Trebuchet MS','Verdana, sans-serif'=>'Verdana','Tahoma, sans-serif'=>'Tahoma'); ?>
                            <div class="cm-field">
                                <label><strong><?php echo $lbl; ?></strong></label>
                                <select name="caterme_settings[<?php echo $k; ?>]" class="cm-sel">
                                    <?php foreach ($fonts as $val=>$name): ?>
                                    <option value="<?php echo esc_attr($val); ?>" <?php selected($s[$k],$val); ?> style="font-family:<?php echo esc_attr($val); ?>;"><?php echo $name; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="cm-font-preview" style="font-family:<?php echo esc_attr($s[$k]); ?>;">The quick brown fox</div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="cm-divider"></div>
                        <div class="cm-card-head"><h2>📐 Layout</h2></div>
                        <div class="cm-field" style="max-width:400px;">
                            <label><strong>Card Corner Radius</strong><em>0 = sharp corners · 24 = very rounded</em></label>
                            <div class="cm-range-row">
                                <input type="range" id="border_radius" name="caterme_settings[border_radius]" min="0" max="24" value="<?php echo esc_attr($s['border_radius']); ?>" />
                                <span id="radius_lbl" class="cm-range-val"><?php echo esc_attr($s['border_radius']); ?>px</span>
                            </div>
                        </div>
                        <div class="cm-field" style="margin-top:16px;">
                            <label><strong>Show Header Bar</strong><em>Show or hide the dark title bar at the top of the form.</em></label>
                            <div class="cm-tog-row" style="margin-top:10px;">
                                <label class="cm-tog-switch" for="cm_show_header">
                                    <input type="checkbox" id="cm_show_header" name="caterme_settings[show_header]" value="1" <?php checked($s['show_header'],'1'); ?> />
                                    <span class="cm-tog-track"><span class="cm-tog-thumb"></span></span>
                                </label>
                                <label class="cm-tog-text" for="cm_show_header">Show header bar</label>
                            </div>
                        </div>

                        <div class="cm-divider"></div>
                        <div class="cm-card-head"><h2>👁️ Live Preview</h2></div>
                        <div id="caterme-prev-card" style="display:inline-block;min-width:260px;max-width:300px;background:<?php echo esc_attr($s['color_card']); ?>;border:1px solid <?php echo esc_attr($s['color_border']); ?>;border-radius:<?php echo esc_attr($s['border_radius']); ?>px;padding:18px;font-family:<?php echo esc_attr($s['font_body']); ?>;">
                            <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
                                <span id="pv-name" style="font-family:<?php echo esc_attr($s['font_heading']); ?>;font-size:15px;font-weight:800;color:<?php echo esc_attr($s['color_text']); ?>;">Standard Sandwich Box</span>
                                <span id="pv-price" style="font-size:16px;font-weight:900;color:<?php echo esc_attr($s['color_accent']); ?>;">$12.00</span>
                            </div>
                            <p id="pv-desc" style="font-size:12px;color:<?php echo esc_attr($s['color_text_muted']); ?>;margin:0 0 12px;line-height:1.5;">Choice of protein, chicken salad, or pimento cheese.</p>
                            <button id="pv-btn" style="background:<?php echo esc_attr($s['color_primary']); ?>;color:#f5e6c8;border:none;border-radius:<?php echo esc_attr($s['border_radius']); ?>px;padding:9px 14px;font-family:<?php echo esc_attr($s['font_body']); ?>;font-size:13px;font-weight:700;cursor:default;width:100%;">Customize &amp; Add</button>
                        </div>

                        <div style="margin-top:20px;">
                            <button type="button" id="caterme-reset" class="button">↩️ Reset to Defaults</button>
                        </div>
                    </div>
                </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: PAYMENTS
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='payments' ? ' cm-pane--active' : ''; ?>" data-pane="payments">

                    <!-- Test Mode -->
                    <div class="cm-card<?php echo $test_mode ? ' cm-card--warning' : ''; ?>">
                        <div class="cm-card-head">
                            <h2>🧪 Test Mode</h2>
                            <p>When enabled, orders are accepted and stored normally but <strong>no credit card processing occurs</strong> — WooCommerce payment steps are skipped entirely. Use this while setting up, training staff, or testing the order flow.</p>
                        </div>
                        <div class="cm-tog-row">
                            <label class="cm-tog-switch" for="cm_test_mode">
                                <input type="checkbox" id="cm_test_mode" name="caterme_settings[test_mode]" value="1" <?php checked($s['test_mode']??'0','1'); ?> />
                                <span class="cm-tog-track"><span class="cm-tog-thumb"></span></span>
                            </label>
                            <label class="cm-tog-text<?php echo $test_mode ? ' cm-tog-text--warn' : ''; ?>" for="cm_test_mode">
                                <?php echo $test_mode ? '<strong>⚠️ Test Mode is ON — payments are disabled</strong>' : 'Test Mode is off — live payments active'; ?>
                            </label>
                        </div>
                        <?php if ($test_mode): ?>
                        <div class="cm-alert cm-alert--warning" style="margin-top:14px;">
                            ⚠️ <strong>Test Mode is active.</strong> Customers can submit orders but will not be asked for payment. A visible banner is shown on the order form. Remember to turn this off before going live.
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- WooCommerce -->
                    <div class="cm-card<?php echo $wc_on ? ' cm-card--wc' : ''; ?>">
                        <div class="cm-card-head">
                            <h2>🛒 WooCommerce Payment Integration</h2>
                        </div>
                        <?php if ($wc_on): ?>
                        <div class="cm-alert cm-alert--success" style="margin-bottom:16px;">
                            ✅ WooCommerce is active. Orders will create a WC payment order and redirect customers to the checkout payment page for card pre-authorization.
                        </div>
                        <?php else: ?>
                        <div class="cm-alert cm-alert--info" style="margin-bottom:16px;">
                            ℹ️ WooCommerce is not installed or active. Install WooCommerce to enable payment processing.
                        </div>
                        <?php endif; ?>
                        <p style="font-size:13px;color:#555;line-height:1.7;margin-bottom:18px;">When enabled, each submitted catering order creates a WooCommerce order (status: <em>Pending payment</em>). The customer is redirected to enter their card, which is pre-authorized (held). When you mark the order <strong>Confirmed</strong>, the hold is automatically captured. Cancelling voids the hold.</p>

                        <div class="cm-2col">
                            <div class="cm-field">
                                <label><strong>Enable WooCommerce Payments</strong><em>Require card pre-authorization on order submission.</em></label>
                                <div class="cm-tog-row" style="margin-top:10px;">
                                    <label class="cm-tog-switch<?php echo !$wc_on ? ' cm-tog-switch--disabled' : ''; ?>" for="cm_wc_enabled">
                                        <input type="checkbox" id="cm_wc_enabled" name="caterme_settings[wc_enabled]" value="1" <?php checked($s['wc_enabled']??'1','1'); ?> <?php echo !$wc_on ? 'disabled' : ''; ?> />
                                        <span class="cm-tog-track"><span class="cm-tog-thumb"></span></span>
                                    </label>
                                    <label class="cm-tog-text" for="cm_wc_enabled"><?php echo $wc_on ? 'Enabled' : 'Requires WooCommerce'; ?></label>
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Pre-Auth Notice</strong><em>Shown to customers in the cart before they submit.</em></label>
                                <textarea name="caterme_settings[wc_preauth_note]" rows="3" class="cm-textarea" style="border-color:#ddd;"><?php echo esc_textarea($s['wc_preauth_note']??''); ?></textarea>
                            </div>
                        </div>

                        <?php if ($wc_on): ?>
                        <details class="cm-details" style="margin-top:16px;">
                            <summary>⚙️ Gateway Configuration Checklist</summary>
                            <div class="cm-details-body">
                                <p>For pre-authorization (authorize-only, capture-later) to work, your payment gateway must support it. Configure this in <strong>WooCommerce → Settings → Payments</strong>:</p>
                                <ul class="cm-list">
                                    <li><strong>Stripe:</strong> Set <em>Capture</em> to <strong>"Authorize Only"</strong> in the Stripe gateway settings.</li>
                                    <li><strong>Authorize.net:</strong> Set <em>Transaction Type</em> to <strong>"Authorization Only"</strong>.</li>
                                    <li><strong>Other gateways:</strong> Look for an "Authorize Only" or "Pre-Authorize" mode. CaterMe transitions WC order to <em>Processing</em> on confirmation which triggers most gateway capture hooks.</li>
                                </ul>
                            </div>
                        </details>
                        <?php endif; ?>
                    </div>

                    <!-- Tipping -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>💰 Tipping</h2>
                            <p>Let customers add a tip at checkout. They can choose a preset percentage or enter a custom amount.</p>
                        </div>
                        <div class="cm-field">
                            <div class="cm-tog-row">
                                <label class="cm-tog-switch" for="cm_tip_enabled">
                                    <input type="checkbox" id="cm_tip_enabled" name="caterme_settings[tip_enabled]" value="1" <?php checked($s['tip_enabled']??'1','1'); ?> />
                                    <span class="cm-tog-track"><span class="cm-tog-thumb"></span></span>
                                </label>
                                <label class="cm-tog-text" for="cm_tip_enabled">Enable tipping at checkout</label>
                            </div>
                        </div>
                        <div class="cm-field" style="margin-top:14px;">
                            <label><strong>Preset Tip Percentages</strong><em>Up to 5 values, comma-separated (e.g. 10,15,20,25). Customers see these as quick-pick buttons.</em></label>
                            <input type="text" name="caterme_settings[tip_presets]"
                                value="<?php echo esc_attr($s['tip_presets']??'15,20,25'); ?>"
                                placeholder="15,20,25"
                                class="regular-text" style="margin-top:6px;max-width:300px;" />
                        </div>
                    </div>

                    <!-- Sales Tax -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🧾 Sales Tax</h2>
                            <p>Apply WooCommerce tax rates to catering orders. Tax is calculated by WooCommerce using your configured tax classes and rates, then recorded on each order.</p>
                        </div>
                        <div class="cm-field">
                            <div class="cm-tog-row">
                                <label class="cm-tog-switch<?php echo !$wc_on ? ' cm-tog-switch--disabled' : ''; ?>" for="cm_wc_tax_enabled">
                                    <input type="checkbox" id="cm_wc_tax_enabled" name="caterme_settings[wc_tax_enabled]" value="1"
                                           <?php checked($s['wc_tax_enabled']??'1','1'); ?>
                                           <?php echo !$wc_on ? 'disabled' : ''; ?> />
                                    <span class="cm-tog-track"><span class="cm-tog-thumb"></span></span>
                                </label>
                                <label class="cm-tog-text" for="cm_wc_tax_enabled">
                                    <?php echo $wc_on ? 'Apply WooCommerce tax rates to catering orders' : 'Requires WooCommerce'; ?>
                                </label>
                            </div>
                        </div>
                        <?php if ( $wc_on ): ?>
                        <?php
                        $wc_tax_active = get_option('woocommerce_calc_taxes') === 'yes';
                        ?>
                        <?php if ( ! $wc_tax_active ): ?>
                        <div class="cm-alert cm-alert--warning" style="margin-top:12px;">
                            ⚠️ WooCommerce tax calculations are currently <strong>disabled</strong>.
                            Enable them in <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=tax'); ?>">WooCommerce → Settings → Tax</a> for this toggle to have effect.
                        </div>
                        <?php else: ?>
                        <div class="cm-alert cm-alert--success" style="margin-top:12px;">
                            ✅ WooCommerce tax is enabled. Tax rates and classes are configured in
                            <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=tax'); ?>">WooCommerce → Settings → Tax</a>.
                        </div>
                        <?php endif; ?>
                        <p style="font-size:12px;color:#888;margin:10px 0 0;line-height:1.6;">
                            Tax is calculated by WooCommerce at order creation using the customer's billing address and your configured rates. The amount is stored on the catering order and shown in the order detail. Customers see "Tax calculated at checkout" in the cart; the actual amount appears on the WooCommerce payment page and on the order confirmation.
                        </p>
                        <?php else: ?>
                        <p style="font-size:12px;color:#888;margin:10px 0 0;">WooCommerce must be active to use this feature.</p>
                        <?php endif; ?>
                    </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: NOTIFICATIONS
                ═══════════════════════════════════════════════════════ */ ?>
                </div>
                <div class="cm-pane<?php echo $active_tab==='notifications' ? ' cm-pane--active' : ''; ?>" data-pane="notifications">
                    <div class="cm-card cm-card--blue">
                        <div class="cm-card-head">
                            <h2 style="color:#0a4b78;">📬 Notification Recipients</h2>
                            <p>Send rich HTML notification emails to staff or managers when orders are submitted, pre-authorized, or confirmed. Each recipient gets a separate email.</p>
                        </div>

                        <div class="cm-field" style="margin-bottom:18px;">
                            <label><strong>Email Addresses</strong><em>One per line, or comma/semicolon separated. Invalid addresses are ignored on save.</em></label>
                            <textarea name="caterme_settings[notify_emails]" rows="4" class="cm-textarea" style="border-color:#90c5f0;font-family:monospace;" placeholder="manager@yourdomain.com&#10;chef@yourdomain.com"><?php echo esc_textarea($s['notify_emails']??''); ?></textarea>
                            <?php
                            $current_emails = array_filter( array_map('trim', preg_split('/[\s,;]+/', $s['notify_emails']??'')) );
                            if ( ! empty($current_emails) ): ?>
                            <div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;">
                                <?php foreach ($current_emails as $em): ?>
                                <span class="cm-pill">✉️ <?php echo esc_html($em); ?></span>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="cm-field" style="margin-bottom:20px;">
                            <label><strong>Email Subject Template</strong><em>Use <code>{order_number}</code> as a placeholder.</em></label>
                            <input type="text" name="caterme_settings[notify_subject]"
                                value="<?php echo esc_attr($s['notify_subject']??'New Catering Order: {order_number}'); ?>"
                                class="regular-text" style="border-color:#90c5f0;width:100%;max-width:500px;" />
                            <p style="margin-top:6px;font-size:12px;color:#555;">Preview: <em>"<?php echo esc_html(str_replace('{order_number}','CAT-20260213-001',$s['notify_subject']??'New Catering Order: {order_number}')); ?> — 🆕 New Order Received"</em></p>
                        </div>

                        <h3 style="color:#0a4b78;border-color:#90c5f0;font-size:13px;padding-bottom:8px;margin-bottom:16px;">When to Send</h3>
                        <div class="cm-notify-grid">
                            <?php
                            $notify_opts = array(
                                'notify_on_new'       => array('🆕 New Order Submitted',     'Fires immediately when a customer submits the catering form, before payment.'),
                                'notify_on_paid'      => array('💳 Payment Pre-Authorized',   'Fires when the customer\'s card is successfully pre-authorized (WC order moves to on-hold). Requires WooCommerce.'),
                                'notify_on_confirmed' => array('✅ Order Confirmed & Charged', 'Fires when you set the order status to Confirmed and payment capture succeeds.'),
                            );
                            foreach ($notify_opts as $key => list($title, $desc)): ?>
                            <div class="cm-notify-item">
                                <div class="cm-tog-row">
                                    <label class="cm-tog-switch" for="cm_<?php echo $key; ?>">
                                        <input type="checkbox" id="cm_<?php echo $key; ?>" name="caterme_settings[<?php echo $key; ?>]" value="1" <?php checked($s[$key]??'1','1'); ?> />
                                        <span class="cm-tog-track"><span class="cm-tog-thumb"></span></span>
                                    </label>
                                    <label class="cm-tog-text" for="cm_<?php echo $key; ?>"><strong><?php echo $title; ?></strong></label>
                                </div>
                                <p class="cm-tog-desc"><?php echo esc_html($desc); ?></p>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="cm-infobox" style="margin-top:16px;">
                            <strong>📧 What's included in each email:</strong> Order number, fulfillment type &amp; date/time, full itemized list with customizations and dietary flags, customer name/phone/email, order total, payment status, and a direct admin link to view/manage the order.
                        </div>

                        <div style="margin-top:16px;">
                            <button type="button" id="caterme-test-email" class="button" <?php echo empty($s['notify_emails']) ? 'disabled title="Add recipients first"' : ''; ?>>
                                📤 Send Test Email
                            </button>
                            <span id="caterme-test-status" style="margin-left:12px;font-size:13px;"></span>
                        </div>
                    </div>
                </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: PRINT & EMAIL
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='print' ? ' cm-pane--active' : ''; ?>" data-pane="print">

                    <!-- Logo -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🖼️ Logo</h2>
                            <p>Displayed in label headers and customer email headers. Leave blank to show your store name as text instead.</p>
                        </div>
                        <div class="cm-field">
                            <label><strong>Logo URL</strong><em>Paste any publicly accessible image URL (PNG with transparent background works best).</em></label>
                            <div style="display:flex;align-items:center;gap:12px;margin-top:6px;flex-wrap:wrap;">
                                <input type="url" name="caterme_settings[logo_url]" id="caterme_logo_url"
                                    value="<?php echo esc_attr($s['logo_url']??''); ?>"
                                    placeholder="https://yourdomain.com/logo.png"
                                    class="regular-text" style="flex:1;min-width:240px;" />
                                <div id="caterme-logo-preview" style="<?php echo empty($s['logo_url']) ? 'display:none;' : ''; ?>height:52px;border:1px solid #ddd;border-radius:8px;padding:5px 10px;background:#fff;">
                                    <img src="<?php echo esc_attr($s['logo_url']??''); ?>" alt="Logo preview" style="max-height:42px;max-width:160px;object-fit:contain;" />
                                </div>
                            </div>
                        </div>
                        <div class="cm-2col" style="margin-top:16px;">
                            <div class="cm-field">
                                <label><strong>Logo Size on Labels</strong><em>Max height in pixels (16–60 px).</em></label>
                                <div class="cm-range-row" style="margin-top:6px;">
                                    <input type="range" name="caterme_settings[label_logo_height]" id="label_logo_height_range"
                                        min="16" max="60" value="<?php echo esc_attr($s['label_logo_height']??'28'); ?>"
                                        oninput="document.getElementById('label_logo_height_val').textContent=this.value+'px';" />
                                    <span id="label_logo_height_val" class="cm-range-val"><?php echo esc_attr($s['label_logo_height']??'28'); ?>px</span>
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Logo Size in Emails</strong><em>Max height in pixels (30–120 px).</em></label>
                                <div class="cm-range-row" style="margin-top:6px;">
                                    <input type="range" name="caterme_settings[email_logo_height]" id="email_logo_height_range"
                                        min="30" max="120" value="<?php echo esc_attr($s['email_logo_height']??'56'); ?>"
                                        oninput="document.getElementById('email_logo_height_val').textContent=this.value+'px'; rpEmail();" />
                                    <span id="email_logo_height_val" class="cm-range-val"><?php echo esc_attr($s['email_logo_height']??'56'); ?>px</span>
                                </div>
                            </div>
                        </div>
                        <div class="cm-2col" style="margin-top:16px;">
                            <div class="cm-field">
                                <label><strong>Logo Alignment on Labels</strong><em>Position the logo within the label header.</em></label>
                                <div style="display:flex;gap:8px;margin-top:8px;">
                                    <?php foreach (['left'=>'⬅ Left','center'=>'⬛ Center','right'=>'➡ Right'] as $val=>$lbl): ?>
                                    <label class="cm-choice <?php echo ($s['label_logo_align']??'left')===$val?'cm-choice--active':''; ?>" style="flex:1;text-align:center;">
                                        <input type="radio" name="caterme_settings[label_logo_align]" value="<?php echo $val; ?>" <?php checked($s['label_logo_align']??'left',$val); ?> />
                                        <?php echo $lbl; ?>
                                    </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Logo Alignment in Emails</strong><em>Position the logo within the email header.</em></label>
                                <div style="display:flex;gap:8px;margin-top:8px;">
                                    <?php foreach (['left'=>'⬅ Left','center'=>'⬛ Center','right'=>'➡ Right'] as $val=>$lbl): ?>
                                    <label class="cm-choice <?php echo ($s['email_logo_align']??'center')===$val?'cm-choice--active':''; ?>" style="flex:1;text-align:center;">
                                        <input type="radio" name="caterme_settings[email_logo_align]" value="<?php echo $val; ?>" <?php checked($s['email_logo_align']??'center',$val); ?> />
                                        <?php echo $lbl; ?>
                                    </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Labels -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🏷️ Label Settings</h2>
                            <p>Controls how order labels print. Labels are formatted for Avery 5163 (2×4") sheets.</p>
                        </div>
                        <div class="cm-2col">
                            <div class="cm-field">
                                <label><strong>Orientation</strong><em>Portrait = 2"w × 4"h · Landscape = 4"w × 2"h</em></label>
                                <div style="display:flex;gap:10px;margin-top:8px;">
                                    <?php foreach (array('portrait'=>'📄 Portrait','landscape'=>'📋 Landscape') as $val=>$lbl): ?>
                                    <label class="cm-choice<?php echo ($s['label_orientation']??'portrait')===$val ? ' cm-choice--active' : ''; ?>">
                                        <input type="radio" name="caterme_settings[label_orientation]" value="<?php echo $val; ?>" <?php checked($s['label_orientation']??'portrait',$val); ?> />
                                        <?php echo $lbl; ?>
                                    </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Label Font</strong></label>
                                <select name="caterme_settings[label_font]" class="cm-sel" style="margin-top:6px;">
                                    <?php foreach (array('Arial, Helvetica, sans-serif'=>'Arial','Helvetica, Arial, sans-serif'=>'Helvetica','Verdana, sans-serif'=>'Verdana','Tahoma, sans-serif'=>'Tahoma','Georgia, serif'=>'Georgia','Times New Roman, serif'=>'Times New Roman') as $val=>$lbl): ?>
                                    <option value="<?php echo esc_attr($val); ?>" <?php selected($s['label_font']??'Arial, Helvetica, sans-serif',$val); ?>><?php echo $lbl; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="cm-field">
                                <label><strong>Item Name Size</strong><em>Font size for the main item name (7–18 pt).</em></label>
                                <div class="cm-range-row" style="margin-top:6px;">
                                    <input type="range" name="caterme_settings[label_font_size]" id="lbl_font_size_range" min="7" max="18" value="<?php echo esc_attr($s['label_font_size']??'11'); ?>" oninput="document.getElementById('lbl_font_size_val').textContent=this.value+'pt';" />
                                    <span id="lbl_font_size_val" class="cm-range-val"><?php echo esc_attr($s['label_font_size']??'11'); ?>pt</span>
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Font Weight</strong></label>
                                <div style="display:flex;gap:10px;margin-top:8px;">
                                    <?php foreach (array('normal'=>'Normal','bold'=>'Bold') as $val=>$lbl): ?>
                                    <label class="cm-choice<?php echo ($s['label_font_weight']??'bold')===$val ? ' cm-choice--active' : ''; ?>" style="font-weight:<?php echo $val; ?>;">
                                        <input type="radio" name="caterme_settings[label_font_weight]" value="<?php echo $val; ?>" <?php checked($s['label_font_weight']??'bold',$val); ?> />
                                        <?php echo $lbl; ?>
                                    </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Primary Color</strong><em>Store name, item name, date.</em></label>
                                <div class="cm-clr-row" style="margin-top:6px;">
                                    <input type="color" id="label_color_primary" name="caterme_settings[label_color_primary]" value="<?php echo esc_attr($s['label_color_primary']??'#1a1208'); ?>" />
                                    <input type="text" class="caterme-hex" data-for="label_color_primary" value="<?php echo esc_attr($s['label_color_primary']??'#1a1208'); ?>" maxlength="7" />
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Accent Color</strong><em>Person name highlight, dietary flags.</em></label>
                                <div class="cm-clr-row" style="margin-top:6px;">
                                    <input type="color" id="label_color_accent" name="caterme_settings[label_color_accent]" value="<?php echo esc_attr($s['label_color_accent']??'#c8832a'); ?>" />
                                    <input type="text" class="caterme-hex" data-for="label_color_accent" value="<?php echo esc_attr($s['label_color_accent']??'#c8832a'); ?>" maxlength="7" />
                                </div>
                            </div>
                        </div>

                        <!-- Label Preview -->
                        <div style="margin-top:20px;">
                            <p class="cm-preview-label">Label Preview (actual size: 4" × 2")</p>
                            <div id="caterme-label-preview" class="cm-label-prev" style="font-family:<?php echo esc_attr($s['label_font']??'Arial, Helvetica, sans-serif'); ?>;">
                                <!-- Top bar -->
                                <div id="lpv-top" style="display:flex;justify-content:space-between;align-items:center;border-bottom:1.5px solid <?php echo esc_attr($s['label_color_primary']??'#1a1208'); ?>;padding-bottom:3px;margin-bottom:4px;flex-shrink:0;">
                                    <?php if (!empty($s['logo_url'])): ?>
                                        <img id="lpv-logo-img" src="<?php echo esc_url($s['logo_url']); ?>" alt="logo"
                                            style="max-height:<?php echo esc_attr($s['label_logo_height']??'28'); ?>px;max-width:<?php echo min(120,(int)($s['label_logo_height']??28)*4); ?>px;height:auto;object-fit:contain;display:block;" />
                                        <div id="lpv-store" style="display:none;font-size:8.5pt;font-weight:900;letter-spacing:0.8px;text-transform:uppercase;color:<?php echo esc_attr($s['label_color_primary']??'#1a1208'); ?>;"><?php echo esc_html($s['store_name']??'Boone\'s Deli'); ?></div>
                                    <?php else: ?>
                                        <img id="lpv-logo-img" src="" alt="logo" style="display:none;max-height:28px;max-width:112px;height:auto;object-fit:contain;" />
                                        <div id="lpv-store" style="font-size:8.5pt;font-weight:900;letter-spacing:0.8px;text-transform:uppercase;color:<?php echo esc_attr($s['label_color_primary']??'#1a1208'); ?>;"><?php echo esc_html($s['store_name']??'Boone\'s Deli'); ?></div>
                                    <?php endif; ?>
                                    <span style="font-size:7pt;color:#bbb;margin-left:6px;flex-shrink:0;">CAT-001</span>
                                </div>
                                <!-- Body -->
                                <div style="flex:1;display:flex;flex-direction:column;justify-content:flex-start;overflow:hidden;min-height:0;">
                                    <div id="lpv-person" style="font-size:13pt;font-weight:900;color:<?php echo esc_attr($s['label_color_accent']??'#c8832a'); ?>;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Jane Smith</div>
                                    <div id="lpv-item" style="font-size:<?php echo esc_attr($s['label_font_size']??'11'); ?>pt;font-weight:<?php echo esc_attr($s['label_font_weight']??'bold'); ?>;color:<?php echo esc_attr($s['label_color_primary']??'#1a1208'); ?>;line-height:1.2;margin-top:1px;">Standard Sandwich Box</div>
                                    <div id="lpv-sels" style="font-size:7.5pt;color:#444;line-height:1.35;margin-top:2px;">Turkey · Wheat Bread · Zapp's Chips · No Onion</div>
                                    <div style="font-size:7pt;color:<?php echo esc_attr($s['label_color_accent']??'#c8832a'); ?>;font-weight:700;margin-top:2px;">⚠️ Gluten-Free</div>
                                </div>
                                <!-- Footer -->
                                <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #ddd;padding-top:3px;margin-top:3px;flex-shrink:0;">
                                    <span id="lpv-dt" style="font-size:7.5pt;font-weight:700;color:<?php echo esc_attr($s['label_color_primary']??'#1a1208'); ?>;">Fri, Feb 14 12:00 pm</span>
                                    <span style="font-size:7.5pt;color:#888;">🏪 Pick Up</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Email Appearance -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>📧 Email Appearance</h2>
                            <p>Controls the look of quote and payment-link emails sent to customers.</p>
                        </div>
                        <div class="cm-2col">
                            <div class="cm-field">
                                <label><strong>Email Font</strong></label>
                                <select name="caterme_settings[email_font]" class="cm-sel" style="margin-top:6px;">
                                    <?php foreach (array('Georgia, serif'=>'Georgia','Palatino Linotype, serif'=>'Palatino','Times New Roman, serif'=>'Times New Roman','Arial, sans-serif'=>'Arial','Helvetica, Arial, sans-serif'=>'Helvetica','Verdana, sans-serif'=>'Verdana','Tahoma, sans-serif'=>'Tahoma') as $val=>$lbl): ?>
                                    <option value="<?php echo esc_attr($val); ?>" <?php selected($s['email_font']??'Georgia, serif',$val); ?>><?php echo $lbl; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="cm-field">
                                <label><strong>Body Font Size</strong><em>10–20 px</em></label>
                                <div class="cm-range-row" style="margin-top:6px;">
                                    <input type="range" name="caterme_settings[email_font_size]" id="email_font_size_range" min="10" max="20" value="<?php echo esc_attr($s['email_font_size']??'14'); ?>" oninput="document.getElementById('email_font_size_val').textContent=this.value+'px';" />
                                    <span id="email_font_size_val" class="cm-range-val"><?php echo esc_attr($s['email_font_size']??'14'); ?>px</span>
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Header Background</strong><em>The dark bar at the top of emails.</em></label>
                                <div class="cm-clr-row" style="margin-top:6px;">
                                    <input type="color" id="email_color_header" name="caterme_settings[email_color_header]" value="<?php echo esc_attr($s['email_color_header']??'#1a1208'); ?>" />
                                    <input type="text" class="caterme-hex" data-for="email_color_header" value="<?php echo esc_attr($s['email_color_header']??'#1a1208'); ?>" maxlength="7" />
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Accent Color</strong><em>Buttons, price totals, highlights.</em></label>
                                <div class="cm-clr-row" style="margin-top:6px;">
                                    <input type="color" id="email_color_accent" name="caterme_settings[email_color_accent]" value="<?php echo esc_attr($s['email_color_accent']??'#c8832a'); ?>" />
                                    <input type="text" class="caterme-hex" data-for="email_color_accent" value="<?php echo esc_attr($s['email_color_accent']??'#c8832a'); ?>" maxlength="7" />
                                </div>
                            </div>
                            <div class="cm-field">
                                <label><strong>Body Text Color</strong></label>
                                <div class="cm-clr-row" style="margin-top:6px;">
                                    <input type="color" id="email_color_text" name="caterme_settings[email_color_text]" value="<?php echo esc_attr($s['email_color_text']??'#1a1208'); ?>" />
                                    <input type="text" class="caterme-hex" data-for="email_color_text" value="<?php echo esc_attr($s['email_color_text']??'#1a1208'); ?>" maxlength="7" />
                                </div>
                            </div>
                        </div>

                        <!-- Email Preview -->
                        <div style="margin-top:20px;">
                            <p class="cm-preview-label">Email Preview</p>
                            <div class="cm-email-prev">
                                <div id="epv-header" style="background:<?php echo esc_attr($s['email_color_header']??'#1a1208'); ?>;padding:16px 20px;border-radius:8px 8px 0 0;text-align:center;">
                                    <img id="epv-logo-img" src="<?php echo esc_attr($s['logo_url']??''); ?>" alt="logo"
                                        style="<?php echo empty($s['logo_url']) ? 'display:none;' : ''; ?>max-height:<?php echo esc_attr($s['email_logo_height']??'56'); ?>px;max-width:280px;height:auto;object-fit:contain;display:<?php echo empty($s['logo_url']) ? 'none' : 'inline-block'; ?>;" />
                                    <div id="epv-store" style="<?php echo !empty($s['logo_url']) ? 'display:none;' : ''; ?>font-family:<?php echo esc_attr($s['email_font']??'Georgia, serif'); ?>;font-size:18px;font-weight:900;color:#f5e6c8;letter-spacing:2px;text-transform:uppercase;"><?php echo esc_html($s['store_name']??'Boone\'s Deli'); ?></div>
                                    <p style="color:#b8996a;font-size:11px;letter-spacing:2px;text-transform:uppercase;margin:6px 0 0;">Catering Quote</p>
                                </div>
                                <div id="epv-body" style="padding:16px 20px;font-family:<?php echo esc_attr($s['email_font']??'Georgia, serif'); ?>;font-size:<?php echo esc_attr($s['email_font_size']??'14'); ?>px;color:<?php echo esc_attr($s['email_color_text']??'#1a1208'); ?>;background:#fff;border-radius:0 0 8px 8px;">
                                    <p style="margin:0 0 10px;">Hi Jane, here is your catering quote.</p>
                                    <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #eee;font-size:13px;">
                                        <span>Standard Sandwich Box ×2<br><span style="font-size:11px;color:#888;">Turkey · Wheat · Chips</span></span>
                                        <strong id="epv-price" style="color:<?php echo esc_attr($s['email_color_accent']??'#c8832a'); ?>;">$24.00</strong>
                                    </div>
                                    <div style="text-align:center;margin-top:14px;">
                                        <span id="epv-btn" style="background:<?php echo esc_attr($s['email_color_accent']??'#c8832a'); ?>;color:#fff;padding:10px 22px;border-radius:6px;font-weight:700;font-size:14px;display:inline-block;">💳 Complete Payment</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: INTEGRATIONS
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='integrations' ? ' cm-pane--active' : ''; ?>" data-pane="integrations">
                    <div class="cm-card cm-card--green">
                        <div class="cm-card-head">
                            <h2 style="color:#1a6630;">📊 Google Sheets Integration</h2>
                            <p>Automatically log each order as a new row in your Google Sheet.</p>
                        </div>

                        <details class="cm-details cm-details--green" open>
                            <summary>📋 Setup Instructions</summary>
                            <div class="cm-details-body">
                                <ol class="cm-list cm-list--ol">
                                    <li>Open your Google Sheet → <strong>Extensions → Apps Script</strong></li>
                                    <li>Paste the script below, save it, then <strong>Deploy → New deployment</strong> as a Web App</li>
                                    <li>Set access to <strong>Anyone</strong>, authorize, then copy the Web App URL</li>
                                    <li>Paste that URL in the field below and save settings</li>
                                </ol>
                            </div>
                        </details>

                        <div style="position:relative;margin:16px 0;">
                            <pre id="apps-script-code" class="cm-code-block">function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(['Order #','Timestamp','Type','Date','Time','Customer','Phone','Email','Items','Details','Subtotal','Notes','Status']);
      sheet.getRange(1,1,1,13).setFontWeight('bold');
      sheet.setFrozenRows(1);
    }
    var itemsList   = (data.items||[]).map(function(i){ return i.qty+'x '+i.name; }).join(', ');
    var detailsList = (data.items||[]).map(function(i){ return i.qty+'x '+i.name+(i.selections&&i.selections.length?' ('+i.selections.join(' | ')+')':''); }).join('\n');
    sheet.appendRow([data.order_number,new Date(data.timestamp),data.fulfillment==='pickup'?'Pick Up':'Delivery',data.orderDate||'',data.orderTime||'',data.customer_name||'',data.customer_phone||'',data.customer_email||'',itemsList,detailsList,data.subtotal||0,data.notes||'','New']);
    return ContentService.createTextOutput(JSON.stringify({success:true})).setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({success:false,error:err.toString()})).setMimeType(ContentService.MimeType.JSON);
  }
}</pre>
                            <button type="button" onclick="copyScript()" class="cm-copy-btn">Copy</button>
                        </div>

                        <div class="cm-field">
                            <label><strong>Web App URL</strong><em>Paste your deployed Apps Script URL here.</em></label>
                            <input type="url" name="caterme_settings[sheets_webhook]"
                                value="<?php echo esc_attr($s['sheets_webhook']??''); ?>"
                                placeholder="https://script.google.com/macros/s/YOUR_ID/exec"
                                class="regular-text" style="width:100%;max-width:580px;border-color:#a8d5b5;margin-top:6px;" />
                            <?php if (!empty($s['sheets_webhook'])): ?>
                            <p style="color:#1a6630;font-size:12px;margin-top:6px;">✅ Webhook configured.</p>
                            <?php else: ?>
                            <p style="color:#888;font-size:12px;margin-top:6px;">⚠️ No URL set — orders won't sync to Sheets until configured.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php caterme_render_telemetry_settings( $s ); ?>
                </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: AVAILABILITY
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='availability' ? ' cm-pane--active' : ''; ?>" data-pane="availability">

                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>📅 Blackout Dates & Times</h2>
                            <p>Prevent customers from selecting specific days or dates for pickup and/or delivery. Perfect for holidays, planned closures, or days when you're at capacity.</p>
                        </div>
                    </div>

                    <!-- ── Pickup Availability ──────────────────────────────── -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🏪 Pickup Availability</h2>
                        </div>

                        <div class="cm-field" style="margin-bottom:18px;">
                            <label><strong>Closed Days of Week</strong> <em>Block pickup on specific weekdays every week.</em></label>
                            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-top:10px;">
                                <?php
                                $days = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
                                $pickup_closed = array_map('strtolower', array_filter(explode(',', $s['pickup_closed_days']??'')));
                                foreach ($days as $day):
                                    $checked = in_array(strtolower($day), $pickup_closed);
                                ?>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;border:1.5px solid <?php echo $checked?'#c8832a':'#ddd'; ?>;border-radius:6px;cursor:pointer;background:<?php echo $checked?'#fff7ed':'#fff'; ?>;font-size:13px;">
                                    <input type="checkbox" name="caterme_settings[pickup_closed_days][]" value="<?php echo strtolower($day); ?>" <?php checked($checked); ?> style="margin:0;" />
                                    <?php echo $day; ?>
                                </label>
                                <?php endforeach; ?>
                            </div>
                            <p style="font-size:12px;color:#888;margin:8px 0 0;">Customers won't be able to select these days for pickup.</p>
                        </div>

                        <div class="cm-field">
                            <label><strong>Blocked Specific Dates</strong> <em>One-time closures (e.g. holidays). Comma-separated YYYY-MM-DD format.</em></label>
                            <textarea name="caterme_settings[pickup_blocked_dates]" rows="3"
                                      placeholder="2026-12-25, 2026-01-01, 2026-07-04"
                                      style="width:100%;max-width:600px;border:1.5px solid #ddd;border-radius:6px;padding:10px 12px;font-size:13px;font-family:monospace;margin-top:8px;box-sizing:border-box;"><?php echo esc_textarea($s['pickup_blocked_dates']??''); ?></textarea>
                            <p style="font-size:12px;color:#888;margin:6px 0 0;">Enter dates in YYYY-MM-DD format, separated by commas.</p>
                        </div>
                    </div>

                    <!-- ── Delivery Availability ────────────────────────────── -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🚗 Delivery Availability</h2>
                        </div>

                        <div class="cm-field" style="margin-bottom:18px;">
                            <label><strong>Closed Days of Week</strong> <em>Block delivery on specific weekdays every week.</em></label>
                            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-top:10px;">
                                <?php
                                $delivery_closed = array_map('strtolower', array_filter(explode(',', $s['delivery_closed_days']??'')));
                                foreach ($days as $day):
                                    $checked = in_array(strtolower($day), $delivery_closed);
                                ?>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;border:1.5px solid <?php echo $checked?'#c8832a':'#ddd'; ?>;border-radius:6px;cursor:pointer;background:<?php echo $checked?'#fff7ed':'#fff'; ?>;font-size:13px;">
                                    <input type="checkbox" name="caterme_settings[delivery_closed_days][]" value="<?php echo strtolower($day); ?>" <?php checked($checked); ?> style="margin:0;" />
                                    <?php echo $day; ?>
                                </label>
                                <?php endforeach; ?>
                            </div>
                            <p style="font-size:12px;color:#888;margin:8px 0 0;">Customers won't be able to select these days for delivery.</p>
                        </div>

                        <div class="cm-field">
                            <label><strong>Blocked Specific Dates</strong> <em>One-time closures. Comma-separated YYYY-MM-DD format.</em></label>
                            <textarea name="caterme_settings[delivery_blocked_dates]" rows="3"
                                      placeholder="2026-12-25, 2026-01-01, 2026-07-04"
                                      style="width:100%;max-width:600px;border:1.5px solid #ddd;border-radius:6px;padding:10px 12px;font-size:13px;font-family:monospace;margin-top:8px;box-sizing:border-box;"><?php echo esc_textarea($s['delivery_blocked_dates']??''); ?></textarea>
                            <p style="font-size:12px;color:#888;margin:6px 0 0;">Enter dates in YYYY-MM-DD format, separated by commas.</p>
                        </div>
                    </div>

                </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: TOOLS
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='tools' ? ' cm-pane--active' : ''; ?>" data-pane="tools">

                    <?php if ( ! empty($_GET['caterme_import_result']) ): ?>
                    <div class="notice notice-success is-dismissible" style="margin-bottom:16px;"><p><?php echo esc_html(rawurldecode($_GET['caterme_import_result'])); ?></p></div>
                    <?php endif; ?>

                    <!-- ── Lead Time ───────────────────────────────────────── -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>⏱️ Minimum Lead Time</h2>
                            <p>Require orders to be placed at least this far in advance. The date picker on the customer form will block any date/time sooner than this.</p>
                        </div>
                        <div class="cm-field" style="max-width:260px;">
                            <label><strong>Minimum Hours in Advance</strong>
                                <em>Set to 0 to allow same-day orders with no restriction.</em>
                            </label>
                            <div style="display:flex;align-items:center;gap:10px;margin-top:8px;">
                                <input type="number" name="caterme_settings[lead_time_hours]"
                                       value="<?php echo esc_attr($s['lead_time_hours']??'24'); ?>"
                                       min="0" max="720" step="1"
                                       style="width:100px;border:1.5px solid #ddd;border-radius:6px;padding:7px 10px;font-size:14px;" />
                                <span style="font-size:13px;color:#666;">hours</span>
                            </div>
                            <p style="font-size:12px;color:#888;margin:6px 0 0;">Examples: 24 = 1 day, 48 = 2 days, 72 = 3 days</p>
                        </div>
                    </div>

                    <!-- ── Delivery Fees ───────────────────────────────────── -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>🚗 Tiered Delivery Fees</h2>
                            <p>Set fee tiers based on driving distance from your store. The highest threshold the customer's address exceeds wins. Requires your store location to be set below.</p>
                        </div>

                        <!-- Store Location -->
                        <div style="background:#faf7f2;border:1px solid #e8dcc8;border-radius:8px;padding:14px 16px;margin-bottom:18px;">
                            <p style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#666;margin:0 0 10px;">📍 Store Location (for distance calculation)</p>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">
                                <div>
                                    <label style="font-size:12px;color:#555;display:block;margin-bottom:3px;">Latitude</label>
                                    <input type="number" id="caterme-store-lat" name="caterme_settings[store_lat]"
                                           value="<?php echo esc_attr($s['store_lat']??''); ?>"
                                           step="any" placeholder="e.g. 35.2271"
                                           style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;" />
                                </div>
                                <div>
                                    <label style="font-size:12px;color:#555;display:block;margin-bottom:3px;">Longitude</label>
                                    <input type="number" id="caterme-store-lng" name="caterme_settings[store_lng]"
                                           value="<?php echo esc_attr($s['store_lng']??''); ?>"
                                           step="any" placeholder="e.g. -80.8431"
                                           style="width:100%;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;" />
                                </div>
                            </div>
                            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                                <button type="button" id="caterme-geocode-btn" class="button"
                                        style="font-size:12px;">
                                    📍 Geocode from Store Address
                                </button>
                                <span id="caterme-geocode-status" style="font-size:12px;color:#888;"></span>
                            </div>
                            <p style="font-size:11px;color:#aaa;margin:8px 0 0;">
                                Clicks your saved Store Address (General tab) against
                                <?php echo empty($s['gmaps_key']) ? 'OpenStreetMap Nominatim (free)' : 'Google Geocoding API'; ?>.
                                Or enter coordinates manually — find them at
                                <a href="https://www.latlong.net/" target="_blank" rel="noopener">latlong.net</a>.
                            </p>
                        </div>

                        <!-- Optional Google Maps key -->
                        <div class="cm-field" style="margin-bottom:18px;">
                            <label><strong>Google Maps API Key</strong> <em>Optional — improves geocoding accuracy.</em></label>
                            <input type="text" name="caterme_settings[gmaps_key]"
                                   value="<?php echo esc_attr($s['gmaps_key']??''); ?>"
                                   placeholder="AIzaSy..."
                                   style="width:100%;max-width:480px;border:1.5px solid #ddd;border-radius:6px;padding:7px 9px;font-size:13px;box-sizing:border-box;margin-top:6px;" />
                            <p style="font-size:11px;color:#888;margin:4px 0 0;">
                                Requires Geocoding API enabled. Leave blank to use free OpenStreetMap Nominatim.
                            </p>
                        </div>

                        <!-- Tiers table -->
                        <p style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#666;margin:0 0 10px;">Fee Tiers</p>
                        <div id="caterme-tiers-table" style="margin-bottom:12px;">
                            <!-- Rows rendered by JS -->
                        </div>
                        <button type="button" id="caterme-add-tier" class="button" style="font-size:12px;">+ Add Tier</button>
                        <p style="font-size:12px;color:#888;margin:8px 0 0;">
                            Tip: Add an "Over 0 miles" base tier to set a default delivery fee that applies everywhere, then add higher thresholds to override it at distance.
                        </p>
                        <!-- Hidden field stores tiers JSON -->
                        <input type="hidden" id="caterme-tiers-json" name="caterme_settings[delivery_tiers]"
                               value="<?php echo esc_attr($s['delivery_tiers']??'[]'); ?>" />
                    </div>

                    <!-- ── Sample Data ─────────────────────────────────────── -->
                    <div class="cm-card">
                        <div class="cm-card-head">
                            <h2>📦 Sample Menu Data</h2>
                            <p>Import a complete sample menu (Boone's Deli) as WooCommerce products to explore CaterMe's features immediately. Safe to run more than once — products that already exist (matched by slug) are skipped.</p>
                        </div>
                        <div style="display:flex;flex-direction:column;gap:10px;">
                            <div style="background:#faf7f2;border:1px solid #e8dcc8;border-radius:8px;padding:14px 16px;font-size:13px;line-height:1.7;">
                                <strong>Creates:</strong> 5 product categories with 20 products including full modifier configurations. Drinks and loose chips are automatically flagged <em>No Label</em>. All products are set to <em>hidden</em> catalog visibility.
                            </div>
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url('admin.php?page=caterme-settings&tab=tools&caterme_action=import_sample_data'), 'caterme_import_sample' ) ); ?>"
                               class="button button-primary" style="align-self:flex-start;"
                               onclick="return confirm('Import sample menu products? Products with matching slugs will be skipped.');">
                                📦 Import Sample Menu
                            </a>
                        </div>
                    </div>

                    <!-- ── How-to reference ────────────────────────────────── -->
                    <div class="cm-card cm-card--info">
                        <div class="cm-card-head">
                            <h2>📋 How Products Become Menu Items</h2>
                        </div>
                        <ul style="font-size:13px;line-height:2;margin:0;padding-left:20px;">
                            <li><strong>Category</strong> → Product Category tab in the order form. Add a CaterMe emoji icon on the category edit screen.</li>
                            <li><strong>Product Name &amp; Price</strong> → shown on the menu card.</li>
                            <li><strong>Short Description</strong> → item description.</li>
                            <li><strong>Unit Suffix</strong> → set in the CaterMe meta box (e.g. <em>/lb</em>).</li>
                            <li><strong>Sub-filter Tag</strong> → in-category tag pill filter.</li>
                            <li><strong>🚫 No Label</strong> → skip Avery label for this item.</li>
                            <li><strong>Modifiers</strong> → protein choices, add-ons, quantities, etc.</li>
                        </ul>
                    </div>

                </div>

                <?php /* ═══════════════════════════════════════════════════════
                    TAB: PLAN & LICENSE
                ═══════════════════════════════════════════════════════ */ ?>
                <div class="cm-pane<?php echo $active_tab==='plan' ? ' cm-pane--active' : ''; ?>" data-pane="plan">
                    <?php caterme_render_plan_tab(); ?>
                </div>

                <!-- Sticky Save Bar -->
                <div class="cm-save-bar">
                    <?php submit_button('Save Settings', 'primary', 'submit', false); ?>
                    <span class="cm-save-hint">Changes apply to all tabs when saved.</span>
                </div>

            </form>
        </div>
    </div>

    <style>
    /* ── Layout ── */
    .cm-admin { max-width:900px; }
    .cm-header { background:#1a1208; color:#f5e6c8; border-radius:12px; padding:20px 26px; margin-bottom:22px; display:flex; align-items:center; justify-content:space-between; }
    .cm-header-title { display:flex; align-items:center; gap:16px; }
    .cm-logo { font-size:36px; line-height:1; }
    .cm-header h1 { color:#f5e6c8; margin:0; font-size:22px; }
    .cm-header p { margin:3px 0 0; font-size:12px; color:#b8996a; }
    .cm-header code { background:rgba(255,255,255,.12); color:#f5e6c8; padding:2px 6px; border-radius:4px; font-size:12px; }

    /* ── Tabs ── */
    .cm-tab-wrap { position:relative; }
    .cm-tabs { display:flex; gap:2px; border-bottom:2px solid #e0d0b8; margin-bottom:0; flex-wrap:wrap; }
    .cm-tab { display:flex; align-items:center; gap:6px; padding:10px 18px; background:none; border:none; border-bottom:2px solid transparent; margin-bottom:-2px; cursor:pointer; font-size:13px; font-weight:600; color:#666; border-radius:6px 6px 0 0; transition:all .15s; }
    .cm-tab:hover { background:#faf7f2; color:#1a1208; }
    .cm-tab--active { color:#c8832a; border-bottom-color:#c8832a; background:#fffbf5; }
    .cm-tab-ico { font-size:16px; }

    /* ── Panes ── */
    .cm-pane { display:none; padding-top:20px; }
    .cm-pane--active { display:block; }

    /* ── Cards ── */
    .cm-hidden { display: none !important; }
    .cm-card { background:#fff; border:1px solid #e0d0b8; border-radius:10px; padding:22px 26px; margin-bottom:18px; }
    .cm-card--warning { border-color:#d97706; background:#fffbeb; }
    .cm-card--wc { border-color:#7c3aed; background:#f5f3ff; }
    .cm-card--blue { border-color:#2271b1; background:#f0f6ff; }
    .cm-card--green { border-color:#34a853; background:#f0faf3; }
    .cm-card--info { border-color:#e0d0b8; background:#faf7f2; }
    .cm-card-head h2 { margin:0 0 4px; font-size:16px; color:#1a1208; }
    .cm-card-head p { margin:0 0 18px; font-size:13px; color:#666; line-height:1.6; }
    .cm-divider { border:none; border-top:1px solid #f0e8d8; margin:22px 0; }

    /* ── Grid ── */
    .cm-2col { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
    .cm-notify-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    .cm-notify-item { background:#f0f6ff; border:1px solid #c3d9f5; border-radius:8px; padding:14px 16px; }
    .cm-tog-desc { font-size:12px; color:#888; margin:8px 0 0; line-height:1.5; }

    /* ── Fields ── */
    .cm-field { margin-bottom:4px; }
    .cm-field > label { display:block; margin-bottom:6px; }
    .cm-field > label strong { display:block; font-size:13px; color:#1a1208; margin-bottom:2px; }
    .cm-field > label em { display:block; font-size:11.5px; color:#aaa; font-style:normal; }
    .cm-sel { width:100%; padding:8px 10px; border:1.5px solid #ddd; border-radius:7px; font-size:13px; }
    .cm-textarea { width:100%; padding:9px 11px; border:1.5px solid #ddd; border-radius:7px; font-size:13px; line-height:1.6; resize:vertical; box-sizing:border-box; }
    .cm-font-preview { margin-top:7px; font-size:16px; padding:8px 12px; background:#faf7f2; border-radius:7px; color:#1a1208; border:1px solid #ede3d0; }
    .cm-clr-row { display:flex; align-items:center; gap:10px; }
    .cm-clr-row input[type=color] { width:44px; height:38px; border:1.5px solid #ddd; border-radius:8px; cursor:pointer; padding:2px; flex-shrink:0; }
    .caterme-hex { font-family:monospace; font-size:13px; width:88px; border:1.5px solid #ddd; border-radius:6px; padding:6px 9px; }
    .cm-range-row { display:flex; align-items:center; gap:12px; }
    .cm-range-row input[type=range] { flex:1; }
    .cm-range-val { font-weight:700; min-width:36px; font-size:13px; }

    /* ══════════════════════════════════════════════════════════════
       TOGGLE SWITCH — fully self-contained, no overlap possible
    ══════════════════════════════════════════════════════════════ */
    .cm-tog-row { display:flex; align-items:center; gap:12px; }
    .cm-tog-switch {
        display:inline-block;          /* fixed-size container */
        width:44px;
        height:24px;
        flex-shrink:0;
        cursor:pointer;
        position:relative;             /* contains all children */
    }
    .cm-tog-switch input {
        display:none;                  /* hidden — no position:absolute, no layout bleed */
    }
    .cm-tog-track {
        display:block;
        position:absolute;
        inset:0;
        background:#ccc;
        border-radius:12px;
        transition:background .2s;
    }
    .cm-tog-thumb {
        display:block;
        position:absolute;
        width:18px;
        height:18px;
        background:#fff;
        border-radius:50%;
        top:3px;
        left:3px;
        transition:left .2s;
        box-shadow:0 1px 4px rgba(0,0,0,.3);
        pointer-events:none;
    }
    /* Checked state: CSS adjacent-sibling on track, then descendant thumb */
    .cm-tog-switch input:checked + .cm-tog-track { background:#c8832a; }
    .cm-tog-switch input:checked + .cm-tog-track .cm-tog-thumb { left:23px; }
    .cm-tog-switch--disabled { opacity:.5; cursor:default; }
    .cm-tog-text { cursor:pointer; font-size:13px; color:#444; line-height:1.4; flex:1; }
    .cm-tog-text--warn { color:#92400e; }

    /* ── Misc UI ── */
    .cm-mode-row { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:4px; }
    .cm-mode-opt { display:block; border:2px solid #ddd; border-radius:10px; padding:16px; cursor:pointer; }
    .cm-mode-opt input { display:none; }
    .cm-mode-opt--active { border-color:#c8832a; background:#fff7ed; }
    .cm-mode-ico { font-size:22px; margin-bottom:5px; }
    .cm-mode-name { font-weight:700; font-size:14px; margin-bottom:3px; }
    .cm-mode-opt--active .cm-mode-name { color:#c8832a; }
    .cm-mode-desc { font-size:12px; color:#888; line-height:1.4; }

    .cm-choice { display:inline-flex; align-items:center; gap:7px; cursor:pointer; font-size:13px; border:1.5px solid #ddd; border-radius:8px; padding:8px 14px; background:#fff; transition:all .15s; }
    .cm-choice input { display:none; }
    .cm-choice--active { border-color:#c8832a; background:#fff7ed; color:#92400e; font-weight:600; }

    .cm-alert { padding:11px 15px; border-radius:8px; font-size:13px; line-height:1.6; }
    .cm-alert--success { background:#dcfce7; border:1px solid #86efac; color:#14532d; }
    .cm-alert--warning { background:#fef3c7; border:1px solid #f6d28a; color:#92400e; }
    .cm-alert--info { background:#dbeafe; border:1px solid #93c5fd; color:#1e3a5f; }

    .cm-infobox { background:#eff6ff; border:1px solid #93c5fd; border-radius:8px; padding:13px 16px; font-size:12.5px; color:#1e4d8c; line-height:1.7; }
    .cm-pill { background:#dbeafe; color:#1e3a5f; border:1px solid #93c5fd; border-radius:20px; padding:3px 12px; font-size:12px; font-family:monospace; }
    .cm-code-big { background:#1a1208; color:#f5e6c8; padding:10px 18px; border-radius:8px; font-size:16px; display:inline-block; }
    .cm-info-row { display:flex; gap:20px; flex-wrap:wrap; }
    .cm-info-item p { font-size:13px; color:#666; margin:8px 0 0; }

    .cm-details { border:1px solid #e0d0b8; border-radius:8px; margin-bottom:16px; overflow:hidden; }
    .cm-details summary { padding:12px 16px; cursor:pointer; font-weight:600; font-size:13px; background:#faf7f2; list-style:none; }
    .cm-details summary::-webkit-details-marker { display:none; }
    .cm-details summary::before { content:'▶ '; font-size:10px; }
    .cm-details[open] summary::before { content:'▼ '; }
    .cm-details--green { border-color:#a8d5b5; }
    .cm-details--green summary { background:#f0faf3; color:#1a6630; }
    .cm-details-body { padding:14px 18px; font-size:13px; color:#444; line-height:1.8; }

    .cm-list { padding-left:18px; }
    .cm-list li { margin-bottom:4px; }
    .cm-list--ol { list-style:decimal; }

    .cm-code-block { background:#1e1e2e; color:#cdd6f4; border-radius:8px; padding:14px; font-size:11.5px; line-height:1.6; overflow-x:auto; white-space:pre-wrap; word-break:break-word; margin:0; }
    .cm-copy-btn { position:absolute; top:10px; right:10px; background:#34a853; color:#fff; border:none; border-radius:6px; padding:6px 12px; cursor:pointer; font-size:12px; font-weight:700; }

    .cm-preview-label { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#888; margin:0 0 8px; }
    .cm-label-prev { display:inline-flex; flex-direction:column; justify-content:space-between; width:4in; height:2in; border:1.5px dashed #ddd; border-radius:6px; padding:10px 14px; background:#fff; box-sizing:border-box; }
    .cm-email-prev { border:1px solid #e0d0b8; border-radius:10px; overflow:hidden; max-width:480px; }

    /* ── Save bar ── */
    .cm-save-bar { background:#fff; border:1px solid #e0d0b8; border-radius:10px; padding:16px 22px; display:flex; align-items:center; gap:16px; position:sticky; bottom:20px; box-shadow:0 4px 20px rgba(0,0,0,.1); margin-top:4px; }
    .cm-save-hint { font-size:12px; color:#888; }

    @media(max-width:640px) {
        .cm-2col,.cm-mode-row,.cm-notify-grid { grid-template-columns:1fr; }
        .cm-tabs { gap:0; }
        .cm-tab { padding:8px 12px; font-size:12px; }
        .cm-tab-lbl { display:none; }
        .cm-tab-ico { font-size:20px; }
    }
    </style>

    <script>
    (function(){
        /* ── Tab switching ── */
        var tabs   = document.querySelectorAll('.cm-tab');
        var panes  = document.querySelectorAll('.cm-pane');
        var tabField = document.getElementById('cm_active_tab_field');

        tabs.forEach(function(btn){
            btn.addEventListener('click', function(){
                var target = this.dataset.tab;
                tabs.forEach(function(t){ t.classList.remove('cm-tab--active'); t.setAttribute('aria-selected','false'); });
                panes.forEach(function(p){ p.classList.remove('cm-pane--active'); });
                this.classList.add('cm-tab--active');
                this.setAttribute('aria-selected','true');
                var pane = document.querySelector('.cm-pane[data-pane="'+target+'"]');
                if(pane) pane.classList.add('cm-pane--active');
                if(tabField) tabField.value = target;
                // update URL hash without scroll
                history.replaceState(null,'','#'+target);
            });
        });

        // Restore tab from URL hash on load
        var hash = location.hash.replace('#','');
        if(hash){
            var btn = document.querySelector('.cm-tab[data-tab="'+hash+'"]');
            if(btn) btn.click();
        }

        /* ── Appearance: style mode toggle ── */
        document.querySelectorAll('[name="caterme_settings[style_mode]"]').forEach(function(r){
            r.addEventListener('change',function(){
                var b=document.getElementById('cm-custom-block');
                b.style.opacity=this.value==='custom'?'1':'0.45';
                b.style.pointerEvents=this.value==='custom'?'':'none';
                document.querySelectorAll('.cm-mode-opt').forEach(function(c){c.classList.remove('cm-mode-opt--active');});
                this.closest('.cm-mode-opt').classList.add('cm-mode-opt--active');
            });
        });

        /* ── Color pickers ↔ hex inputs sync ── */
        document.querySelectorAll('.caterme-hex').forEach(function(h){
            var id=h.dataset.for, p=document.getElementById(id);
            if(!p) return;
            h.addEventListener('input',function(){ if(/^#[0-9a-fA-F]{6}$/.test(this.value)){ p.value=this.value; rpAppearance(); rpEmail(); rpLabel(); } });
            p.addEventListener('input',function(){ h.value=this.value; rpAppearance(); rpEmail(); rpLabel(); });
        });

        /* ── Border radius slider ── */
        var rng=document.getElementById('border_radius'), rl=document.getElementById('radius_lbl');
        if(rng) rng.addEventListener('input',function(){if(rl)rl.textContent=this.value+'px'; rpAppearance();});

        /* ── Appearance live preview ── */
        var D=<?php echo json_encode(caterme_defaults()); ?>;
        function g(id){ return(document.getElementById(id)||{}).value||D[id]; }
        function rpAppearance(){
            var r=g('border_radius')+'px', c=document.getElementById('caterme-prev-card');
            if(!c)return;
            c.style.background=g('color_card'); c.style.borderColor=g('color_border'); c.style.borderRadius=r;
            c.style.fontFamily=g('font_body');
            var pn=document.getElementById('pv-name'); if(pn){pn.style.color=g('color_text');pn.style.fontFamily=g('font_heading');}
            var pp=document.getElementById('pv-price'); if(pp) pp.style.color=g('color_accent');
            var pd=document.getElementById('pv-desc'); if(pd) pd.style.color=g('color_text_muted');
            var pb=document.getElementById('pv-btn'); if(pb){pb.style.background=g('color_primary');pb.style.borderRadius=r;pb.style.fontFamily=g('font_body');}
        }

        /* ── Font selects update preview ── */
        document.querySelectorAll('[name="caterme_settings[font_heading]"],[name="caterme_settings[font_body]"]').forEach(function(sel){
            sel.addEventListener('change',function(){
                var prev=this.closest('.cm-field').querySelector('.cm-font-preview');
                if(prev) prev.style.fontFamily=this.value;
                rpAppearance();
            });
        });

        /* ── Label live preview ── */
        function rpLabel(){
            var lpv=document.getElementById('caterme-label-preview'); if(!lpv) return;
            var font=   (document.querySelector('[name="caterme_settings[label_font]"]')||{}).value||'Arial, Helvetica, sans-serif';
            var size=   (document.querySelector('[name="caterme_settings[label_font_size]"]')||{}).value||'11';
            var weight= (document.querySelector('[name="caterme_settings[label_font_weight]"]:checked')||{}).value||'bold';
            var pcol=   (document.getElementById('label_color_primary')||{}).value||'#1a1208';
            var acol=   (document.getElementById('label_color_accent')||{}).value||'#c8832a';
            var logoH=  (document.getElementById('label_logo_height_range')||{}).value||'28';
            var logoUrl=(document.getElementById('caterme_logo_url')||{}).value||'';

            lpv.style.fontFamily=font;

            // Top bar border color
            var top=document.getElementById('lpv-top');
            if(top) top.style.borderBottomColor=pcol;

            // Show logo or store name
            var logoImg=document.getElementById('lpv-logo-img');
            var storeTxt=document.getElementById('lpv-store');
            if(logoUrl && logoImg){
                logoImg.src=logoUrl;
                logoImg.style.maxHeight=logoH+'px';
                logoImg.style.maxWidth=Math.min(120,parseInt(logoH)*4)+'px';
                logoImg.style.display='block';
                if(storeTxt) storeTxt.style.display='none';
            } else {
                if(logoImg) logoImg.style.display='none';
                if(storeTxt){ storeTxt.style.display='block'; storeTxt.style.color=pcol; }
            }

            var p=document.getElementById('lpv-person');   if(p) p.style.color=acol;
            var i=document.getElementById('lpv-item');     if(i){i.style.fontSize=size+'pt';i.style.fontWeight=weight;i.style.color=pcol;}
            var d=document.getElementById('lpv-dt');       if(d) d.style.color=pcol;
        }
        document.querySelectorAll('[name="caterme_settings[label_font]"],[name="caterme_settings[label_font_size]"],[name="caterme_settings[label_font_weight]"]').forEach(function(el){
            el.addEventListener('change',rpLabel); el.addEventListener('input',rpLabel);
        });
        var lblLogoH=document.getElementById('label_logo_height_range');
        if(lblLogoH){ lblLogoH.addEventListener('input',rpLabel); }

        /* ── Email live preview ── */
        function rpEmail(){
            var hdr=document.getElementById('epv-header'), body=document.getElementById('epv-body'); if(!hdr||!body) return;
            var hcol=  (document.getElementById('email_color_header')||{}).value||'#1a1208';
            var acol=  (document.getElementById('email_color_accent')||{}).value||'#c8832a';
            var tcol=  (document.getElementById('email_color_text')||{}).value||'#1a1208';
            var font=  (document.querySelector('[name="caterme_settings[email_font]"]')||{}).value||'Georgia, serif';
            var fsize= (document.querySelector('[name="caterme_settings[email_font_size]"]')||{}).value||'14';
            var logoH= (document.getElementById('email_logo_height_range')||{}).value||'56';
            var logoUrl=(document.getElementById('caterme_logo_url')||{}).value||'';

            hdr.style.background=hcol;

            // Show logo or store name in email preview
            var logoImg=document.getElementById('epv-logo-img');
            var storeTxt=document.getElementById('epv-store');
            if(logoUrl && logoImg){
                logoImg.src=logoUrl;
                logoImg.style.maxHeight=logoH+'px';
                logoImg.style.display='inline-block';
                if(storeTxt) storeTxt.style.display='none';
            } else {
                if(logoImg) logoImg.style.display='none';
                if(storeTxt){ storeTxt.style.display='block'; storeTxt.style.fontFamily=font; }
            }

            body.style.fontFamily=font; body.style.fontSize=fsize+'px'; body.style.color=tcol;
            var price=document.getElementById('epv-price'); if(price) price.style.color=acol;
            var btn=document.getElementById('epv-btn');     if(btn)   btn.style.background=acol;
        }
        document.querySelectorAll('[name="caterme_settings[email_font]"],[name="caterme_settings[email_font_size]"]').forEach(function(el){
            el.addEventListener('change',rpEmail); el.addEventListener('input',rpEmail);
        });
        var emLogoH=document.getElementById('email_logo_height_range');
        if(emLogoH){ emLogoH.addEventListener('input',rpEmail); }

        /* ── Logo URL preview ── */
        var logoIn=document.getElementById('caterme_logo_url');
        if(logoIn) logoIn.addEventListener('input',function(){
            var prev=document.getElementById('caterme-logo-preview');
            var thumb=prev?prev.querySelector('img'):null;
            if(this.value&&thumb){ thumb.src=this.value; prev.style.display=''; }
            else if(prev) prev.style.display='none';
            // update both live previews
            rpLabel(); rpEmail();
        });

        /* ── Reset to defaults ── */
        var resetBtn=document.getElementById('caterme-reset');
        if(resetBtn) resetBtn.addEventListener('click',function(){
            if(!confirm('Reset all styling to defaults?')) return;
            Object.keys(D).forEach(function(k){
                var el=document.getElementById(k)||document.querySelector('[name="caterme_settings['+k+']"]');
                if(!el) return;
                if(el.type==='checkbox') el.checked=D[k]==='1'; else el.value=D[k];
                var h=document.querySelector('.caterme-hex[data-for="'+k+'"]'); if(h) h.value=D[k];
            });
            var customBtn=document.querySelector('[name="caterme_settings[style_mode]"][value="custom"]');
            if(customBtn) customBtn.click();
            if(rng&&rl){rl.textContent=D['border_radius']+'px';}
            rpAppearance();
        });

        /* ── Choice buttons (radio as styled pills) ── */
        document.querySelectorAll('.cm-choice').forEach(function(lbl){
            var inp=lbl.querySelector('input[type=radio]');
            if(!inp) return;
            inp.addEventListener('change',function(){
                var name=this.name;
                document.querySelectorAll('[name="'+name+'"]').forEach(function(r){
                    r.closest('.cm-choice').classList.toggle('cm-choice--active', r.checked);
                });
                rpLabel();
            });
        });

        /* ── Copy Apps Script ── */
        window.copyScript=function(){
            var c=document.getElementById('apps-script-code');
            if(!c) return;
            navigator.clipboard.writeText(c.textContent).then(function(){
                var b=document.querySelector('.cm-copy-btn');
                if(b){b.textContent='✓ Copied!'; setTimeout(function(){b.textContent='Copy';},2000);}
            });
        };

        /* ── Test email button ── */
        var testBtn=document.getElementById('caterme-test-email');
        if(testBtn){
            testBtn.addEventListener('click',function(){
                var status=document.getElementById('caterme-test-status');
                testBtn.disabled=true; testBtn.textContent='Sending…'; status.textContent='';
                fetch('<?php echo esc_url(rest_url('caterme/v1/test-email')); ?>',{
                    method:'POST',
                    headers:{'Content-Type':'application/json','X-WP-Nonce':'<?php echo wp_create_nonce('wp_rest'); ?>'}
                })
                .then(function(r){return r.json();})
                .then(function(json){
                    testBtn.disabled=false; testBtn.textContent='📤 Send Test Email';
                    if(json.success){status.style.color='#00a32a';status.textContent='✅ '+json.message;}
                    else{status.style.color='#d63638';status.textContent='⚠️ '+(json.message||'Failed.');}
                })
                .catch(function(){
                    testBtn.disabled=false; testBtn.textContent='📤 Send Test Email';
                    status.style.color='#d63638'; status.textContent='⚠️ Network error.';
                });
            });
        }

        /* ── Delivery Tiers table ── */
        (function(){
            var jsonField = document.getElementById('caterme-tiers-json');
            var tableEl   = document.getElementById('caterme-tiers-table');
            var addBtn    = document.getElementById('caterme-add-tier');
            if (!jsonField || !tableEl || !addBtn) return;

            var tiers = [];
            try { tiers = JSON.parse(jsonField.value || '[]') || []; } catch(e) {}

            function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

            function renderTiers() {
                if (!tiers.length) {
                    tableEl.innerHTML = '<p style="font-size:13px;color:#888;font-style:italic;padding:6px 0;">No delivery tiers set — delivery fee will be $0.00 for all orders.</p>';
                    saveTiers();
                    return;
                }
                var sorted = tiers.slice().sort(function(a,b){ return a.over_miles - b.over_miles; });
                var html = '<table style="width:100%;border-collapse:collapse;font-size:13px;">';
                html += '<thead><tr style="background:#faf7f2;"><th style="padding:7px 10px;text-align:left;font-weight:700;color:#555;border:1px solid #e8dcc8;">Over X miles</th><th style="padding:7px 10px;text-align:left;font-weight:700;color:#555;border:1px solid #e8dcc8;">Fee ($)</th><th style="padding:7px 10px;border:1px solid #e8dcc8;width:40px;"></th></tr></thead><tbody>';
                sorted.forEach(function(t, idx) {
                    var realIdx = tiers.indexOf(t);
                    html += '<tr style="background:#fff;">';
                    html += '<td style="padding:6px 8px;border:1px solid #e8dcc8;">';
                    html += '<input type="number" min="0" step="0.1" value="'+esc(t.over_miles)+'" style="width:100%;border:1px solid #ddd;border-radius:5px;padding:5px 7px;font-size:13px;box-sizing:border-box;" oninput="cmTierUpdate('+realIdx+',\'over_miles\',this.value)" />';
                    html += '</td>';
                    html += '<td style="padding:6px 8px;border:1px solid #e8dcc8;">';
                    html += '<input type="number" min="0" step="0.01" value="'+esc(t.fee)+'" style="width:100%;border:1px solid #ddd;border-radius:5px;padding:5px 7px;font-size:13px;box-sizing:border-box;" oninput="cmTierUpdate('+realIdx+',\'fee\',this.value)" />';
                    html += '</td>';
                    html += '<td style="padding:6px 8px;border:1px solid #e8dcc8;text-align:center;">';
                    html += '<button type="button" onclick="cmTierRemove('+realIdx+')" style="background:none;border:none;cursor:pointer;color:#cc3333;font-size:16px;line-height:1;" title="Remove">×</button>';
                    html += '</td></tr>';
                });
                html += '</tbody></table>';
                tableEl.innerHTML = html;
                saveTiers();
            }

            function saveTiers() {
                jsonField.value = JSON.stringify(tiers);
            }

            window.cmTierUpdate = function(idx, field, val) {
                if (!tiers[idx]) return;
                tiers[idx][field] = parseFloat(val) || 0;
                saveTiers();
            };

            window.cmTierRemove = function(idx) {
                tiers.splice(idx, 1);
                renderTiers();
            };

            addBtn.addEventListener('click', function() {
                tiers.push({ over_miles: 0, fee: 0 });
                renderTiers();
            });

            renderTiers();
        })();

        /* ── Geocode store address ── */
        (function(){
            var btn    = document.getElementById('caterme-geocode-btn');
            var status = document.getElementById('caterme-geocode-status');
            var latEl  = document.getElementById('caterme-store-lat');
            var lngEl  = document.getElementById('caterme-store-lng');
            if (!btn) return;
            btn.addEventListener('click', function() {
                btn.disabled = true; btn.textContent = '⏳ Locating…'; status.textContent = '';
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=caterme_geocode_store&nonce=<?php echo wp_create_nonce('caterme_geocode_store'); ?>&address='+encodeURIComponent('<?php echo esc_js($s['store_address']??''); ?>')
                })
                .then(function(r){ return r.json(); })
                .then(function(data) {
                    btn.disabled = false; btn.textContent = '📍 Geocode from Store Address';
                    if (data.success) {
                        latEl.value = data.data.lat;
                        lngEl.value = data.data.lng;
                        status.style.color = '#00a32a';
                        status.textContent = '✅ ' + data.data.message;
                    } else {
                        status.style.color = '#d63638';
                        status.textContent = '⚠️ ' + (data.data && data.data.message ? data.data.message : 'Geocoding failed.');
                    }
                })
                .catch(function() {
                    btn.disabled = false; btn.textContent = '📍 Geocode from Store Address';
                    status.style.color = '#d63638'; status.textContent = '⚠️ Network error.';
                });
            });
        })();
    })();
    </script>
    <?php
}

// ─────────────────────────────────────────────────────────────────────────────
// REST API — TEST EMAIL
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route('caterme/v1', '/test-email', array(
        'methods'             => 'POST',
        'callback'            => 'caterme_send_test_notification',
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));
});

function caterme_send_test_notification() {
    $recipients = caterme_get_notify_recipients();
    if ( empty($recipients) ) {
        return new WP_REST_Response( array('success'=>false,'message'=>'No valid recipient emails configured. Add addresses in Settings first.'), 400 );
    }

    $s = caterme_get_settings();

    // Build a fake order object for the preview
    $fake_order = (object) array(
        'id'             => 0,
        'order_number'   => 'CAT-TEST-001',
        'status'         => 'new',
        'fulfillment'    => 'pickup',
        'order_date'     => date('Y-m-d'),
        'order_time'     => '12:00:00',
        'subtotal'       => 47.50,
        'customer_name'  => 'Jane Sample',
        'customer_phone' => '(502) 555-0100',
        'customer_email' => 'jane@example.com',
        'notes'          => 'Please include extra napkins.',
        'wc_order_id'    => null,
        'payment_status' => 'authorized',
        'created_at'     => current_time('mysql'),
    );

    $fake_items = array(
        (object) array(
            'item_name'  => 'Premium Sandwich Box',
            'qty'        => 4,
            'unit_price' => 15.00,
            'line_total' => 60.00,
            'selections' => json_encode(array('Protein: Turkey', 'Bread: Wheat', 'Side: Zapp\'s Chips')),
            'dietary'    => 'Gluten-Free, No Onion',
        ),
        (object) array(
            'item_name'  => 'Killer Brownie',
            'qty'        => 4,
            'unit_price' => 3.50,
            'line_total' => 14.00,
            'selections' => json_encode(array()),
            'dietary'    => '',
        ),
    );

    $subject = '[TEST] ' . caterme_notify_subject(
        $s['notify_subject'] ?? 'New Catering Order: {order_number}',
        $fake_order->order_number,
        '🆕 New Order Received'
    );

    $body    = caterme_build_notification_email( 'new', '🆕 New Order Received', '#2271b1', $fake_order, $fake_items, $s );
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $s['store_name'] . ' <' . $s['store_email'] . '>',
    );

    $sent = 0;
    foreach ( $recipients as $to ) {
        if ( wp_mail( $to, $subject, $body, $headers ) ) $sent++;
    }

    if ( $sent > 0 ) {
        return new WP_REST_Response( array(
            'success' => true,
            'message' => "Test email sent to {$sent} recipient" . ($sent !== 1 ? 's' : '') . ': ' . implode(', ', $recipients),
        ), 200 );
    }

    return new WP_REST_Response( array(
        'success' => false,
        'message' => 'wp_mail() failed — check your WordPress email configuration (SMTP plugin recommended).',
    ), 500 );
}

// ─────────────────────────────────────────────────────────────────────────────
// REST API — ORDER SUBMISSION
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'rest_api_init', function() {
    register_rest_route('caterme/v1', '/submit', array(
        'methods'             => 'POST',
        'callback'            => 'caterme_handle_submit',
        'permission_callback' => '__return_true',
    ));
});

function caterme_generate_order_number() {
    global $wpdb;
    $table = $wpdb->prefix . 'caterme_orders';
    $today = date('Ymd');
    $count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE DATE(created_at)=CURDATE()") + 1;
    return 'CAT-' . $today . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);
}

function caterme_handle_submit( WP_REST_Request $request ) {
    global $wpdb;
    $settings     = caterme_get_settings();
    $orders_table = $wpdb->prefix . 'caterme_orders';
    $items_table  = $wpdb->prefix . 'caterme_order_items';

    $body = $request->get_json_params();
    if ( empty($body) ) {
        return new WP_REST_Response( array('success'=>false,'message'=>'No order data.'), 400 );
    }

    $order_number = caterme_generate_order_number();

    // Parse order date/time
    $order_date = sanitize_text_field( $body['orderDate'] ?? '' );
    $order_time = sanitize_text_field( $body['orderTime'] ?? '' );
    $order_date_val = $order_date ? date('Y-m-d', strtotime($order_date)) : null;
    $order_time_val = $order_time ? $order_time . ':00' : null;

    // Parse customer info from notes field (first line may contain name/contact)
    $raw_notes = sanitize_textarea_field( $body['notes'] ?? '' );
    $customer_name  = sanitize_text_field( $body['customer_name']  ?? '' );
    $customer_phone = sanitize_text_field( $body['customer_phone'] ?? '' );
    $customer_email = sanitize_email(      $body['customer_email'] ?? '' );

    $subtotal = floatval( $body['subtotal'] ?? 0 );
    $tip      = floatval( $body['tip']      ?? 0 );

    // Fulfillment & delivery
    $fulfillment      = sanitize_text_field( $body['fulfillment'] ?? 'pickup' );
    $delivery_address = sanitize_textarea_field( $body['delivery_address'] ?? '' );

    // ── Lead time validation ───────────────────────────────────────────────────
    $lead_hours = absint( $settings['lead_time_hours'] ?? 0 );
    if ( $lead_hours > 0 && $order_date_val && $order_time_val ) {
        $order_dt    = strtotime( $order_date_val . ' ' . $order_time_val );
        $min_allowed = time() + ( $lead_hours * 3600 );
        if ( $order_dt !== false && $order_dt < $min_allowed ) {
            return new WP_REST_Response( array(
                'success' => false,
                'message' => sprintf(
                    'Orders require at least %d hour%s advance notice. Please choose a later date/time.',
                    $lead_hours,
                    $lead_hours === 1 ? '' : 's'
                ),
            ), 400 );
        }
    }

    // ── Delivery fee calculation ───────────────────────────────────────────────
    $delivery_fee = 0.0;
    if ( $fulfillment === 'delivery' && $delivery_address ) {
        $fee_result = caterme_calc_delivery_fee( $delivery_address );
        if ( is_array($fee_result) ) {
            $delivery_fee = $fee_result['fee'];
        }
        // If null (store not configured) or false (geocoding failed), fee stays 0 — admin can adjust
    }

    // Order intake is always unlimited — feature gates (labels, invoices, tickets) apply instead.

    // Insert order
    $inserted = $wpdb->insert( $orders_table, array(
        'order_number'     => $order_number,
        'status'           => 'new',
        'fulfillment'      => $fulfillment,
        'order_date'       => $order_date_val,
        'order_time'       => $order_time_val,
        'subtotal'         => $subtotal,
        'delivery_fee'     => $delivery_fee,
        'tip'              => $tip,
        'customer_name'    => $customer_name,
        'customer_phone'   => $customer_phone,
        'customer_email'   => $customer_email,
        'delivery_address' => $delivery_address,
        'notes'            => $raw_notes,
        'created_at'       => current_time('mysql'),
    ));

    if ( ! $inserted ) {
        return new WP_REST_Response( array('success'=>false,'message'=>'Database error: '.$wpdb->last_error), 500 );
    }

    $order_id = $wpdb->insert_id;

    // ── Freemium: increment monthly counter + track event ──────────────────
    $new_count = caterme_increment_order_count();
    caterme_track_event( 'order_submitted', array(
        'order_number'   => $order_number,
        'fulfillment'    => $fulfillment,
        'subtotal'       => $subtotal,
        'item_count'     => count( $items ),
        'has_tip'        => $tip > 0,
        'has_delivery'   => $delivery_fee > 0,
        'month_count'    => $new_count,
    ) );

    // Insert items
    $items = $body['items'] ?? array();
    foreach ( $items as $item ) {
        $name       = sanitize_text_field( $item['name']  ?? '' );
        $qty        = max(1, absint( $item['qty']          ?? 1 ));
        $unit_price = floatval( $item['price']             ?? 0 );
        $line_total = $unit_price * $qty;

        $sels = array();
        if ( isset($item['selections']) && is_array($item['selections']) ) {
            foreach ($item['selections'] as $sel) {
                $sels[] = sanitize_text_field($sel);
            }
        }
        $dietary = '';
        if ( isset($item['dietary']) && is_array($item['dietary']) ) {
            $dietary = sanitize_text_field( implode(', ', $item['dietary']) );
        }

        $wpdb->insert( $items_table, array(
            'order_id'   => $order_id,
            'item_name'  => $name,
            'qty'        => $qty,
            'unit_price' => $unit_price,
            'line_total' => $line_total,
            'selections' => wp_json_encode( $sels ),
            'dietary'    => $dietary,
            'label_name' => sanitize_text_field( $item['label_name'] ?? '' ),
        ));
    }

    // Forward to Google Sheets if configured
    $webhook = $settings['sheets_webhook'] ?? '';
    $sheets_ok = false;
    if ( ! empty($webhook) ) {
        $payload = array(
            'order_number'   => $order_number,
            'timestamp'      => sanitize_text_field( $body['timestamp'] ?? date('c') ),
            'fulfillment'    => $body['fulfillment'] ?? 'pickup',
            'orderDate'      => $order_date,
            'orderTime'      => $order_time,
            'subtotal'       => $subtotal,
            'customer_name'  => $customer_name,
            'customer_phone' => $customer_phone,
            'customer_email' => $customer_email,
            'notes'          => $raw_notes,
            'items'          => $items,
        );
        $resp = wp_remote_post( $webhook, array(
            'headers' => array('Content-Type'=>'application/json'),
            'body'    => wp_json_encode($payload),
            'timeout' => 15,
        ));
        $sheets_ok = ( ! is_wp_error($resp) && wp_remote_retrieve_response_code($resp) === 200 );
    }

    // Send new-order notification email
    caterme_notify_new_order( $order_id );

    // ── WooCommerce: create order & return payment URL ─────────────────────────
    $payment_url = null;
    $test_mode   = ( $settings['test_mode'] ?? '0' ) === '1';
    $wc_enabled  = ( $settings['wc_enabled'] ?? '1' ) === '1';

    if ( ! $test_mode && $wc_enabled && caterme_wc_active() ) {
        $wc_data = array(
            'order_number'   => $order_number,
            'fulfillment'    => $fulfillment,
            'orderDate'      => $order_date,
            'orderTime'      => $order_time,
            'subtotal'       => $subtotal + $delivery_fee,
            'customer_name'  => $customer_name,
            'customer_phone' => $customer_phone,
            'customer_email' => $customer_email,
            'notes'          => $raw_notes,
        );

        $wc_order_id = caterme_create_wc_order( $order_id, $wc_data, $items );

        if ( ! is_wp_error($wc_order_id) ) {
            // Read back WC-calculated tax
            $wc_order_obj = wc_get_order( $wc_order_id );
            $wc_tax = $wc_order_obj ? round( floatval( $wc_order_obj->get_total_tax() ), 2 ) : 0;

            // Link the WC order to our catering order
            $wpdb->update( $orders_table,
                array(
                    'wc_order_id'    => $wc_order_id,
                    'payment_status' => 'pending',
                    'tax'            => $wc_tax,
                ),
                array( 'id' => $order_id )
            );
            // Return URL after payment — points back to the page with the form
            $return_url = add_query_arg( array(
                'caterme_order'  => $order_number,
                'caterme_paid'   => '1',
            ), get_permalink() ?: home_url('/') );

            $payment_url = caterme_get_wc_payment_url( $wc_order_id, $return_url );
        }
    }

    return new WP_REST_Response( array(
        'success'      => true,
        'order_number' => $order_number,
        'has_sheets'   => $sheets_ok,
        'payment_url'  => $payment_url,
        'test_mode'    => $test_mode,
        'wc_active'    => caterme_wc_active() && $wc_enabled && ! $test_mode,
        'message'      => $test_mode
            ? "✅ Order {$order_number} received! (Test Mode — no payment processed)"
            : ( $payment_url
                ? "Order {$order_number} saved! Redirecting to secure payment..."
                : ( $sheets_ok
                    ? "Order {$order_number} received and logged to Google Sheets!"
                    : "Order {$order_number} received! We'll be in touch shortly." ) ),
    ), 200 );
}

// ─────────────────────────────────────────────────────────────────────────────
// ENQUEUE SCRIPTS
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// SHORTCODE — fully self-contained, no global hooks
// ─────────────────────────────────────────────────────────────────────────────

function caterme_menu_shortcode() {
    $settings = caterme_get_settings();

    // Build settings payload — all values cast to their correct types
    $pub = array();
    foreach ( $settings as $k => $v ) {
        if ( $k === 'sheets_webhook' ) continue;
        $pub[ $k ] = ( $v === null ) ? '' : $v;
    }
    $pub['rest_url']           = (string) esc_url( rest_url( 'caterme/v1/submit' ) );
    $pub['rest_nonce']         = (string) wp_create_nonce( 'wp_rest' );
    $pub['delivery_fee_url']   = (string) esc_url( rest_url( 'caterme/v1/delivery-fee' ) );
    $pub['blocked_dates_url']  = (string) esc_url( rest_url( 'caterme/v1/blocked-dates' ) );
    $pub['wc_cart_add_url']    = (string) esc_url( rest_url( 'caterme/v1/cart/add' ) );
    $pub['wc_cart_update_url'] = (string) esc_url( rest_url( 'caterme/v1/cart/update' ) );
    $pub['wc_cart_remove_url'] = (string) esc_url( rest_url( 'caterme/v1/cart/remove' ) );
    $pub['wc_cart_get_url']    = (string) esc_url( rest_url( 'caterme/v1/cart/get' ) );
    $pub['wc_checkout_url']    = caterme_wc_active() ? (string) wc_get_checkout_url() : '';
    $pub['lead_time_hours']    = (int) ( $settings['lead_time_hours'] ?? 0 );
    $pub['store_lat']          = (float) ( $settings['store_lat'] ?? 0 );
    $pub['store_lng']          = (float) ( $settings['store_lng'] ?? 0 );
    $pub['has_sheets']         = ! empty( $settings['sheets_webhook'] );
    $pub['wc_active']          = caterme_wc_active() && ( ( $settings['wc_enabled'] ?? '1' ) === '1' ) && ( ( $settings['test_mode'] ?? '0' ) !== '1' );
    $pub['track_url']          = (string) esc_url( rest_url( 'caterme/v1/track' ) );
    $pub['plan']               = (string) caterme_get_plan();
    // Order intake is always unlimited — no gating exposed to frontend
    $pub['use_wc_cart']        = caterme_wc_active() && ( ( $settings['wc_enabled'] ?? '1' ) === '1' ); // Use WC cart even in test mode
    $pub['test_mode']          = ( $settings['test_mode'] ?? '0' ) === '1';
    $pub['wc_preauth_note']    = (string) ( $settings['wc_preauth_note'] ?? '' );

    // caterme_get_wc_menu() pulls products from WooCommerce, grouped by product category.
    // app.js expects: {categories:[{name,icon},...], items:{"CategoryName":[...],...}}
    // Transform here so the internal format never needs to change.
    $menu_raw = caterme_get_wc_menu();
    $menu_for_js = array(
        'categories' => array(),
        'items'      => array(),
    );
    foreach ( ($menu_raw['categories'] ?? array()) as $cat ) {
        $cat_name = $cat['name'] ?? '';
        $menu_for_js['categories'][] = array(
            'name' => $cat_name,
            'icon' => $cat['icon'] ?? '🍽️',
        );
        $menu_for_js['items'][ $cat_name ] = $cat['items'] ?? array();
    }

    // ── Menu photos are a Pro feature — strip images for free/beta plans ──────
    if ( ! caterme_has_feature( 'menu_photos' ) ) {
        foreach ( $menu_for_js['items'] as $cat_name => &$cat_items ) {
            foreach ( $cat_items as &$item ) {
                unset( $item['image'] );
            }
        }
        unset( $cat_items, $item );
    }

    $settings_json = wp_json_encode( $pub );
    $menu_json     = wp_json_encode( $menu_for_js );
    if ( ! $settings_json ) $settings_json = '{}';
    if ( ! $menu_json )     $menu_json     = '{"categories":[],"items":{}}';

    $react_url   = 'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js';
    $reactdom_url = 'https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js';
    $babel_url   = 'https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.23.2/babel.min.js';
    $app_url     = esc_url( plugin_dir_url( __FILE__ ) . 'js/app.js?v=' . CATERME_VERSION );

    ob_start();
    ?>
    <div id="caterme-root"></div>
    <script type="text/javascript">
        var CATERME_SETTINGS = <?php echo $settings_json; ?>;
        var CATERME_MENU     = <?php echo $menu_json; ?>;
    </script>
    <script src="<?php echo $react_url; ?>"></script>
    <script src="<?php echo $reactdom_url; ?>"></script>
    <script src="<?php echo $babel_url; ?>"></script>
    <script type="text/babel" src="<?php echo $app_url; ?>"></script>
    <?php
    return ob_get_clean();
}
add_shortcode( 'CaterMe_Menu', 'caterme_menu_shortcode' );

